import random


def get_useragent():
    return 'Mozilla/4.0 (PSP (PlayStation Portable); 2.00)'
