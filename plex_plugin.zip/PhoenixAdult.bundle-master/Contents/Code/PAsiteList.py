import siteNaughtyAmerica
import siteXart
import sitePorndoePremium
import siteAnalVids
import siteNewSensations
import siteSpizoo
import sitePrivate
import networkFullPornNetwork
import networkSteppedUp
import networkGammaEnt
import siteJulesJordan
import networkPerfectGonzo
import networkKellyMadison
import networkBadoinkVR
import siteVRBangers
import networkHighTechVR
import siteMilfVR
import networkPornPros
import networkStrike3
import networkKink
import networkNubiles
import networkBellaPass
import siteAllureMedia
import siteManyvids
import siteVirtualReal
import siteVirtualTaboo
import networkCzechVR
import siteFinishesTheJob
import networkWankz
import siteTonightsGirlfriend
import siteKarups
import networkTeenMegaWorld
import siteScrewbox
import siteDorcelClub
import siteMissaX
import networkMYLF
import addActors
import siteFirstAnalQuest
import siteHegre
import networkFemdomEmpire
import siteDorcelVision
import siteXConfessions
import networkCzechAV
import siteArchAngel
import siteWeAreHairy
import networkLoveHerFilms
import siteMomPOV
import networkFuelVirtual
import siteLittleCaprice
import siteVIPissy
import siteGirlsOutWest
import siteGirlsRimming
import siteStepSecrets
import siteVRHush
import networkMetArt
import siteFittingRoom
import siteClips4Sale
import siteVogoV
import siteUltrafilms
import siteFuckingAwesome
import siteToughLoveX
import siteCumLouder
import siteClubFilly
import networkIntersec
import networkCherryPimps
import siteReidMyLips
import sitePlayboyPlus
import siteMeanaWolf
import siteAmourAngels
import networkBang
import siteVivid
import networkAdultEmpireCash
import siteBAMVisions
import sitePJGirls
import siteSinsLife
import networkPuffy
import networkSinX
import networkPureCFNM
import siteATKGirlfriends
import siteInterracialPass
import network1service
import networkTeamSkeet
import networkGammaEntOther
import siteRealityLovers
import siteHoloGirlsVR
import networkRomero
import siteXVirtual
import siteLustReality
import siteSexLikeReal
import siteXillimite
import siteVRPFilms
import siteVRLatina
import siteVRConk
import networkEvolvedFights
import networkJavBus
import siteHucows
import networkVNA
import siteQueenSnake
import siteScrewMeToo
import siteAussieAss
import network5Kporn
import networkTeenCoreClub
import siteDesperateAmateurs
import networkDirtyHardDrive
import siteMeloneChallenge
import siteHollyRandall
import siteInTheCrack
import siteAngelaWhite
import siteCumbizz
import sitePornstarPlatinum
import siteWoodmanCastingX
import networkScoreGroup
import siteTwoTGirls
import siteSicflics
import networkModelCentro
import siteAlettaOceanLive
import networkPornWorld
import siteMormonGirlz
import networkRadicalCashOther
import sitePlumperPass
import networkFTV
import siteJacquieEtMichel
import siteData18Scenes
import sitePenthouseGold
import siteData18Movies
import siteData18Empire
import siteWUNF
import siteSexMex
import siteExpliciteArt
import siteBlackPayBack
import siteSunnyLaneLive
import networkFAKings
import networkBangBrosOther
import sitePutalocura
import siteMelenaMariaRya
import networkPervCity
import networkAbbyWinters
import siteNewSensationsOther
import networkDerangedDollars
import siteDickDrainers
import siteAlsAngels
import siteWatch4Beauty
import siteFemjoy
import networkThickCash
import networkPornCZ
import siteMyDirtyHobby
import networkMetadataAPI
import networkCouplesCinema
import siteJVRPorn
import networkGrooby
import siteAdultEmpire
import siteFamilyTherapy
import siteDarkRoomVR
import sitePuba
import siteStasyQ
import siteBoundHoneys
import siteLustomic
import siteStraponCum
import siteHotwifeXXX
import siteXSinsVR
import sitePOVR
import siteSwallowBay
import siteVirtualPorn
import siteJavLibrary
import siteKillergram
import networkVIP4K
import network18
import networkDirtyFlix
import networkNVG
import networkBlurredMedia
import siteBelAmi
import siteMomComesFirst
import siteCaribbeancom
import siteVRAllure
import siteKin8tengoku
import siteJAVDatabase
import networkAdultPrime
import networkRadicalCash
import siteTeenyTaboo
import networkWowNetwork
import networkAuntJudys
import siteColette
import networkThickCashOther
import siteXevUnleashed
import networkPKJMedia
import networkBellesa
import siteBrandNewAmateurs
import sitePornbox
import siteJesseLoadsMonsterFacials
import networkGASM
import siteHeavyOnHotties

searchSites = {
    0: ('BlackedRaw', 'https://www.blackedraw.com', '/graphql'),
    1: ('Blacked', 'https://www.blacked.com', '/graphql'),
    2: ('Brazzers', 'http://www.brazzers.com', 'https://site-api.project1service.com'),
    3: ('MetadataAPI', 'https://theporndb.net', 'https://api.theporndb.net'),
    4: (),
    5: ('My Friends Hot Mom', 'https://naughtyamerica.com', '/search?term='),
    6: ('My First Sex Teacher', 'https://naughtyamerica.com', '/search?term='),
    7: ('Seduced By A Cougar', 'https://naughtyamerica.com', '/search?term='),
    8: ('My Daughters Hot Friend', 'https://naughtyamerica.com', '/search?term='),
    9: ('My Wife is My Pornstar', 'https://naughtyamerica.com', '/search?term='),
    10: ('Tonights Girlfriend Classic', 'https://naughtyamerica.com', '/search?term='),
    11: ('Wives on Vacation', 'https://naughtyamerica.com', '/search?term='),
    12: ('My Sisters Hot Friend', 'https://naughtyamerica.com', '/search?term='),
    13: ('Naughty Weddings', 'https://naughtyamerica.com', '/search?term='),
    14: ('Dirty Wives Club', 'https://naughtyamerica.com', '/search?term='),
    15: ('My Dads Hot Girlfriend', 'https://naughtyamerica.com', '/search?term='),
    16: ('My Girl Loves Anal', 'https://naughtyamerica.com', '/search?term='),
    17: ('Lesbian Girl on Girl', 'https://naughtyamerica.com', '/search?term='),
    18: ('Naughty Office', 'https://naughtyamerica.com', '/search?term='),
    19: ('I have a Wife', 'https://naughtyamerica.com', '/search?term='),
    20: ('Naughty Bookworms', 'https://naughtyamerica.com', '/search?term='),
    21: ('Housewife 1 on 1', 'https://naughtyamerica.com', '/search?term='),
    22: ('My Wifes Hot Friend', 'https://naughtyamerica.com', '/search?term='),
    23: ('Latin Adultery', 'https://naughtyamerica.com', '/search?term='),
    24: ('Ass Masterpiece', 'https://naughtyamerica.com', '/search?term='),
    25: ('2 Chicks Same Time', 'https://naughtyamerica.com', '/search?term='),
    26: ('My Friends Hot Girl', 'https://naughtyamerica.com', '/search?term='),
    27: ('Neighbor Affair', 'https://naughtyamerica.com', '/search?term='),
    28: ('My Girlfriends Busty Friend', 'https://naughtyamerica.com', '/search?term='),
    29: ('Naughty Athletics', 'https://naughtyamerica.com', '/search?term='),
    30: ('My Naughty Massage', 'https://naughtyamerica.com', '/search?term='),
    31: ('Fast Times', 'https://naughtyamerica.com', '/search?term='),
    32: ('The Passenger', 'https://naughtyamerica.com', '/search?term='),
    33: ('Milf Sugar Babes', 'https://naughtyamerica.com', '/search?term='),
    34: ('Perfect Fucking Strangers', 'https://naughtyamerica.com', '/search?term='),
    35: ('Asian 1 on 1', 'https://naughtyamerica.com', '/search?term='),
    36: ('American Daydreams', 'https://naughtyamerica.com', '/search?term='),
    37: ('SoCal Coeds', 'https://naughtyamerica.com', '/search?term='),
    38: ('Naughty Country Girls', 'https://naughtyamerica.com', '/search?term='),
    39: ('Diary of a Milf', 'https://naughtyamerica.com', '/search?term='),
    40: ('Naughty Rich Girls', 'https://naughtyamerica.com', '/search?term='),
    41: ('My Naughty Latin Maid', 'https://naughtyamerica.com', '/search?term='),
    42: ('Naughty America', 'https://naughtyamerica.com', '/search?term='),
    43: ('Diary of a Nanny', 'https://naughtyamerica.com', '/search?term='),
    44: ('Naughty Flipside', 'https://naughtyamerica.com', '/search?term='),
    45: ('Live Party Girl', 'https://naughtyamerica.com', '/search?term='),
    46: ('Live Naughty Student', 'https://naughtyamerica.com', '/search?term='),
    47: ('Live Naughty Secretary', 'https://naughtyamerica.com', '/search?term='),
    48: ('Live Gym Cam', 'https://naughtyamerica.com', '/search?term='),
    49: ('Live Naughty Teacher', 'https://naughtyamerica.com', '/search?term='),
    50: ('Live Naughty Milf', 'https://naughtyamerica.com', '/search?term='),
    51: ('Live Naughty Nurse', 'https://naughtyamerica.com', '/search?term='),
    52: ('Vixen', 'https://www.vixen.com', '/graphql'),
    53: ('Girlsway', 'https://www.girlsway.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    54: ('Moms in Control', 'http://www.brazzers.com', 'https://site-api.project1service.com'),
    55: ('Pornstars Like It Big', 'http://www.brazzers.com', 'https://site-api.project1service.com'),
    56: ('Big Tits at Work', 'http://www.brazzers.com', 'https://site-api.project1service.com'),
    57: ('Big Tits at School', 'http://www.brazzers.com', 'https://site-api.project1service.com'),
    58: ('Baby Got Boobs', 'http://www.brazzers.com', 'https://site-api.project1service.com'),
    59: ('Real Wife Stories', 'http://www.brazzers.com', 'https://site-api.project1service.com'),
    60: ('Teens Like It Big', 'http://www.brazzers.com', 'https://site-api.project1service.com'),
    61: ('ZZ Series', 'http://www.brazzers.com', 'https://site-api.project1service.com'),
    62: ('Mommy Got Boobs', 'http://www.brazzers.com', 'https://site-api.project1service.com'),
    63: ('Milfs Like It Big', 'http://www.brazzers.com', 'https://site-api.project1service.com'),
    64: ('Big Tits in Uniform', 'http://www.brazzers.com', 'https://site-api.project1service.com'),
    65: ('Doctor Adventures', 'http://www.brazzers.com', 'https://site-api.project1service.com'),
    66: ('Brazzers Exxtra', 'http://www.brazzers.com', 'https://site-api.project1service.com'),
    67: ('Big Tits in Sports', 'http://www.brazzers.com', 'https://site-api.project1service.com'),
    68: ('Big Butts like it big', 'http://www.brazzers.com', 'https://site-api.project1service.com'),
    69: ('Big Wet Butts', 'http://www.brazzers.com', 'https://site-api.project1service.com'),
    70: ('Dirty Masseur', 'http://www.brazzers.com', 'https://site-api.project1service.com'),
    71: ('Hot and Mean', 'http://www.brazzers.com', 'https://site-api.project1service.com'),
    72: ('Shes Gonna Squirt', 'http://www.brazzers.com', 'https://site-api.project1service.com'),
    73: ('Asses In Public', 'http://www.brazzers.com', 'https://site-api.project1service.com'),
    74: ('Busty Z', 'http://www.brazzers.com', 'https://site-api.project1service.com'),
    75: ('Busty and Real', 'http://www.brazzers.com', 'https://site-api.project1service.com'),
    76: ('Hot Chicks Big Asses', 'http://www.brazzers.com', 'https://site-api.project1service.com'),
    77: ('CFNM Clothed Female Male Nude', 'http://www.brazzers.com', 'https://site-api.project1service.com'),
    78: ('Teens Like It Black', 'http://www.brazzers.com', 'https://site-api.project1service.com'),
    79: ('Racks and Blacks', 'http://www.brazzers.com', 'https://site-api.project1service.com'),
    80: ('Butts and Blacks', 'http://www.brazzers.com', 'https://site-api.project1service.com'),
    81: (),
    82: ('X-Art', 'https://www.x-art.com', '/search/'),
    83: ('Bang Bros', 'https://bangbros.com', 'https://site-api.project1service.com'),
    84: ('Ass Parade', 'https://bangbros.com', 'https://site-api.project1service.com'),
    85: ('AvaSpice', 'https://bangbros.com', 'https://site-api.project1service.com'),
    86: ('Back Room Facials', 'https://bangbros.com', 'https://site-api.project1service.com'),
    87: ('Backroom MILF', 'https://bangbros.com', 'https://site-api.project1service.com'),
    88: ('Ball Honeys', 'https://bangbros.com', 'https://site-api.project1service.com'),
    89: ('Bang Bus', 'https://bangbros.com', 'https://site-api.project1service.com'),
    90: ('Bang Casting', 'https://bangbros.com', 'https://site-api.project1service.com'),
    91: ('Bang POV', 'https://bangbros.com', 'https://site-api.project1service.com'),
    92: ('Bang Tryouts', 'https://bangbros.com', 'https://site-api.project1service.com'),
    93: ('BangBros 18', 'https://bangbros.com', 'https://site-api.project1service.com'),
    94: ('BangBros Angels', 'https://bangbros.com', 'https://site-api.project1service.com'),
    95: ('Bangbros Clips', 'https://bangbros.com', 'https://site-api.project1service.com'),
    96: ('BangBros Remastered', 'https://bangbros.com', 'https://site-api.project1service.com'),
    97: ('Big Mouthfuls', 'https://bangbros.com', 'https://site-api.project1service.com'),
    98: ('Big Tit Cream Pie', 'https://bangbros.com', 'https://site-api.project1service.com'),
    99: ('Big Tits Round Asses', 'https://bangbros.com', 'https://site-api.project1service.com'),
    100: ('BlowJob Fridays', 'https://bangbros.com', 'https://site-api.project1service.com'),
    101: ('Blowjob Ninjas', 'https://bangbros.com', 'https://site-api.project1service.com'),
    102: ('Boob Squad', 'https://bangbros.com', 'https://site-api.project1service.com'),
    103: ('Brown Bunnies', 'https://bangbros.com', 'https://site-api.project1service.com'),
    104: ('Can He Score', 'https://bangbros.com', 'https://site-api.project1service.com'),
    105: ('Bang Casting', 'https://bangbros.com', 'https://site-api.project1service.com'),
    106: ('Chongas', 'https://bangbros.com', 'https://site-api.project1service.com'),
    107: ('Colombia Fuck Fest', 'https://bangbros.com', 'https://site-api.project1service.com'),
    108: ('Dirty World Tour', 'https://bangbros.com', 'https://site-api.project1service.com'),
    109: ('Dorm Invasion', 'https://bangbros.com', 'https://site-api.project1service.com'),
    110: ('Facial Fest', 'https://bangbros.com', 'https://site-api.project1service.com'),
    111: ('Fuck Team Five', 'https://bangbros.com', 'https://site-api.project1service.com'),
    112: ('Glory Hole Loads', 'https://bangbros.com', 'https://site-api.project1service.com'),
    113: ('Latina Rampage', 'https://bangbros.com', 'https://site-api.project1service.com'),
    114: ('Living With Anna', 'https://bangbros.com', 'https://site-api.project1service.com'),
    115: ('Magical Feet', 'https://bangbros.com', 'https://site-api.project1service.com'),
    116: ('MILF Lessons', 'https://bangbros.com', 'https://site-api.project1service.com'),
    117: ('Milf Soup', 'https://bangbros.com', 'https://site-api.project1service.com'),
    118: ('MomIsHorny', 'https://bangbros.com', 'https://site-api.project1service.com'),
    119: ('Monsters of Cock', 'https://bangbros.com', 'https://site-api.project1service.com'),
    120: ('Mr CamelToe', 'https://bangbros.com', 'https://site-api.project1service.com'),
    121: ('Mr Anal', 'https://bangbros.com', 'https://site-api.project1service.com'),
    122: ('My Dirty Maid', 'https://bangbros.com', 'https://site-api.project1service.com'),
    123: ('My Life In Brazil', 'https://bangbros.com', 'https://site-api.project1service.com'),
    124: ('Newbie Black', 'https://bangbros.com', 'https://site-api.project1service.com'),
    125: ('Party of 3', 'https://bangbros.com', 'https://site-api.project1service.com'),
    126: ('Pawg', 'https://bangbros.com', 'https://site-api.project1service.com'),
    127: ('Penny Show', 'https://bangbros.com', 'https://site-api.project1service.com'),
    128: ('Porn Star Spa', 'https://bangbros.com', 'https://site-api.project1service.com'),
    129: ('Power Munch', 'https://bangbros.com', 'https://site-api.project1service.com'),
    130: ('Public Bang', 'https://bangbros.com', 'https://site-api.project1service.com'),
    131: ('Slutty White Girls', 'https://bangbros.com', 'https://site-api.project1service.com'),
    132: ('Stepmom Videos', 'https://bangbros.com', 'https://site-api.project1service.com'),
    133: ('Street Ranger', 'https://bangbros.com', 'https://site-api.project1service.com'),
    134: ('Tugjobs', 'https://bangbros.com', 'https://site-api.project1service.com'),
    135: ('Working Latinas', 'https://bangbros.com', 'https://site-api.project1service.com'),
    136: ('Tushy', 'https://www.tushy.com', '/graphql'),
    137: ('Reality Kings', 'https://www.realitykings.com', 'https://site-api.project1service.com'),
    138: ('40 Inch Plus', 'https://www.realitykings.com', 'https://site-api.project1service.com'),
    139: ('8th Street Latinas', 'https://www.realitykings.com', 'https://site-api.project1service.com'),
    140: ('Bad Tow Truck', 'https://www.realitykings.com', 'https://site-api.project1service.com'),
    141: ('Big Naturals', 'https://www.realitykings.com', 'https://site-api.project1service.com'),
    142: ('Big Tits Boss', 'https://www.realitykings.com', 'https://site-api.project1service.com'),
    143: ('Bikini Crashers', 'https://www.realitykings.com', 'https://site-api.project1service.com'),
    144: ('Captain Stabbin', 'https://www.realitykings.com', 'https://site-api.project1service.com'),
    145: ('CFNM Secret', 'https://www.realitykings.com', 'https://site-api.project1service.com'),
    146: ('Cum Fiesta', 'https://www.realitykings.com', 'https://site-api.project1service.com'),
    147: ('Cum Girls', 'https://www.realitykings.com', 'https://site-api.project1service.com'),
    148: ('Dangerous Dongs', 'https://www.realitykings.com', 'https://site-api.project1service.com'),
    149: ('Euro Sex Parties', 'https://www.realitykings.com', 'https://site-api.project1service.com'),
    150: ('Extreme Asses', 'https://www.realitykings.com', 'https://site-api.project1service.com'),
    151: ('Extreme Naturals', 'https://www.realitykings.com', 'https://site-api.project1service.com'),
    152: ('First Time Auditions', 'https://www.realitykings.com', 'https://site-api.project1service.com'),
    153: ('Flower Tucci', 'https://www.realitykings.com', 'https://site-api.project1service.com'),
    154: ('Girls of Naked', 'https://www.realitykings.com', 'https://site-api.project1service.com'),
    155: ('Happy Tugs', 'https://www.realitykings.com', 'https://site-api.project1service.com'),
    156: ('HD Love', 'https://www.realitykings.com', 'https://site-api.project1service.com'),
    157: ('Hot Bush', 'https://www.realitykings.com', 'https://site-api.project1service.com'),
    158: ('In the VIP', 'https://www.realitykings.com', 'https://site-api.project1service.com'),
    159: ('Mike in Brazil', 'https://www.realitykings.com', 'https://site-api.project1service.com'),
    160: ('Mikes Apartment', 'https://www.realitykings.com', 'https://site-api.project1service.com'),
    161: ('Milf Hunter', 'https://www.realitykings.com', 'https://site-api.project1service.com'),
    162: ('Milf Next Door', 'https://www.realitykings.com', 'https://site-api.project1service.com'),
    163: ('Moms Bang Teens', 'https://www.realitykings.com', 'https://site-api.project1service.com'),
    164: ('Moms Lick Teens', 'https://www.realitykings.com', 'https://site-api.project1service.com'),
    165: ('Money Talks', 'https://www.realitykings.com', 'https://site-api.project1service.com'),
    166: ('Monster Curves', 'https://www.realitykings.com', 'https://site-api.project1service.com'),
    167: ('No Faces', 'https://www.realitykings.com', 'https://site-api.project1service.com'),
    168: ('Pure 18', 'https://www.realitykings.com', 'https://site-api.project1service.com'),
    169: ('Real Orgasms', 'https://www.realitykings.com', 'https://site-api.project1service.com'),
    170: ('RK Prime', 'https://www.realitykings.com', 'https://site-api.project1service.com'),
    171: ('Round and Brown', 'https://www.realitykings.com', 'https://site-api.project1service.com'),
    172: ('Saturday Night Latinas', 'https://www.realitykings.com', 'https://site-api.project1service.com'),
    173: ('See My Wife', 'https://www.realitykings.com', 'https://site-api.project1service.com'),
    174: ('Sneaky Sex', 'https://www.realitykings.com', 'https://site-api.project1service.com'),
    175: ('Street BlowJobs', 'https://www.realitykings.com', 'https://site-api.project1service.com'),
    176: ('Team Squirt', 'https://www.realitykings.com', 'https://site-api.project1service.com'),
    177: ('Teens Love Huge Cocks', 'https://www.realitykings.com', 'https://site-api.project1service.com'),
    178: ('Top Shelf Pussy', 'https://www.realitykings.com', 'https://site-api.project1service.com'),
    179: ('Tranny Surprise', 'https://www.realitykings.com', 'https://site-api.project1service.com'),
    180: ('VIP Crew', 'https://www.realitykings.com', 'https://site-api.project1service.com'),
    181: ('We Live Together', 'https://www.realitykings.com', 'https://site-api.project1service.com'),
    182: ('Wives in Pantyhose', 'https://www.realitykings.com', 'https://site-api.project1service.com'),
    183: ('21Naturals', 'https://www.21naturals.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    184: ('PornFidelity', 'https://www.pornfidelity.com', '/episodes/search/??site=2&page=1&search='),
    185: ('TeenFidelity', 'https://www.pornfidelity.com', '/episodes/search/??site=3&page=1&search='),
    186: ('Kelly Madison', 'https://www.pornfidelity.com', '/episodes/search/??site=1&page=1&search='),
    187: ('TeamSkeet', 'https://www.teamskeet.com', '/movies/'),
    188: ('Exxxtra Small', 'https://www.teamskeet.com', '/movies/'),
    189: ('Teen Pies', 'https://www.teamskeet.com', '/movies/'),
    190: ('Innocent High', 'https://www.teamskeet.com', '/movies/'),
    191: ('Teen Curves', 'https://www.teamskeet.com', '/movies/'),
    192: ('CFNM Teens', 'https://www.teamskeet.com', '/movies/'),
    193: ('Teens Love Anal', 'https://www.teamskeet.com', '/movies/'),
    194: ('My Babysitters Club', 'https://www.teamskeet.com', '/movies/'),
    195: ('Shes New', 'https://www.teamskeet.com', '/movies/'),
    196: ('Teens Do Porn', 'https://www.teamskeet.com', '/movies/'),
    197: ('POV Life', 'https://www.teamskeet.com', '/movies/'),
    198: ('The Real Workout', 'https://www.teamskeet.com', '/movies/'),
    199: ('This Girl Sucks', 'https://www.teamskeet.com', '/movies/'),
    200: ('Teens Love Money', 'https://www.teamskeet.com', '/movies/'),
    201: ('Oye Loca', 'https://www.teamskeet.com', '/movies/'),
    202: ('Titty Attack', 'https://www.teamskeet.com', '/movies/'),
    203: ('Teeny Black', 'https://www.teamskeet.com', '/movies/'),
    204: ('Lust HD', 'https://www.teamskeet.com', '/movies/'),
    205: ('Rub A Teen', 'https://www.teamskeet.com', '/movies/'),
    206: ('Her Freshman Year', 'https://www.teamskeet.com', '/movies/'),
    207: ('Self Desire', 'https://www.teamskeet.com', '/movies/'),
    208: ('Solo Interviews', 'https://www.teamskeet.com', '/movies/'),
    209: ('Team Skeet Extras', 'https://www.teamskeet.com', '/movies/'),
    210: ('Dyked', 'https://www.teamskeet.com', '/movies/'),
    211: ('Badmilfs', 'https://www.teamskeet.com', '/movies/'),
    212: ('Gingerpatch', 'https://www.teamskeet.com', '/movies/'),
    213: ('BraceFaced', 'https://www.teamskeet.com', '/movies/'),
    214: ('TeenJoi', 'https://www.teamskeet.com', '/movies/'),
    215: ('StepSiblings', 'https://www.teamskeet.com', '/movies/'),
    216: ('Lets Doe It', 'https://letsdoeit.com', 'https://site-api.project1service.com'),
    217: ('The White Boxxx', 'https://letsdoeit.com', 'https://site-api.project1service.com'),
    218: ('Scam Angels', 'https://letsdoeit.com', 'https://site-api.project1service.com'),
    219: ('Chicas Loca', 'https://mamacitaz.com', '/search.en.html?q='),
    220: ('Her Limit', 'https://letsdoeit.com', 'https://site-api.project1service.com'),
    221: ('A Girl Knows', 'https://letsdoeit.com', 'https://site-api.project1service.com'),
    222: ('Porno Academie', 'https://letsdoeit.com', 'https://site-api.project1service.com'),
    223: ('Xchimera', 'https://letsdoeit.com', 'https://site-api.project1service.com'),
    224: ('Carne Del Mercado', 'https://mamacitaz.com', '/search.en.html?q='),
    225: ('XXX Shades', 'https://letsdoeit.com', 'https://site-api.project1service.com'),
    226: ('Bums Bus', 'https://letsdoeit.com', 'https://site-api.project1service.com'),
    227: ('Bitches Abroad', 'https://letsdoeit.com', 'https://site-api.project1service.com'),
    228: ('La Cochonne', 'https://amateureuro.com', '/search.en.html?q='),
    229: ('Crowd Bondage', 'https://forbondage.com', '/search.en.html?q='),
    230: ('Relaxxxed', 'https://letsdoeit.com', 'https://site-api.project1service.com'),
    231: ('My Naughty Album', 'https://letsdoeit.com', 'https://site-api.project1service.com'),
    232: ('Tu Venganza', 'https://mamacitaz.com', '/search.en.html?q='),
    233: ('Bums Buero', 'https://letsdoeit.com', 'https://site-api.project1service.com'),
    234: ('Los Consoladores', 'https://vipsexvault.com', '/search.en.html?q='),
    235: ('Quest for Orgasm', 'https://letsdoeit.com', 'https://site-api.project1service.com'),
    236: ('Trans Bella', 'https://transbella.com', '/search.en.html?q='),
    237: ('Her Big Ass', 'https://mamacitaz.com', '/search.en.html?q='),
    238: ('Horny Hostel', 'https://letsdoeit.com', 'https://site-api.project1service.com'),
    239: ('Fucked In Traffic', 'https://vipsexvault.com', '/search.en.html?q='),
    240: ('Las Folladoras', 'https://amateureuro.com', '/search.en.html?q='),
    241: ('Badtime Stories', 'https://forbondage.com', '/search.en.html?q'),
    242: ('Exposed Casting', 'https://vipsexvault.com', '/search.en.html?q='),
    243: ('Kinky Inlaws', 'https://letsdoeit.com', 'https://site-api.project1service.com'),
    244: ('Doe Projects', 'https://letsdoeit.com', 'https://site-api.project1service.com'),
    245: ('Porndoepedia', 'https://vipsexvault.com', '/search.en.html?q='),
    246: ('Casting Francais', 'https://amateureuro.com', '/search.en.html?q='),
    247: ('Bums Besuch', 'https://letsdoeit.com', 'https://site-api.project1service.com'),
    248: ('Special Feet Force', 'https://forbondage.com', '/search.en.html?q'),
    249: ('Trans Taboo', 'https://transbella.com', '/search.en.html?q='),
    250: ('Operacion Limpieza', 'https://mamacitaz.com', '/search.en.html?q='),
    251: ('La Novice', 'https://amateureuro.com', '/search.en.html?q='),
    252: ('Casting Alla Italiana', 'https://amateureuro.com', '/search.en.html?q='),
    253: ('PinUp Sex', 'https://vipsexvault.com', '/search.en.html?q='),
    254: ('Hausfrau Ficken', 'https://amateureuro.com', '/search.en.html?q='),
    255: ('Deutschland Report', 'https://amateureuro.com', '/search.en.html?q='),
    256: ('Reife Swinger', 'https://amateureuro.com', '/search.en.html?q='),
    257: ('Scambisti Maturi', 'https://amateureuro.com', '/search.en.html?q='),
    258: ('Sextape Germany', 'https://amateureuro.com', '/search.en.html?q='),
    259: ('XXX Omas', 'https://amateureuro.com', '/search.en.html?q='),
    260: ('AnalVids', 'https://www.analvids.com', '/api/autocomplete/search?q='),
    261: ('Mofos', 'https://www.mofos.com', 'https://site-api.project1service.com'),
    262: ('ShareMyBF', 'https://www.mofos.com', 'https://site-api.project1service.com'),
    263: ('Dont Break Me', 'https://www.mofos.com', 'https://site-api.project1service.com'),
    264: ('I Know That Girl', 'https://www.mofos.com', 'https://site-api.project1service.com'),
    265: ('Lets Try Anal', 'https://www.mofos.com', 'https://site-api.project1service.com'),
    266: ('Pervs On Patrol', 'https://www.mofos.com', 'https://site-api.project1service.com'),
    267: ('Stranded Teens', 'https://www.mofos.com', 'https://site-api.project1service.com'),
    268: ('Mofos B Sides', 'https://www.mofos.com', 'https://site-api.project1service.com'),
    269: ('Shes a Freak', 'https://www.mofos.com', 'https://site-api.project1service.com'),
    270: ('Public Pickups', 'https://www.mofos.com', 'https://site-api.project1service.com'),
    271: ('Babes', 'https://www.babes.com', 'https://site-api.project1service.com'),
    272: ('Babes Unleashed', 'https://www.babes.com', 'https://site-api.project1service.com'),
    273: ('Black is Better', 'https://www.babes.com', 'https://site-api.project1service.com'),
    274: ('Elegant Anal', 'https://www.babes.com', 'https://site-api.project1service.com'),
    275: ('Office Obsession', 'https://www.babes.com', 'https://site-api.project1service.com'),
    276: ('Stepmom Lessons', 'https://www.babes.com', 'https://site-api.project1service.com'),
    277: ('Evil Angel', 'https://www.evilangel.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    278: ('HardX', 'https://www.xempire.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    279: ('GloryHoleSecrets', 'http://www.gloryholesecrets.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    280: ('New Sensations', 'http://www.newsensations.com', '/tour_ns/'),
    281: ('Pure Taboo', 'https://www.puretaboo.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    282: ('Swallowed', 'https://tour.swallowed.com', '/_next/data/'),
    283: ('TrueAnal', 'https://tour.trueanal.com', '/_next/data/'),
    284: ('Nympho', 'https://tour.nympho.com', '/_next/data/'),
    285: ('EroticaX', 'https://www.xempire.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    286: ('DarkX', 'https://www.xempire.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    287: ('LesbianX', 'http://www.xempire.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    288: ('Twistys', 'https://www.twistys.com', 'https://site-api.project1service.com'),
    289: ('WhenGirlsPlay', 'https://www.twistys.com', 'https://site-api.project1service.com'),
    290: ('MomKnowsBest', 'https://www.twistys.com', 'https://site-api.project1service.com'),
    291: ('TwistysHard', 'https://www.twistys.com', 'https://site-api.project1service.com'),
    292: ('VirtualTaboo', 'https://virtualtaboo.com', '/search?q='),
    293: ('Spizoo', 'https://www.spizoo.com', '/search.php?query='),
    294: ('Private', 'https://www.private.com', '/search.php?query='),
    295: ('Anal Introductions', 'https://www.private.com', '/search.php?query='),
    296: ('Blacks on Sluts', 'https://www.private.com', '/search.php?query='),
    297: ('I confess Files', 'https://www.private.com', '/search.php?query='),
    298: ('Private Fetish', 'https://www.private.com', '/search.php?query='),
    299: ('Mission Ass Possible', 'https://www.private.com', '/search.php?query='),
    300: ('Private MILFs', 'https://www.private.com', '/search.php?query='),
    301: ('Russian Fake Agent', 'https://www.private.com', '/search.php?query='),
    302: ('Russian Teen Ass', 'https://www.private.com', '/search.php?query='),
    303: ('Sex on the beach', 'https://www.private.com', '/search.php?query='),
    304: ('Private Stars', 'https://www.private.com', '/search.php?query='),
    305: ('Tight and Teen', 'https://www.private.com', '/search.php?query='),
    306: ('Passion-HD', 'https://passion-hd.com', '/api'),
    307: ('FantasyHD', 'https://fantasyhd.com', '/api'),
    308: ('PornPros', 'https://pornpros.com', '/api'),
    309: ('18 Years Old', 'https://pornpros.com', '/api'),
    310: ('Real ExGirlfriends', 'https://pornpros.com', '/api'),
    311: ('Massage Creep', 'https://pornpros.com', '/api'),
    312: ('Deep Throat Love', 'https://pornpros.com', '/api'),
    313: ('TeenBFF', 'https://pornpros.com', '/api'),
    314: ('Shady Pi', 'https://pornpros.com', '/api'),
    315: ('Cruelty Party', 'https://pornpros.com', '/api'),
    316: ('Disgraced 18', 'https://pornpros.com', '/api'),
    317: ('Milf Humiliation', 'https://pornpros.com', '/api'),
    318: ('Cumshot Surprise', 'https://pornpros.com', '/api'),
    319: ('40oz Bounce', 'https://pornpros.com', '/api'),
    320: ('Jurassic Cock', 'https://pornpros.com', '/api'),
    321: ('Freaks Of Cock', 'https://pornpros.com', '/api'),
    322: ('Euro Humpers', 'https://pornpros.com', '/api'),
    323: ('Freaks Of Boobs', 'https://pornpros.com', '/api'),
    324: ('Cum Disgrace', 'https://pornpros.com', '/api'),
    325: ('Cock Competition', 'https://pornpros.com', '/api'),
    326: ('Pimp Parade', 'https://pornpros.com', '/api'),
    327: ('Squirt Disgrace', 'https://pornpros.com', '/api'),
    328: ('DigitalPlayground', 'https://www.digitalplayground.com', 'https://site-api.project1service.com'),
    329: ('Throated', 'https://www.blowpass.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    330: ('Nuru Massage', 'https://www.fantasymassage.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    331: (),
    332: ('DDF Babes', 'https://ddfnetwork.com', '/videos/freeword/'),
    333: ('SexyHub', 'https://www.sexyhub.com', 'https://site-api.project1service.com'),
    334: ('Dane Jones', 'https://www.sexyhub.com', 'https://site-api.project1service.com'),
    335: ('Fitness Rooms', 'https://www.sexyhub.com', 'https://site-api.project1service.com'),
    336: ('Girlfriends.xxx', 'https://www.sexyhub.com', 'https://site-api.project1service.com'),
    337: ('Lesbea', 'https://www.lesbea.com', 'https://site-api.project1service.com'),
    338: ('Massage Rooms', 'https://www.sexyhub.com', 'https://site-api.project1service.com'),
    339: ('MomXXX', 'https://www.sexyhub.com', 'https://site-api.project1service.com'),
    340: ('FakeHub', 'https://www.fakehub.com', 'https://site-api.project1service.com'),
    341: ('Big Cock Bully', 'https://naughtyamerica.com', '/search?term='),
    342: ('VirtualRealPorn', 'https://virtualrealporn.com', '/vr-porn-video/'),
    343: ('Analized', 'https://analized.com', '/1/search/'),
    344: ('James Deen', 'https://jamesdeen.com', '/1/search/'),
    345: ('Twisted Visual', 'https://twistedvisual.com', '/1/search/'),
    346: ('Only Prince', 'https://onlyprince.com', '/1/search/'),
    347: ('Bad Daddy POV', 'https://baddaddypov.com', '/1/search/'),
    348: ('POV Perverts', 'https://povperverts.net', '/1/search/'),
    349: ('Pervert Gallery', 'https://pervertgallery.com', '/1/search/'),
    350: ('DTF Sluts', 'https://dtfsluts.com', '/1/search/'),
    351: ('Mommy Blows Best', 'http://www.blowpass.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    352: ('Only Teen Blowjobs', 'http://www.blowpass.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    353: ('1000 Facials', 'http://www.blowpass.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    354: ('Immoral Live', 'http://www.blowpass.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    355: ('Fantasy Massage', 'http://www.fantasymassage.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    356: ('All Girl Massage', 'http://www.fantasymassage.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    357: ('Soapy Massage', 'http://www.fantasymassage.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    358: ('Milking Table', 'http://www.fantasymassage.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    359: ('Massage Parlor', 'http://www.fantasymassage.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    360: ('Tricky Spa', 'http://www.fantasymassage.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    361: ('Sweetheart Video', 'https://www.milehighmedia.com', 'https://site-api.project1service.com'),
    362: ('Reality Junkies', 'http://www.milehighmedia.com', 'https://site-api.project1service.com'),
    363: ('SweetSinner', 'https://www.milehighmedia.com', 'https://site-api.project1service.com'),
    364: ('Doghouse Digital', 'http://www.milehighmedia.com', 'https://site-api.project1service.com'),
    365: ('21Sextury', 'http://www.21sextury.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    366: ('Anal Teen Angels', 'http://www.21sextury.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    367: ('Deepthroat Frenzy', 'http://www.21sextury.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    368: ('DP Fanatics', 'http://www.21sextury.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    369: ('Footsie Babes', 'http://www.21sextury.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    370: ('Gapeland', 'http://www.21sextury.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    371: ('Lez Cuties', 'http://www.21sextury.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    372: ('Pix and Video', 'http://www.21sextury.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    373: ('21FootArt', 'http://www.21naturals.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    374: ('21EroticAnal', 'http://www.21naturals.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    375: ('Mommys Girl', 'http://www.girlsway.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    376: ('Web Young', 'http://www.girlsway.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    377: ('Girls Try Anal', 'http://www.girlsway.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    378: ('Sextape Lesbians', 'http://www.girlsway.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    379: ('Girlsway Originals', 'http://www.girlsway.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    380: ('Girlfriends Films', 'http://www.girlfriendsfilms.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    381: ('Burning Angel', 'http://www.burningangel.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    382: ('Pretty Dirty', 'http://www.prettydirty.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    383: ('Devils Film', 'http://www.devilsfilm.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    384: ('Peter North', 'http://www.peternorth.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    385: ('Rocco Siffredi', 'http://www.roccosiffredi.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    386: ('Tera Patrick', 'http://www.terapatrick.com', '/en/search/'),
    387: ('Sunny Leone', 'http://www.sunnyleone.com', '/en/search/scene/'),
    388: ('Lane Sisters', 'http://www.lanesisters.com', '/en/search/scene/'),
    389: ('Dylan Ryder', 'http://www.dylanryder.com', '/en/search/scene/'),
    390: ('Abbey Brooks', 'http://www.abbeybrooks.com', '/en/search/scene/'),
    391: ('Devon Lee', 'http://www.devonlee.com', '/en/search/scene/'),
    392: ('Hanna Hilton', 'http://www.hannahilton.com', '/en/search/scene/'),
    393: ('LA Sluts', 'https://naughtyamerica.com', '/search?term='),
    394: ('Slut Stepsister', 'https://naughtyamerica.com', '/search?term='),
    395: ('Teens Love Cream', 'https://naughtyamerica.com', '/search?term='),
    396: ('Latina Stepmom', 'https://naughtyamerica.com', '/search?term='),
    397: ('Fake Taxi', 'https://www.fakehub.com', 'https://site-api.project1service.com'),
    398: ('Fakehub Originals', 'https://www.fakehub.com', 'https://site-api.project1service.com'),
    399: ('Public Agent', 'https://www.fakehub.com', 'https://site-api.project1service.com'),
    400: ('Fake Agent', 'https://www.fakehub.com', 'https://site-api.project1service.com'),
    401: ('Female Agent', 'https://www.fakehub.com', 'https://site-api.project1service.com'),
    402: ('Fake Hospital', 'https://www.fakehub.com', 'https://site-api.project1service.com'),
    403: ('Fake Agent UK', 'https://www.fakehub.com', 'https://site-api.project1service.com'),
    404: ('Fake Cop', 'https://www.fakehub.com', 'https://site-api.project1service.com'),
    405: ('Female Fake Taxi', 'https://www.fakehub.com', 'https://site-api.project1service.com'),
    406: ('Fake Driving School', 'https://www.fakehub.com', 'https://site-api.project1service.com'),
    407: ('Fake Hostel', 'https://www.fakehub.com', 'https://site-api.project1service.com'),
    408: ('Dogfart', 'https://www.dogfartnetwork.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    409: ('BlacksOnBlondes', 'https://www.dogfartnetwork.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    410: ('CuckoldSessions', 'https://www.dogfartnetwork.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    411: ('GloryHole', 'https://www.dogfartnetwork.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    412: ('BlacksOnCougars', 'https://www.dogfartnetwork.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    413: ('WeFuckBlackGirls', 'https://www.dogfartnetwork.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    414: ('WatchingMyMomGoBlack', 'https://www.dogfartnetwork.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    415: ('InterracialBlowbang', 'https://www.dogfartnetwork.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    416: ('CumBang', 'https://www.dogfartnetwork.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    417: ('InterracialPickups', 'https://www.dogfartnetwork.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    418: ('WatchingMyDaughterGoBlack', 'https://www.dogfartnetwork.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    419: ('ZebraGirls', 'https://www.dogfartnetwork.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    420: ('GloryHoleInitiations', 'https://www.dogfartnetwork.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    421: ('DogfartBehindTheScenes', 'https://www.dogfartnetwork.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    422: ('BlackMeatWhiteFeet', 'https://www.dogfartnetwork.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    423: ('SpringThomas', 'https://www.dogfartnetwork.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    424: ('KatieThomas', 'https://www.dogfartnetwork.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    425: ('RuthBlackwell', 'https://www.dogfartnetwork.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    426: ('CandyMonroe', 'https://www.dogfartnetwork.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    427: ('WifeWriting', 'https://www.dogfartnetwork.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    428: ('BarbCummings', 'https://www.dogfartnetwork.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    429: ('TheMinion', 'https://www.dogfartnetwork.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    430: ('BlacksOnBoys', 'https://www.dogfartnetwork.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    431: ('GloryholesAndHandjobs', 'https://www.dogfartnetwork.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    432: ('Jules Jordan', 'https://www.julesjordan.com', '/trial/search.php?query='),
    433: ('DDFNetwork', 'https://ddfnetwork.com', '/videos/freeword/'),
    434: ('Sandys Fantasies', 'https://ddfnetwork.com', '/videos/freeword/'),
    435: ('Cherry Jul', 'https://ddfnetwork.com', '/videos/freeword/'),
    436: ('Eve Angel Official', 'https://ddfnetwork.com', '/videos/freeword/'),
    437: ('Sex Video Casting', 'https://ddfnetwork.com', '/videos/freeword/'),
    438: ('Hairy Twatter', 'https://ddfnetwork.com', '/videos/freeword/'),
    439: ('DDF Xtreme', 'https://ddfnetwork.com', '/videos/freeword/'),
    440: ('DDF Busty', 'https://ddfbusty.com', '/videos/freeword/'),
    441: ('House of Taboo', 'https://houseoftaboo.com', '/videos/freeword/'),
    442: ('Euro Girls on Girls', 'https://eurogirlsongirls.com', '/videos/freeword/'),
    443: ('1ByDay', 'https://1by-day.com', '/videos/freeword/'),
    444: ('Euro Teen Erotica', 'https://euroteenerotica.com', '/videos/freeword/'),
    445: ('Hot Legs and Feet', 'https://hotlegsandfeet.com', '/videos/freeword/'),
    446: ('Only Blowjob', 'https://onlyblowjob.com', '/videos/freeword/'),
    447: ('Hands on Hardcore', 'https://handsonhardcore.com', '/videos/freeword/'),
    448: ('PerfectGonzo', 'https://www.perfectgonzo.com', '/movies?q='),
    449: ('AllInternal', 'https://www.perfectgonzo.com', '/movies?tag=allinternal&q='),
    450: ('AssTraffic', 'https://www.perfectgonzo.com', '/movies?tag=asstraffic&q='),
    451: ('CumForCover', 'https://www.perfectgonzo.com', '/movies?tag=cumforcover&q='),
    452: ('Primecups', 'https://www.perfectgonzo.com', '/movies?tag=primecups&q='),
    453: ('PurePOV', 'https://www.perfectgonzo.com', '/movies?tag=purepov&q='),
    454: ('SpermSwap', 'https://www.perfectgonzo.com', '/movies?tag=spermaswap&q='),
    455: ('TamedTeens', 'https://www.perfectgonzo.com', '/movies?tag=tamedteens&q='),
    456: ('GiveMePink', 'https://givemepink.com', '/movies?tag=givemepink&q='),
    457: ('FistFlush', 'https://www.perfectgonzo.com', '/movies?tag=fistflush&q='),
    458: ('MilfThing', 'https://www.perfectgonzo.com', '/movies?tag=milfthing&q='),
    459: ('PerfectGonzoInterview', 'https://www.perfectgonzo.com', '/movies?tag=interview&q='),
    460: ('21Sextreme', 'http://www.21sextreme.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    461: ('LustyGrandmas', 'http://www.21sextreme.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    462: ('GrandpasFuckTeens', 'http://www.21sextreme.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    463: ('TeachMeFisting', 'http://www.21sextreme.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    464: ('Zoliboy', 'http://www.21sextreme.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    465: ('DominatedGirls', 'http://www.21sextreme.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    466: ('Asshole Fever', 'http://www.21sextury.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    467: ('Anal College', 'https://naughtyamerica.com', '/search?term='),
    468: ('Watch Your Wife', 'https://naughtyamerica.com', '/search?term='),
    469: ('BadoinkVR', 'https://www.badoinkvr.com', '/vrpornvideos/search/'),
    470: ('BabeVR', 'https://www.babevr.com', '/vrpornvideos/search/'),
    471: ('18VR', 'https://www.18vr.com', '/vrpornvideos/search/'),
    472: ('KinkVR', 'http://www.kinkvr.com', '/bdsm-vr-videos/search/'),
    473: ('VRCosplayX', 'https://www.vrcosplayx.com', '/cosplaypornvideos/search/'),
    474: ('VRBangers', 'https://www.vrbangers.com', '/api/content/v1/search/'),
    475: ('SexBabesVR', 'https://www.sexbabesvr.com', '/video/'),
    476: ('WankzVR', 'https://www.wankzvr.com', '/search?q='),
    477: ('MilfVR', 'https://www.milfvr.com', '/search?q='),
    478: ('Joymii', 'https://www.joymii.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    479: ('POVD', 'https://povd.com', '/api'),
    480: ('Cum4K', 'https://cum4k.com', '/api'),
    481: ('Exotic4k', 'https://exotic4k.com', '/api'),
    482: ('Tiny4k', 'https://tiny4k.com', '/api'),
    483: ('Lubed', 'https://lubed.com', '/api'),
    484: ('PureMature', 'https://puremature.com', '/api'),
    485: ('NannySpy', 'https://nannyspy.com', '/api'),
    486: ('Holed', 'https://holed.com', '/api'),
    487: ('Casting Couch-X', 'https://castingcouch-x.com', '/api'),
    488: ('SpyFam', 'https://spyfam.com', '/api'),
    489: ('My Very First Time', 'https://myveryfirsttime.com', '/api'),
    490: ('Kink', 'http://www.kink.com', '/search?q='),
    491: ('Brutal Sessions', 'http://www.kink.com', '/search?channelIds=brutalsessions&q='),
    492: ('Device Bondage', 'http://www.kink.com', '/search?channelIds=devicebondage&q='),
    493: ('Families Tied', 'http://www.kink.com', '/search?channelIds=familiestied&q='),
    494: ('Hardcore Gangbang', 'http://www.kink.com', '/search?channelIds=hardcoregangbang&q='),
    495: ('Hogtied', 'http://www.kink.com', '/search?channelIds=hogtied&q='),
    496: ('Kink Features', 'http://www.kink.com', '/search?channelIds=kinkfeatures&q='),
    497: ('Kink University', 'http://www.kink.com', '/search?channelIds=kinkuniversity&q='),
    498: ('Public Disgrace', 'http://www.kink.com', '/search?channelIds=publicdisgrace&q='),
    499: ('Sadistic Rope', 'http://www.kink.com', '/search?channelIds=sadisticrope&q='),
    500: ('Sex and Submission', 'http://www.kink.com', '/search?channelIds=sexandsubmission&q='),
    501: ('The Training of O', 'http://www.kink.com', '/search?channelIds=thetrainingofo&q='),
    502: ('The Upper Floor', 'http://www.kink.com', '/search?channelIds=theupperfloor&q='),
    503: ('Water Bondage', 'http://www.kink.com', '/search?channelIds=waterbondage&q='),
    504: ('Everything Butt', 'http://www.kink.com', '/search?channelIds=everythingbutt&q='),
    505: ('Foot Worship', 'http://www.kink.com', '/search?channelIds=footworship&q='),
    506: ('Fucking Machines', 'http://www.kink.com', '/search?channelIds=fuckingmachines&q='),
    507: ('TS Pussy Hunters', 'http://www.kink.com', '/search?channelIds=tspussyhunters&q='),
    508: ('TS Seduction', 'http://www.kink.com', '/search?channelIds=tsseduction&q='),
    509: ('Ultimate Surrender', 'http://www.kink.com', '/search?channelIds=ultimatesurrender&q='),
    510: ('30 Minutes of Torment', 'http://www.kink.com', '/search?channelIds=30minutesoftorment&q='),
    511: ('Bound Gods', 'http://www.kink.com', '/search?channelIds=boundgods&q='),
    512: ('Bound in Public', 'http://www.kink.com', '/search?channelIds=boundinpublic&q='),
    513: ('Butt Machine Boys', 'http://www.kink.com', '/search?channelIds=buttmachineboys&q='),
    514: ('Men on Edge', 'http://www.kink.com', '/search?channelIds=menonedge&q='),
    515: ('Naked Kombat', 'http://www.kink.com', '/search?channelIds=nakedkombat&q='),
    516: ('Divine Bitches', 'http://www.kink.com', '/search?channelIds=divinebitches&q='),
    517: ('Electrosluts', 'http://www.kink.com', '/search?channelIds=electrosluts&q='),
    518: ('Men In Pain', 'http://www.kink.com', '/search?channelIds=meninpain&q='),
    519: ('Whipped Ass', 'http://www.kink.com', '/search?channelIds=whippedass&q='),
    520: ('Wired Pussy', 'http://www.kink.com', '/search?channelIds=wiredpussy&q='),
    521: ('Bound Gang Bangs', 'http://www.kink.com', '/search?channelIds=boundgangbangs&q='),
    522: ('Manuel Ferrara', 'https://www.manuelferrara.com', '/trial/search.php?query='),
    523: ('The Ass Factory', 'https://www.theassfactory.com', '/trial/search.php?query='),
    524: ('Sperm Swallowers', 'https://www.spermswallowers.com', '/trial/search.php?query='),
    525: ('Nubile Films', 'https://nubilefilms.com', '/video/'),
    526: ('Nubiles Porn', 'https://nubiles-porn.com', '/video/'),
    527: ('Step Siblings Caught', 'https://nubiles-porn.com', '/video/website/16/'),
    528: ('Moms Teach Sex', 'https://nubiles-porn.com', '/video/website/8/'),
    529: ('Bad Teens Punished', 'https://nubiles-porn.com', '/video/website/18/'),
    530: ('Princess Cum', 'https://nubiles-porn.com', '/video/website/17/'),
    531: ('Nubiles Unscripted', 'https://nubiles-porn.com', '/video/website/22/'),
    532: ('Nubiles Casting', 'https://nubiles-porn.com', '/video/website/6/'),
    533: ('Petite HD Porn', 'https://nubiles-porn.com', '/video/website/9/'),
    534: ('Driver XXX', 'https://nubiles-porn.com', '/video/website/13/'),
    535: ('Petite Ballerinas Fucked', 'https://nubiles-porn.com', '/video/website/14/'),
    536: ('Teacher Fucks Teens', 'https://nubiles-porn.com', '/video/website/15/'),
    537: ('Bountyhunter Porn', 'https://nubiles-porn.com', '/video/website/23/'),
    538: ('Daddys Lil Angel', 'https://nubiles-porn.com', '/video/website/25/'),
    539: ('My Family Pies', 'https://nubiles-porn.com', '/video/website/26/'),
    540: ('Nubiles', 'https://nubiles.net', '/video/'),
    541: ('Bratty Sis', 'https://brattysis.com', '/video/gallery/'),
    542: ('Anilos', 'https://anilos.com', '/video/'),
    543: ('Hot Crazy Mess', 'https://hotcrazymess.com', '/video/'),
    544: ('NF Busty', 'https://nfbusty.com', '/video/'),
    545: ('That Sitcom Show', 'https://thatsitcomshow.com', '/video/'),
    546: ('FuckedHard18', 'http://fuckedhard18.com', '/membersarea/search.php?st=advanced&site[]=5&qall='),
    547: ('MassageGirls18', 'http://massagegirls18.com', '/membersarea/search.php?st=advanced&site[]=4&qall='),
    548: ('BellaPass', 'https://www.bellapass.com', '/search.php?query='),
    549: ('Bryci', 'https://www.bryci.com', '/search.php?query='),
    550: ('Katie Banks', 'https://www.katiebanks.com', '/search.php?query='),
    551: ('Alexis Monroe', 'https://www.alexismonroe.com', '/search.php?query='),
    552: ('Cali Carter', 'https://www.calicarter.com', '/search.php?query='),
    553: ('Talia Shepard', 'https://www.taliashepard.com', '/search.php?query='),
    554: ('Jana Fox', 'https://www.janafox.com', '/search.php?query='),
    555: ('Monroe Lee', 'https://www.monroelee.com', '/search.php?query='),
    556: ('Aleah Jasmine', 'https://www.aleahjasmine.com', '/search.php?query='),
    557: ('Cece September', 'https://www.ceceseptember.com', '/search.php?query='),
    558: ('Hunter Leigh', 'https://www.hunterleigh.com', '/search.php?query='),
    559: ('Ava Dawn', 'https://www.avadawn.com', '/search.php?query='),
    560: ('Bella Next Door', 'https://www.bellanextdoor.com', '/search.php?query='),
    561: ('Joe Perv', 'https://www.joeperv.com', '/search.php?query='),
    562: ('HD 19', 'https://www.hd19.com', '/search.php?query='),
    563: ('Bella HD', 'https://www.bellahd.com', '/search.php?query='),
    564: ('Amateur Allure', 'https://www.amateurallure.com', '/tour/search.php?st=advanced&cat[]=5&qany='),
    565: ('Swallow Salon', 'https://www.swallowsalon.com', '/search.php?st=advanced&cat[]=5&qany='),
    566: ('Black Valley Girls', 'https://www.teamskeet.com', '/movies/'),
    567: ('Sis Loves Me', 'https://www.teamskeet.com', '/movies/'),
    568: ('Manyvids', 'https://www.manyvids.com', '/video/'),
    569: ('SinsVR', 'https://www.xsinsvr.com', '/search/'),
    570: ('StasyQ VR', 'https://www.stasyqvr.com', '/virtualreality/scene/id/'),
    571: ('First Class POV', 'https://www.spizoo.com', '/search.php?query='),
    572: ('Intimate Lesbians', 'https://www.spizoo.com', '/search.php?query='),
    573: ('The Stripper Experience', 'https://www.spizoo.com', '/search.php?query='),
    574: ('Porn Goes Pro', 'https://www.spizoo.com', '/search.php?query='),
    575: ('Jessica Jaymes XXX', 'https://www.spizoo.com', '/search.php?query='),
    576: ('Pornstar Tease', 'https://www.spizoo.com', '/search.php?query='),
    577: ('Raw Attack', 'https://www.rawattack.com', '/search.php?query='),
    578: ('CzechVR', 'https://www.czechvr.com', '/model-'),
    579: ('CzechVR Fetish', 'https://www.czechvrfetish.com', '/model-'),
    580: ('CzechVR Casting', 'https://www.czechvrcasting.com', '/model-'),
    581: ('Slut Stepmom', 'https://naughtyamerica.com', '/search?term='),
    582: ('ZZ Series', 'http://www.brazzers.com', 'https://site-api.project1service.com'),
    583: ('Latina Sex Tapes', 'https://www.mofos.com', 'https://site-api.project1service.com'),
    584: ('Mano Job', 'https://www.finishesthejob.com', '/search?search='),
    585: ('The Dick Suckers', 'https://www.finishesthejob.com', '/search?search='),
    586: ('Mister POV', 'https://www.finishesthejob.com', '/search?search='),
    587: ('4K Desire', 'https://www.wankz.com', '/search?q='),
    588: ('All Interracial', 'https://www.wankz.com', '/search?q='),
    589: ('Bang My Stepmom', 'https://www.wankz.com', '/search?q='),
    590: ('Big Tits Like Big Dicks', 'https://www.wankz.com', '/search?q='),
    591: ('Bubbly Massage', 'https://www.wankz.com', '/search?q='),
    592: ('Cougar Sex Club', 'https://www.wankz.com', '/search?q='),
    593: ('Ebony Internal', 'https://www.wankz.com', '/search?q='),
    594: ('Escort Trick', 'https://www.wankz.com', '/search?q='),
    595: ('Exploited 18', 'https://www.wankz.com', '/search?q='),
    596: ('Handjob Harry', 'https://www.wankz.com', '/search?q='),
    597: ('I am Eighteen', 'https://www.wankz.com', '/search?q='),
    598: ('Lesbian Sistas', 'https://www.wankz.com', '/search?q='),
    599: ('Make Them Gag', 'https://www.wankz.com', '/search?q='),
    600: ('My Milf Boss', 'https://www.wankz.com', '/search?q='),
    601: ('Not So Innocent Teens', 'https://www.wankz.com', '/search?q='),
    602: ('Rap Video Auditions', 'https://www.wankz.com', '/search?q='),
    603: ('Real Blowjob Auditions', 'https://www.wankz.com', '/search?q='),
    604: ('Round Juicy Butts', 'https://www.wankz.com', '/search?q='),
    605: ('Schoolgirl Internal', 'https://www.wankz.com', '/search?q='),
    606: ('Service Whores', 'https://www.wankz.com', '/search?q='),
    607: ('Sex For Grades', 'https://www.wankz.com', '/search?q='),
    608: ('Spoiled Slut', 'https://www.wankz.com', '/search?q='),
    609: ('Swallow For Cash', 'https://www.wankz.com', '/search?q='),
    610: ('Tight Holes Big Poles', 'https://www.wankz.com', '/search?q='),
    611: ('Wank My Wood', 'https://www.wankz.com', '/search?q='),
    612: ('Wankz TV', 'https://www.wankz.com', '/search?q='),
    613: ('Whale Tailn', 'https://www.wankz.com', '/search?q='),
    614: ('Wild Massage', 'https://www.wankz.com', '/search?q='),
    615: ('XXX At Work', 'https://www.wankz.com', '/search?q='),
    616: ('Young Dirty Lesbians', 'https://www.wankz.com', '/search?q='),
    617: ('Young Sluts Hardcore', 'https://www.wankz.com', '/search?q='),
    618: ('Matrix Models', 'https://www.wankz.com', '/search?q='),
    619: ('Blow Patrol', 'https://www.wankz.com', '/search?q='),
    620: ('Sleazy Stepdad', 'https://naughtyamerica.com', '/search?term='),
    621: ('SexArt', 'https://www.sexart.com', '/api'),
    622: ('TheLifeErotic', 'https://www.thelifeerotic.com', '/api'),
    623: ('VivThomas', 'https://www.vivthomas.com', '/api'),
    624: ('Baeb', 'http://baeb.com', '/api'),
    625: ('Open Family', 'https://naughtyamerica.com', '/search?term='),
    626: ('Family Strokes', 'https://www.teamskeet.com', '/movies/'),
    627: ('Tonights Girlfriend', 'https://www.tonightsgirlfriend.com', '/pornstar/'),
    628: ('KarupsPC', 'https://www.karups.com', '/models/search/'),
    629: ('KarupsHA', 'https://www.karups.com', '/models/search/'),
    630: ('KarupsOW', 'https://www.karups.com', '/models/search/'),
    631: ('Teen Mega World', 'http://teenmegaworld.net', '/search.php?query='),
    632: ('18 First Sex', 'http://teenmegaworld.net', '/search.php?query='),
    633: ('ATMovs', 'http://teenmegaworld.net', '/search.php?query='),
    634: ('About Girls Love', 'http://teenmegaworld.net', '/search.php?query='),
    635: ('Anal Angels', 'http://anal-angels.com', '/search.php?query='),
    636: ('Anal Beauty', 'http://anal-beauty.com', '/search.php?query='),
    637: ('Beauty 4K', 'http://beauty4k.com', '/search.php?query='),
    638: ('BeautyAngels', 'http://beauty-angels.com', '/search.php?query='),
    639: ('Coeds Reality', 'http://teenmegaworld.net', '/search.php?query='),
    640: ('Creampie Angels', 'http://creampie-angels.com', '/search.php?query='),
    641: ('Dirty Coach', 'http://dirty-coach.com', '/search.php?query='),
    642: ('Dirty Doctor', 'http://dirty-doctor.com', '/search.php?query='),
    643: ('el Porno Latino', 'http://teenmegaworld.net', '/search.php?query='),
    644: ('ExGfBox', 'http://teenmegaworld.net', '/search.php?query='),
    645: ('First BGG', 'http://firstbgg.com', '/search.php?query='),
    646: ('Fuck Studies', 'http://fuckstudies.com', '/search.php?query='),
    647: ('Gag N Gape', 'http://gag-n-gape.com', '/search.php?query='),
    648: ('Home Teen Vids', 'http://teenmegaworld.net', '/search.php?query='),
    649: ('Home Toy Teens', 'http://teenmegaworld.net', '/search.php?query='),
    650: ('Lolly Hardcore', 'http://lollyhardcore.com', '/search.php?query='),
    651: ('No Boring', 'http://noboring.com', '/search.php?query='),
    652: ('Nubile Girls HD', 'http://nubilegirlshd.com', '/search.php?query='),
    653: ('NylonsX', 'http://teenmegaworld.net', '/search.php?query='),
    654: ('Old N Young', 'http://old-n-young.com', '/search.php?query='),
    655: ('Private Teen Video', 'http://teenmegaworld.net', '/search.php?query='),
    656: ('Solo Teen Girls', 'http://soloteengirls.net', '/search.php?query='),
    657: ('Squirting Virgin', 'http://teenmegaworld.net', '/search.php?query='),
    658: ('Teen Sex Mania', 'http://teensexmania.com', '/search.php?query='),
    659: ('Teen Stars Only', 'http://teenmegaworld.net', '/search.php?query='),
    660: ('Teens 3 Some', 'http://teenmegaworld.net', '/search.php?query='),
    661: ('TmwVRnet', 'http://teenmegaworld.net', '/search.php?query='),
    662: ('Tricky Masseur', 'http://trickymasseur.com', '/search.php?query='),
    663: ('WOW Orgasms', 'http://teenmegaworld.net', '/search.php?query='),
    664: ('Watch Me Fucked', 'http://teenmegaworld.net', '/search.php?query='),
    665: ('X Angels', 'http://x-angels.com', '/search.php?query='),
    666: ('Teen Sex Movs', 'http://teensexmovs.com', '/search.php?query='),
    667: ('PJGirls', 'http://www.pjgirls.com', '/en/videos/?fulltext='),
    668: ('Screwbox', 'https://screwbox.com', '/search.php?query='),
    669: ('Dorcel Club', 'https://www.dorcelclub.com', '/en/search?s='),
    670: ('TushyRaw', 'https://www.tushyraw.com', '/graphql'),
    671: ('Deeper', 'https://www.deeper.com', '/graphql'),
    672: ('MissaX', 'https://missax.com', '/tour/search.php?query='),
    673: ('AllHerLuv', 'https://allherluv.com', '/tour/search.php?query='),
    674: ('Mylf', 'https://www.mylf.com', '/movies/'),
    675: ('MylfBoss', 'https://www.mylf.com', '/movies/'),
    676: ('MylfBlows', 'https://www.mylf.com', '/movies/'),
    677: ('Milfty', 'https://www.mylf.com', '/movies/'),
    678: ('Got Mylf', 'https://www.mylf.com', '/movies/'),
    679: ('Mom Drips', 'https://www.mylf.com', '/movies/'),
    680: ('Mylfed', 'https://www.mylf.com', '/movies/'),
    681: ('Milf Body', 'https://www.mylf.com', '/movies/'),
    682: ('Lone Milf', 'https://www.mylf.com', '/movies/'),
    683: ('Full Of JOI', 'https://www.mylf.com', '/movies/'),
    684: ('ManualAddActors', '', ''),
    685: ('First Anal Quest', 'http://www.firstanalquest.com', '/search/?q='),
    686: ('PervMom', 'https://www.teamskeet.com', '/movies/'),
    687: ('Chantas Bitches', 'http://www.kink.com', '/search?channelIds=chantasbitches&q='),
    688: ('Hegre', 'http://www.hegre.com', '/search?q='),
    689: ('Femdom Empire', 'https://femdomempire.com', '/tour/search.php?st=advanced&qany='),
    690: ('Day With a Pornstar', 'http://www.brazzers.com', 'https://site-api.project1service.com'),
    691: ('Watch Your Mom', 'https://naughtyamerica.com', '/search?term='),
    692: ('Butt Plays', 'http://www.21sextury.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    693: ('Dorcel Vision', 'https://www.dorcelvision.com', '/en/search?type=4&keyword='),
    694: ('Feminized', 'http://feminized.com', '/tour/search.php?st=advanced&qany='),
    695: ('XConfessions', 'https://api.xconfessions.com', '/api/search'),
    696: ('Czech Amateurs', 'https://czechamateurs.com', '/tour/search/?q='),
    697: ('Czech Bangbus', 'https://czechbangbus.com', '/tour/search/?q='),
    698: ('Czech Bitch', 'https://czechbitch.com', '/tour/search/?q='),
    699: ('Czech Cabins', 'https://czechcabins.com', '/tour/search/?q='),
    700: ('Czech Couples', 'https://czechcouples.com', '/tour/search/?q='),
    701: ('Czech Dungeon', 'https://czechdungeon.com', '/tour/search/?q='),
    702: ('Czech Estrogenolit', 'https://czechestrogenolit.com', '/tour/search/?q='),
    703: ('Czech Experiment', 'https://czechexperiment.com', '/tour/search/?q='),
    704: ('Czech Fantasy', 'https://czechfantasy.com', '/tour/search/?q='),
    705: ('Czech First Video', 'https://czechfirstvideo.com', '/tour/search/?q='),
    706: ('Czech Game', 'https://czechgame.com', '/tour/search/?q='),
    707: ('Czech Gangbang', 'https://czechgangbang.com', '/tour/search/?q='),
    708: ('Czech Garden Party', 'https://czechgardenparty.com', '/tour/search/?q='),
    709: ('Czech Harem', 'https://czechharem.com', '/tour/search/?q='),
    710: ('Czech Home Orgy', 'https://czechhomeorgy.com', '/tour/search/?q='),
    711: ('Czech Lesbians', 'https://czechlesbians.com', '/tour/search/?q='),
    712: ('Czech Massage', 'https://czechmassage.com', '/tour/search/?q='),
    713: ('Czech Mega Swingers', 'https://czechmegaswingers.com', '/tour/search/?q='),
    714: ('Czech Orgasm', 'https://czechorgasm.com', '/tour/search/?q='),
    715: ('Czech Parties', 'https://czechparties.com', '/tour/search/?q='),
    716: ('Czech Pawn Shop', 'https://czechpawnshop.com', '/tour/search/?q='),
    717: ('Czech Pool', 'https://czechpool.com', '/tour/search/?q='),
    718: ('Czech Sauna', 'https://czechsauna.com', '/tour/search/?q='),
    719: ('Czech Sharking', 'https://czechsharking.com', '/tour/search/?q='),
    720: ('Czech Snooper', 'https://czechsnooper.com', '/tour/search/?q='),
    721: ('Czech Solarium', 'https://czechsolarium.com', '/tour/search/?q='),
    722: ('Czech Spy', 'https://czechspy.com', '/tour/search/?q='),
    723: ('Czech Streets', 'https://czechstreets.com', '/tour/search/?q='),
    724: ('Czech Super Models', 'https://czechsupermodels.com', '/tour/search/?q='),
    725: ('Czech Taxi', 'https://czechtaxi.com', '/tour/search/?q='),
    726: ('Czech Toilets', 'https://czechtoilets.com', '/tour/search/?q='),
    727: ('Czech Twins', 'https://czechtwins.com', '/tour/search/?q='),
    728: ('Czech Wife Swap', 'https://czechwifeswap.com', '/tour/search/?q='),
    729: ('ArchAngel', 'https://www.archangelvideo.com', '/tour/search.php?query='),
    730: ('We Are Hairy', 'https://www.wearehairy.com', '/search/?query='),
    731: ('Love Her Feet', 'https://www.loveherfeet.com', '/tour/search.php?query='),
    732: ('MomPOV', 'http://www.mompov.com', '/tour/?s='),
    733: ('Property Sex', 'https://www.propertysex.com', 'https://site-api.project1service.com'),
    734: (),
    735: ('Fucked and Bound', 'http://www.kink.com', '/search?channelIds=fuckedandbound&q='),
    736: ('Captive Male', 'http://www.kink.com', '/search?channelIds=captivemale&q='),
    737: ('TransAngels', 'https://www.transangels.com', 'https://site-api.project1service.com'),
    738: ('Girls Gone Pink', 'https://www.mofos.com', 'https://site-api.project1service.com'),
    739: ('Real Slut Party', 'https://www.mofos.com', 'https://site-api.project1service.com'),
    740: ('Mofos Lab', 'https://www.mofos.com', 'https://site-api.project1service.com'),
    741: ('Straplezz', 'https://straplezz.com', '/api'),
    742: ('LittleCaprice', 'https://www.littlecaprice-dreams.com', '/?s='),
    743: ('WowGirls', 'https://www.wowgirlsblog.com', '/?s='),
    744: ('VIPissy', 'https://www.vipissy.com', '/updates?search='),
    745: ('GirlsOutWest', 'https://tour.girlsoutwest.com', '/trailers/'),
    746: ('Girls Rimming', 'https://www.girlsrimming.com', '/tour/trailers/'),
    747: ('Gangbang Creampie', 'https://www.gangbangcreampie.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    749: ('Show My BF', 'https://naughtyamerica.com', '/search?term='),
    748: ('DadCrush', 'https://www.teamskeet.com', '/movies/'),
    750: ('POV Massage', 'http://www.fantasymassage.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    751: ('Step Secrets', 'http://www.stepsecrets.com', 'https://www.stepsecrets.com/?query='),
    752: ('VRHush', 'https://www.vrhush.com', '/scenes/'),
    753: ('MetArt', 'https://www.metart.com', '/api'),
    754: ('MetArtX', 'https://www.metartx.com', '/api'),
    755: ('Nubiles ET', 'https://nubileset.com', '/video/'),
    756: ('Detention Girls', 'https://detentiongirls.com', '/video/'),
    757: ('Mylfdom', 'https://www.mylf.com', '/movies/'),
    758: ('Fitting-Room', 'https://www.fitting-room.com', '/videos/'),
    759: ('FamilyHookups', 'https://www.familyhookups.com', 'https://site-api.project1service.com'),
    760: ('Clips4Sale', 'https://www.clips4sale.com', '/studio/'),
    761: ('VogoV', 'https://vogov.com', '/search/?q='),
    762: ('UltraFilms', 'https://www.ultrafilms.xxx', '/?s='),
    763: ('FuckingAwesome', 'https://fuckingawesome.com', '/search/videos/'),
    764: ('ToughLoveX', 'https://tour.toughlovex.com', '/search/'),
    765: ('CumLouder', 'https://www.cumlouder.com', '/search?q='),
    766: ('Deep Lush', 'https://deeplush.com', '/video/'),
    767: ('AllAnal', 'https://tour.allanal.com', '/_next/data/'),
    768: ('TurningTwistys', 'https://www.twistys.com', 'https://site-api.project1service.com'),
    769: ('GirlCum', 'https://girlcum.com', '/api'),
    770: ('Zero Tolerance', 'http://www.zerotolerancefilms.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    771: ('ClubFilly', 'http://www.clubfilly.com', '/scenefocus.php?vnum=V'),
    772: ('Insex', 'https://www.insexondemand.com', '/iod/home.php?s='),
    773: ('Sexuallybroken', 'https://www.insexondemand.com', '/iod/home.php?d=sexuallybroken.com&s='),
    774: ('Infernalrestraints', 'https://www.insexondemand.com', '/iod/home.php?d=infernalrestraints.com&s='),
    775: ('Realtimebondage', 'https://www.insexondemand.com', '/iod/home.php?d=realtimebondage.com&s='),
    776: ('Hardtied', 'https://www.insexondemand.com', '/iod/home.php?d=hardtied.com&s='),
    777: ('Topgrl', 'https://www.insexondemand.com', '/iod/home.php?d=topgrl.com&s='),
    778: ('Sensualpain', 'https://www.insexondemand.com', '/iod/home.php?d=sensualpain.com&s='),
    779: ('Paintoy', 'https://www.insexondemand.com', '/iod/home.php?d=paintoy.com&s='),
    780: ('Renderfiend', 'https://www.insexondemand.com', '/iod/home.php?d=renderfiend.com&s='),
    781: ('Hotelhostages', 'https://www.insexondemand.com', '/iod/home.php?d=hotelhostages.com&s='),
    782: ('GirlGirl', 'https://www.girlgirl.com', '/trial/search.php?query='),
    783: ('Cherry Pimps', 'https://www.cherrypimps.com', '/search.php?query='),
    784: ('Wild On Cam', 'https://www.wildoncam.com', '/search.php?query='),
    785: ('Cherry Spot', 'https://www.cherrypimps.com', '/search.php?query='),
    786: ('Britney Amber', 'https://www.cherrypimps.com', '/search.php?query='),
    787: ('Confessions.XXX', 'https://www.cherrypimps.com', '/search.php?query='),
    788: ('Cucked.XXX', 'https://www.cherrypimps.com', '/search.php?query='),
    789: ('Drilled.XXX', 'https://www.cherrypimps.com', '/search.php?query='),
    790: ('BCM.XXX', 'https://www.cherrypimps.com', '/search.php?query='),
    791: ('Petite.XXX', 'https://www.cherrypimps.com', '/search.php?query='),
    792: ('Family', 'https://www.cherrypimps.com', '/search.php?query='),
    793: ('Wicked', 'https://www.wicked.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    794: ('18 Only Girls', 'https://www.18onlygirlsblog.com', '/?s='),
    795: ('GirlCore', 'https://www.girlsway.com', '/en/video/1/1/'),
    796: ('Moms On Moms', 'https://www.girlsway.com', '/en/video/1/1/'),
    797: ('We Like Girls', 'https://www.girlsway.com', '/en/video/1/1/'),
    798: ('Lil Humpers', 'https://www.realitykings.com', 'https://site-api.project1service.com'),
    799: ('Bellesa Films', 'https://bellesaplus.co', 'https://bellesaplus.co/api/rest/v1'),
    800: ('ClubSweethearts', 'https://adultprime.com', '/studios/search?type='),
    801: (),
    802: ('Family Sinners', 'https://www.familysinners.com', 'https://site-api.project1service.com'),
    803: ('ReidMyLips', 'https://www.reidmylips.com', '/updates/'),
    804: ('Playboy Plus', 'https://www.playboyplus.com', '/search'),
    805: ('Meana Wolf', 'https://meanawolf.elxcomplete.com', '/search.php?query='),
    806: ('Transsensual', 'https://www.transsensual.com', 'https://site-api.project1service.com'),
    807: ('DaughterSwap', 'https://www.teamskeet.com', '/movies/'),
    808: ('Erito', 'https://www.erito.com', 'https://site-api.project1service.com'),
    809: ('True Amateurs', 'https://www.trueamateurs.com', 'https://site-api.project1service.com'),
    810: ('Hustler', 'https://hustler.com', '/api'),
    811: ('AmourAngels', 'http://www.amourangels.com', '/z_cover_'),
    812: (),
    813: ('Bang', 'https://www.bang.com', '/videos?term='),
    814: ('Vivid', 'https://www.vivid.com', '/'),
    815: ('JAYs POV', 'https://jayspov.net', '/MemberSceneSearch?q='),
    816: ('Errotica Archives', 'https://www.errotica-archives.com', '/api'),
    817: ('ALS Scan', 'https://www.alsscan.com', '/api'),
    818: ('Rylsky Art', 'https://www.rylskyart.com', '/api'),
    819: ('Eternal Desire', 'https://www.eternaldesire.com', '/api'),
    820: ('Stunning18', 'https://www.stunning18.com', '/api'),
    821: ('Love Hairy', 'https://www.lovehairy.com', '/api'),
    822: ('GF Revenge', 'https://www.realitykings.com', 'https://site-api.project1service.com'),
    823: ('Black GFs', 'https://www.realitykings.com', 'https://site-api.project1service.com'),
    824: ('Dare Dorm', 'https://www.realitykings.com', 'https://site-api.project1service.com'),
    825: ('Crazy Asian GFs', 'https://www.realitykings.com', 'https://site-api.project1service.com'),
    826: ('Crazy College GFs', 'https://www.realitykings.com', 'https://site-api.project1service.com'),
    827: ('Horny Birds', 'https://www.realitykings.com', 'https://site-api.project1service.com'),
    828: ('Reckless in Miami', 'https://www.realitykings.com', 'https://site-api.project1service.com'),
    829: ('AmateurCFNM', 'https://www.amateurcfnm.com', '/models/'),
    830: ('PureCFNM', 'https://www.purecfnm.com', '/models/'),
    831: ('CFNMGames', 'https://www.cfnmgames.com', '/models/'),
    832: ('GirlsAbuseGuys', 'https://www.girlsabuseguys.com', '/models/'),
    833: ('HeyLittleDick', 'https://www.heylittledick.com', '/models/'),
    834: ('LadyVoyeurs', 'https://www.ladyvoyeurs.com', '/models/'),
    835: ('BAMVisions', 'https://tour.bamvisions.com', '/search.php?st=advanced&qall='),
    836: ('ATKGirlfriends', 'https://www.atkgirlfriends.com', '/tour/model/'),
    837: ('WankItNow', 'https://www.wankitnow.com', '/videos'),
    838: ('BoppingBabes', 'https://www.boppingbabes.com', '/videos'),
    839: ('UpskirtJerk', 'https://www.upskirtjerk.com', '/videos'),
    840: ('Interracial Pass', 'https://www.interracialpass.com', '/t1/search.php?query='),
    841: ('LookAtHerNow', 'https://www.lookathernow.com', 'https://site-api.project1service.com'),
    842: ('Mylfwood', 'https://www.mylf.com', '/movies/'),
    843: ('AllBlackX', 'https://www.xempire.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    844: ('BBCPie', 'https://bbcpie.com', '/api'),
    845: ('Foster Tapes', 'https://www.teamskeet.com', '/movies/'),
    846: ('BFFs', 'https://www.teamskeet.com', '/movies/'),
    847: ('Shoplyfter', 'https://www.teamskeet.com', '/movies/'),
    848: ('ShoplyfterMylf', 'https://www.teamskeet.com', '/movies/'),
    849: ('Little Asians', 'https://www.teamskeet.com', '/movies/'),
    850: ('Thickumz', 'https://www.teamskeet.com', '/movies/'),
    851: ('Teens Love Black Cocks', 'https://www.teamskeet.com', '/movies/'),
    852: ('Bi Empire', 'http://www.biempire.com', 'https://site-api.project1service.com'),
    853: ('Mylf X Joybear', 'https://www.mylf.com', '/movies/'),
    854: ('Mylf X Teamskeet', 'https://www.mylf.com', '/movies/'),
    855: ('Mylf X Hussie Pass', 'https://www.mylf.com', '/movies/'),
    856: ('Mylf Of The Month', 'https://www.mylf.com', '/movies/'),
    857: ('Mylfselects', 'https://www.mylf.com', '/movies/'),
    858: ('Mylf X Lady Fyre', 'https://www.mylf.com', '/movies/'),
    859: ('Deviant Hardcore', 'https://www.devianthardcore.com', 'https://site-api.project1service.com'),
    860: ('She Will Cheat', 'https://www.shewillcheat.com', 'https://site-api.project1service.com'),
    861: ('My XXX Pass', 'http://www.blowpass.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    862: ('SinsLife', 'https://sinslife.com', '/tour/search.php?query='),
    863: ('Wet and Pissy', 'https://www.puffynetwork.com', '/videos?search='),
    864: ('Pissing In Action', 'https://www.sinx.com', '/videos/all?sexualOrientation=0&searchWord='),
    865: ('Golden Shower Power', 'https://www.sinx.com', '/videos/all?sexualOrientation=0&searchWord='),
    866: ('Fully Clothed Pissing', 'https://www.sinx.com', '/videos/all?sexualOrientation=0&searchWord='),
    867: ('Simply Anal', 'https://www.puffynetwork.com', '/videos?search='),
    868: ('Wet and Puffy', 'https://www.puffynetwork.com', '/videos?search='),
    869: ('We Like To Suck', 'https://www.puffynetwork.com', '/videos?search='),
    870: ('Euro Babe Facials', 'https://www.puffynetwork.com', '/videos?search='),
    871: ('Slime Wave', 'https://www.sinx.com', '/videos/all?sexualOrientation=0&searchWord='),
    872: ('Kinky Spa', 'https://www.kinkyspa.com', 'https://site-api.project1service.com'),
    873: ('SubmissiveX', 'http://www.kink.com', '/search?channelIds=submissivex&q='),
    874: ('Filthy Femdom', 'http://www.kink.com', '/search?channelIds=filthyfemdom&q='),
    875: ('Anal Mom', 'https://www.teamskeet.com', '/movies/'),
    876: ('Bellesa House', 'https://bellesaplus.co', 'https://bellesaplus.co/api/rest/v1'),
    877: ('Reality Lovers', 'https://realitylovers.com', '/videos/search'),
    878: ('Adult Time', 'https://adulttime.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    879: ('RealJamVR', 'https://realjamvr.com', '/scene/'),
    880: ('BBC Paradise', 'https://www.bbcparadise.com', '/movies/'),
    881: ('Mylf X CamSoda', 'https://www.mylf.com', '/movies/'),
    882: ('Mylf X Fucking Awesome', 'https://www.mylf.com', '/movies/'),
    883: ('Mylf X James Deen', 'https://www.mylf.com', '/movies/'),
    884: ('Mylf X Mindi Mink', 'https://www.mylf.com', '/movies/'),
    885: ('Mylf X Owen Gray', 'https://www.mylf.com', '/movies/'),
    886: ('Mylf X SpankMonster', 'https://www.mylf.com', '/movies/'),
    887: ('StayHomeMilf', 'https://www.mylf.com', '/movies/'),
    888: ('Kink Evolved Fights Lesbian Edition', 'http://www.kink.com', '/search?channelIds=evolvedfightslesbianedition&q='),
    889: ('Kink Evolved Fights', 'http://www.kink.com', '/search?channelIds=evolvedfights&q='),
    890: ('WetVR', 'https://wetvr.com', '/api'),
    891: ('HoloGirlsVR', 'https://www.hologirlsvr.com', '/Scenes?back=1&search='),
    892: (),
    893: ('Gender X', 'https://www.genderxfilms.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    894: (),
    895: ('Defeated XXX', 'http://xxx.defeated.xxx', '/?s='),
    896: ('Defeated Sex Fight', 'https://defeatedsexfight.com', '/?s='),
    897: ('XVirtual', 'https://xvirtual.com', '/tour/search/?q='),
    898: ('Lust Reality', 'https://www.lustreality.com', '/virtualreality/scene/id/'),
    899: ('Sex Like Real', 'https://www.sexlikereal.com', '/scenes/'),
    900: ('Doe Girls', 'https://doegirls.com', 'https://site-api.project1service.com'),
    901: ('Xillimite', 'https://www.xillimite.com', '/en/search?type=4&keyword='),
    902: ('VRPFilms', 'https://vrpfilms.com', '/m/'),
    903: ('VR Latina', 'https://vrlatina.com', '/video/'),
    904: ('VRConk', 'https://www.vrconk.com', '/api/content/v1/search/'),
    905: (),
    906: ('Evolved Fights', 'https://www.evolvedfights.com', '/updates/'),
    907: ('Evolved Fights Lesbian Edition', 'https://www.evolvedfightslez.com', '/updates/'),
    908: ('SapphiX', 'https://sapphix.com', '/movies?q='),
    909: ('Sapphic Erotica', 'https://sapphix.com', '/movies?site[]=se&q='),
    910: ('Give Me Pink', 'https://sapphix.com', '/movies?site[]=gmp&q='),
    911: ('Fist Flush', 'https://sapphix.com', '/movies?site[]=ff&q='),
    912: ('JavBus', 'https://www.javbus.com', '/en/'),
    913: ('Hucows', 'https://www.hucows.com', '/'),
    914: ('Mile High Media', 'https://milehighmedia.com', 'https://site-api.project1service.com'),
    915: ('Mile High', 'https://milehighmedia.com', 'https://site-api.project1service.com'),
    916: ('Why Not Bi', 'https://whynotbi.com', 'https://site-api.project1service.com'),
    917: ('HentaiPros', 'https://hentaipros.com', 'https://site-api.project1service.com'),
    918: ('3dxstar Channel PornPortal', 'https://3dxstar-channel.pornportal.com', 'https://site-api.project1service.com'),
    919: ('Cosplay Channel PornPortal', 'https://cosplay-channel.pornportal.com', 'https://site-api.project1service.com'),
    920: ('Ebony Channel PornPortal', 'https://ebony-channel.pornportal.com', 'https://site-api.project1service.com'),
    921: ('Latina Channel PornPortal', 'https://latina-channel.pornportal.com', 'https://site-api.project1service.com'),
    922: ('Teen Channel PornPortal', 'https://teen-channel.pornportal.com', 'https://site-api.project1service.com'),
    923: ('Milf Channel PornPortal', 'https://milf-channel.pornportal.com', 'https://site-api.project1service.com'),
    924: ('Stepfamily Channel PornPortal', 'https://stepfamily-channel.pornportal.com', 'https://site-api.project1service.com'),
    925: ('Lesbian Channel PornPortal', 'https://lesbian-channel.pornportal.com', 'https://site-api.project1service.com'),
    926: ('RealityGang Channel PornPortal', 'https://realitygang-channel.pornportal.com', 'https://site-api.project1service.com'),
    927: ('Anal Channel PornPortal', 'https://anal-channel.pornportal.com', 'https://site-api.project1service.com'),
    928: ('BBW Channel PornPortal', 'https://bbw-channel.pornportal.com', 'https://site-api.project1service.com'),
    929: ('VR Channel PornPortal', 'https://vr-channel.pornportal.com', 'https://site-api.project1service.com'),
    930: ('Raw Couples', 'http://rawcouples.com', '/search.php?query='),
    931: ('All Anal All The Time', 'https://www.allanalallthetime.com', '/videos/'),
    932: ('QueenSnake', 'https://queensnake.com', '/previewmovie/'),
    933: ('QueenSect', 'https://queensect.com', '/previewmovie/'),
    934: ('StraponSquad', 'http://www.kink.com', '/search?channelIds=straponsquad&q='),
    935: ('SexualDisgrace', 'http://www.kink.com', '/search?channelIds=sexualdisgrace&q='),
    936: ('FetishNetwork', 'http://www.kink.com', '/search?channelIds=fetishnetwork&q='),
    937: ('FetishNetwork Male', 'http://www.kink.com', '/search?channelIds=fetishnetworkmale&q='),
    938: ('ScrewMeToo', 'https://screwmetoo.com', '/?amp=1&s='),
    939: (),
    940: ('Aussie Ass', 'https://www.aussieass.com', '/models/'),
    941: ('5Kporn', 'https://www.5kporn.com', '/episodes/search?search='),
    942: ('5Kteens', 'https://www.5kporn.com', '/episodes/search?search='),
    943: ('Analyzed Girls', 'https://api.fundorado.com', '/api/'),
    944: ('Ass Teen Mouth', 'https://api.fundorado.com', '/api/'),
    945: ('Bang Teen Pussy', 'https://api.fundorado.com', '/api/'),
    946: ('Brutal Invasion', 'https://api.fundorado.com', '/api/'),
    947: ('Cumoholic Teens', 'https://api.fundorado.com', '/api/'),
    948: ('Defiled 18', 'https://api.fundorado.com', '/api/'),
    949: ('Double Teamed Teens', 'https://api.fundorado.com', '/api/'),
    950: ('Dream Teens HD', 'https://api.fundorado.com', '/api/'),
    951: ('Girls Got Cream', 'https://api.fundorado.com', '/api/'),
    952: ('Hardcore Youth', 'https://api.fundorado.com', '/api/'),
    953: ('Little Hellcat', 'https://api.fundorado.com', '/api/'),
    954: ('Make Teen Gape', 'https://api.fundorado.com', '/api/'),
    955: ('Nylon Sweeties', 'https://api.fundorado.com', '/api/'),
    956: ('Seductive 18', 'https://api.fundorado.com', '/api/'),
    957: ('Teen Anal Casting', 'https://api.fundorado.com', '/api/'),
    958: ('Teen Drillers', 'https://api.fundorado.com', '/api/'),
    959: ('Teens Natural Way', 'https://api.fundorado.com', '/api/'),
    960: ('Teens Try Blacks', 'https://api.fundorado.com', '/api/'),
    961: ('Spermatino', 'https://api.fundorado.com', '/api/'),
    962: ('Teach My Ass', 'https://api.fundorado.com', '/api/'),
    963: ('Drilled Chicks', 'https://api.fundorado.com', '/api/'),
    964: ('Anal Checkups', 'https://api.fundorado.com', '/api/'),
    965: ('Fab Sluts', 'https://api.fundorado.com', '/api/'),
    966: ('Jerk-Off Pass', 'https://api.fundorado.com', '/api/'),
    967: ('Nylon Spunk Junkies', 'https://api.fundorado.com', '/api/'),
    968: ('She Got Six', 'https://api.fundorado.com', '/api/'),
    969: ('Spear Teen Pussy', 'https://api.fundorado.com', '/api/'),
    970: ('Teen Core Club', 'https://api.fundorado.com', '/api/'),
    971: ('Teen Core Zine', 'https://api.fundorado.com', '/api/'),
    972: ('Teens Go Porn', 'https://api.fundorado.com', '/api/'),
    973: ('We Need New Talents', 'https://api.fundorado.com', '/api/'),
    974: ('X Core Club', 'https://api.fundorado.com', '/api/'),
    975: ('Blackmailed', 'https://www.evilangel.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    976: ('Backroom Casting Couch', 'https://backroomcastingcouch.com', '/search.php?query='),
    977: ('BBC Surprise', 'https://bbcsurprise.com', '/search.php?query='),
    978: ('Exploited College Girls', 'https://exploitedcollegegirls.com', '/search.php?query='),
    979: ('Desperate Amateurs', 'https://desperateamateurs.com', '/fintour/search.php?st=advanced&qall='),
    980: ('Bang My Hand', 'http://www.bangmyhand.com', '/tour1/'),
    981: ('Dirty Sluts and Studs', 'http://www.dirtyharddrive.com', '/tour1/'),
    982: ('Katie Kox', 'http://www.katiekox.com', '/tour1/'),
    983: ('Sophie Dee and Friends', 'http://www.sophiedeeandfriends.com', '/tour1/'),
    984: ('Lee Bang XXX', 'http://www.leebangxxx.com', '/tour1/'),
    985: ('The Squirt Instructor', 'http://www.thesquirtinstructor.com', '/tour1/'),
    986: ('Girls In Nylon', 'http://www.girlsinnylon.com', '/tour1/'),
    987: ('Kiera King', 'http://www.kieraking.com', '/tour1/'),
    988: ('Melone Challenge', 'https://melonechallenge.com', '/'),
    989: ('Holly Randall', 'https://hollyrandall.com', '/search.php?query='),
    990: ('In The Crack', 'https://inthecrack.com', '/Collections/Name/'),
    991: ('Angela White', 'http://angelawhite.com', '/tour/search?query='),
    992: ('Cumbizz', 'https://www.cumbizz.com', '/film/'),
    993: ('Pornstar Platinum', 'https://www.pornstarplatinum.com', '/tour/index.php?search='),
    994: ('Woodman Casting X', 'https://www.woodmancastingx.com', '/search?query='),
    995: ('FamilySwapXXX', 'https://familyswap.xxx', '/video/watch/'),
    996: ('GirlsOnlyPorn', 'https://girlsonlyporn.com', '/video/watch/'),
    997: ('TeamSkeet X BAEB', 'https://www.teamskeet.com', '/movies/'),
    998: ('TeamSkeet X Banana Fever', 'https://www.teamskeet.com', '/movies/'),
    999: ('TeamSkeet X CamSoda', 'https://www.teamskeet.com', '/movies/'),
    1000: ('TeamSkeet X Club Sweethearts', 'https://www.teamskeet.com', '/movies/'),
    1001: ('TeamSkeet X Eva Elfie', 'https://www.teamskeet.com', '/movies/'),
    1002: ('TeamSkeet X Flora Rodgers', 'https://www.teamskeet.com', '/movies/'),
    1003: ('TeamSkeet X Fucking Awesome', 'https://www.teamskeet.com', '/movies/'),
    1004: ('TeamSkeet X James Deen', 'https://www.teamskeet.com', '/movies/'),
    1005: ('TeamSkeet X Joy Bear', 'https://www.teamskeet.com', '/movies/'),
    1006: ('TeamSkeet X Layna Landry', 'https://www.teamskeet.com', '/movies/'),
    1007: ('TeamSkeet X LunaXJames', 'https://www.teamskeet.com', '/movies/'),
    1008: ('TeamSkeet X Mickey Mod', 'https://www.teamskeet.com', '/movies/'),
    1009: ('TeamSkeet X OG', 'https://www.teamskeet.com', '/movies/'),
    1010: ('TeamSkeet X Reislin', 'https://www.teamskeet.com', '/movies/'),
    1011: ('TeamSkeet X SpankMonster', 'https://www.teamskeet.com', '/movies/'),
    1012: ('Porn Mega Load', 'https://www.pornmegaload.com', '/hd-porn-scenes/'),
    1013: ('Naughty Mag', 'https://www.naughtymag.com', '/amateur-videos/'),
    1014: ('XL Girls', 'https://www.xlgirls.com', '/bbw-videos/'),
    1015: ('Bootylicious Mag', 'https://www.bootyliciousmag.com', '/big-booty-videos/'),
    1016: ('50 Plus MILFS', 'https://www.50plusmilfs.com', '/xxx-milf-videos/'),
    1017: ('60 Plus MILFS', 'https://www.60plusmilfs.com', '/xxx-granny-videos/'),
    1018: ('18 Eighteen', 'https://www.18eighteen.com', '/xxx-teen-videos/'),
    1019: ('Big Boob Bundle', 'https://www.bigboobbundle.com', '/videos/'),
    1020: ('Leg Sex', 'https://www.legsex.com', '/foot-fetish-videos/'),
    1021: ('Scoreland', 'https://www.scoreland.com', '/big-boob-videos/'),
    1022: ('TwoTGirls', 'https://twotgirls.com', '/videos?query='),
    1023: ('Sicflics', 'https://www.sicflics.com', '/search/'),
    1024: ('AlettaOceanLive', 'https://www.alettaoceanlive.com', '/tour/categories/movies_%d_d.html'),
    1025: ('FallInLovia', 'https://www.fallinlovia.com', '/sapi/'),
    1026: ('RomiRain', 'https://www.romirain.com', '/sapi/'),
    1027: ('JerkOffWithMe', 'https://www.jerkoffwithme.com', '/sapi/'),
    1028: ('GetYourKneesDirty', 'https://www.getyourkneesdirty.com', '/sapi/'),
    1029: ('Nude Beauties', 'https://nudebeauties.eu', '/sapi/'),
    1030: ('Dani Daniels', 'https://danidaniels.com', '/sapi/'),
    1031: ('OfficialChloeToy', 'https://officialchloetoy.com', '/sapi/'),
    1032: ('YummyCouple', 'https://friends.yummycouple.com', '/sapi/'),
    1033: ('Katya Clover', 'https://www.katya-clover.com', '/sapi/'),
    1034: ('DeNudeArt', 'https://denudeart.com', '/sapi/'),
    1035: ('Lisey Sweet', 'https://theliseysweet.com', '/sapi/'),
    1036: ('MyLifeInMiami', 'https://mylifeinmiami.com', '/sapi/'),
    1037: ('GinaGerson', 'https://www.ginagerson.xxx', '/sapi/'),
    1038: (),
    1039: ('VinaSkyXXX', 'https://www.vinaskyxxx.com', '/sapi/'),
    1040: ('Reality Sis', 'https://nubiles-porn.com', '/video/website/73/'),
    1041: (),
    1042: (),
    1043: (),
    1044: (),
    1045: (),
    1046: (),
    1047: (),
    1048: (),
    1049: (),
    1050: (),
    1051: ('Bruce and Morgan', 'https://www.bruceandmorgan.net', '/sapi/'),
    1052: ('Busted', 'https://www.cherrypimps.com', '/search.php?query='),
    1053: ('Cheese.XXX', 'https://www.cherrypimps.com', '/search.php?query='),
    1054: ('Femme', 'https://www.cherrypimps.com', '/search.php?query='),
    1055: ('Fresh', 'https://www.cherrypimps.com', '/search.php?query='),
    1056: ('Taboo', 'https://www.cherrypimps.com', '/search.php?query='),
    1057: ('PornWorld', 'https://pornworld.com', '/search/'),
    1058: ('Vicki Valkyrie', 'https://www.vickivalkyrie.com', '/sapi/'),
    1059: ('Busted Babysitters', 'https://www.mofos.com', 'https://site-api.project1service.com'),
    1060: ('Ebony Sex Tapes', 'https://www.mofos.com', 'https://site-api.project1service.com'),
    1061: ('Milfs Like It Black', 'https://www.mofos.com', 'https://site-api.project1service.com'),
    1062: ('Project RV', 'https://www.mofos.com', 'https://site-api.project1service.com'),
    1063: ('The Sex Scout', 'https://www.mofos.com', 'https://site-api.project1service.com'),
    1064: ('Pornstar Vote', 'https://www.mofos.com', 'https://site-api.project1service.com'),
    1065: ('Mormon Girlz', 'https://mormongirlz.com', '/?s='),
    1066: ('PurgatoryX', 'https://www.purgatoryx.com', 'https://tour.purgatoryx.com/search/'),
    1067: ('PlumperPass', 'https://plumperpass.com', '/tour/search.php?q='),
    1068: ('FTVMilfs', 'https://ftvmilfs.com', '/update/s-'),
    1069: ('FTVGirls', 'https://www.ftvgirls.com', '/update/s-'),
    1070: ('Jacquie Et Michel TV', 'https://www.jacquieetmicheltv.net', '/en/content/list?search='),
    1071: ('Data18 Scenes', 'https://www.data18.com', '/sys/live.php?index=&key='),
    1072: ('Penthouse Gold', 'https://penthousegold.com', '/search.php?query='),
    1073: ('Data18 Movies', 'https://www.data18.com', '/sys/live.php?index=&key='),
    1074: ('WakeUpNFuck', 'https://www.wakeupnfuck.com', '/search?query='),
    1075: ('Dillion Nation', 'https://dillionation.com', '/sapi/'),
    1076: ('SexMex', 'https://sexmex.xxx', '/tour/search.php?query='),
    1077: ('Explicite Art', 'https://www.explicite-art.com', '/visitor/search/videos/'),
    1078: ('Black PayBack', 'https://blackpayback.com', '/tour/trailers/'),
    1079: ('Sunny Lane Live', 'https://sunnylanelive.com', '/videos/'),
    1080: ('FAKings', 'https://www.fakings.com', '/en/buscar/'),
    1081: ('Newbies Or So They Say', 'https://www.fakings.com', '/en/buscar/'),
    1082: ('Quarantine Stories', 'https://www.fakings.com', '/en/buscar/'),
    1083: ('Horsedicks', 'https://www.fakings.com', '/en/buscar/'),
    1084: ('FREE Pussy Day', 'https://www.fakings.com', '/en/buscar/'),
    1085: ('Parejas.NET', 'https://www.fakings.com', '/en/buscar/'),
    1086: ('Curvy Girls', 'https://www.fakings.com', '/en/buscar/'),
    1087: ('Next Door Girl', 'https://www.fakings.com', '/en/buscar/'),
    1088: ('FAKings PornStars', 'https://www.fakings.com', '/en/buscar/'),
    1089: ('Busted', 'https://www.fakings.com', '/en/buscar/'),
    1090: ('Fuck Them', 'https://www.fakings.com', '/en/buscar/'),
    1091: ('My First Anal', 'https://www.fakings.com', '/en/buscar/'),
    1092: ('MILF Club', 'https://www.fakings.com', '/en/buscar/'),
    1093: ('Arnaldo Series', 'https://www.fakings.com', '/en/buscar/'),
    1094: ('Free Couples', 'https://www.fakings.com', '/en/buscar/'),
    1095: ('FAKings Castings', 'https://www.fakings.com', '/en/buscar/'),
    1096: ('First FAKings', 'https://www.fakings.com', '/en/buscar/'),
    1097: ('Talk To Them', 'https://www.fakings.com', '/en/buscar/'),
    1098: ('I Sell My Girlfriend', 'https://www.fakings.com', '/en/buscar/'),
    1099: ('NERD BUSTER', 'https://www.fakings.com', '/en/buscar/'),
    1100: ('Swingers Life', 'https://www.fakings.com', '/en/buscar/'),
    1101: ('Trans FAKings', 'https://www.fakings.com', '/en/buscar/'),
    1102: ('Very Voyeur', 'https://www.fakings.com', '/en/buscar/'),
    1103: ('FAKings Academy', 'https://www.fakings.com', '/en/buscar/'),
    1104: ('The Naughty Bet', 'https://www.fakings.com', '/en/buscar/'),
    1105: ('Ainaras Diary', 'https://www.fakings.com', '/en/buscar/'),
    1106: ('FAKins Wild Party', 'https://www.fakings.com', '/en/buscar/'),
    1107: ('My First DP', 'https://www.fakings.com', '/en/buscar/'),
    1108: ('Innocent 18', 'https://www.fakings.com', '/en/buscar/'),
    1109: ('Fuck Me Fool', 'https://www.fakings.com', '/en/buscar/'),
    1110: ('Perverting Couples', 'https://www.fakings.com', '/en/buscar/'),
    1111: ('Big Rubber Cocks', 'https://www.fakings.com', '/en/buscar/'),
    1112: ('Virtual Reality', 'https://www.fakings.com', '/en/buscar/'),
    1113: ('The Anatomical Sulphate', 'https://www.fakings.com', '/en/buscar/'),
    1114: ('Exchange Student Girls', 'https://www.fakings.com', '/en/buscar/'),
    1115: ('Im a Webcam Girl', 'https://www.fakings.com', '/en/buscar/'),
    1116: ('Sick Videos', 'https://www.fakings.com', '/en/buscar/'),
    1117: ('FAKings Slutwalk', 'https://www.fakings.com', '/en/buscar/'),
    1118: ('Blowjob Lessons', 'https://www.fakings.com', '/en/buscar/'),
    1119: ('Behind FAKings', 'https://www.fakings.com', '/en/buscar/'),
    1120: ('Novatas O Eso Dicen', 'https://www.fakings.com', '/en/buscar/'),
    1121: ('Historias de Cuarentena', 'https://www.fakings.com', '/en/buscar/'),
    1122: ('Rabos de Caballo', 'https://www.fakings.com', '/en/buscar/'),
    1123: ('El Día del Coño GRATIS', 'https://www.fakings.com', '/en/buscar/'),
    1124: ('Chicas Curvis', 'https://www.fakings.com', '/en/buscar/'),
    1125: ('Es Tu Vecina', 'https://www.fakings.com', '/en/buscar/'),
    1126: ('Cazadas', 'https://www.fakings.com', '/en/buscar/'),
    1127: ('Follatelos', 'https://www.fakings.com', '/en/buscar/'),
    1128: ('Mi Primer Anal', 'https://www.fakings.com', '/en/buscar/'),
    1129: ('Club Maduras', 'https://www.fakings.com', '/en/buscar/'),
    1130: ('Parejitas Libres', 'https://www.fakings.com', '/en/buscar/'),
    1131: ('Castings de FAKings', 'https://www.fakings.com', '/en/buscar/'),
    1132: ('Hable Con Ellas', 'https://www.fakings.com', '/en/buscar/'),
    1133: ('Vendo a mi Novia', 'https://www.fakings.com', '/en/buscar/'),
    1134: ('Los Cazatolas', 'https://www.fakings.com', '/en/buscar/'),
    1135: ('Vidas Liberales', 'https://www.fakings.com', '/en/buscar/'),
    1136: ('Muy Voyeur', 'https://www.fakings.com', '/en/buscar/'),
    1137: ('La Escuela de FAKings', 'https://www.fakings.com', '/en/buscar/'),
    1138: ('Porno Dolares', 'https://www.fakings.com', '/en/buscar/'),
    1139: ('Diario de Ainara', 'https://www.fakings.com', '/en/buscar/'),
    1140: ('Fiestas FAKings', 'https://www.fakings.com', '/en/buscar/'),
    1141: ('Mi Primera DP', 'https://www.fakings.com', '/en/buscar/'),
    1142: ('Inocentes 18', 'https://www.fakings.com', '/en/buscar/'),
    1143: ('Follame Tonto', 'https://www.fakings.com', '/en/buscar/'),
    1144: ('Pervirtiendo Parejas', 'https://www.fakings.com', '/en/buscar/'),
    1145: ('Pollazas de Goma', 'https://www.fakings.com', '/en/buscar/'),
    1146: ('FAKingsVR', 'https://www.fakings.com', '/en/buscar/'),
    1147: ('El Sulfato Anatómico', 'https://www.fakings.com', '/en/buscar/'),
    1148: ('Alumnas De Intercambio', 'https://www.fakings.com', '/en/buscar/'),
    1149: ('Soy Webcamer', 'https://www.fakings.com', '/en/buscar/'),
    1150: ('Videos Enfermos', 'https://www.fakings.com', '/en/buscar/'),
    1151: ('De Paseo con FAKings', 'https://www.fakings.com', '/en/buscar/'),
    1152: ('Clases de Mamadas', 'https://www.fakings.com', '/en/buscar/'),
    1153: ('XXXPawn', 'http://bangbrosportal.com', '/?s='),
    1154: ('Black Patrol', 'http://bangbrosportal.com', '/?s='),
    1155: ('Putalocura', 'https://www.putalocura.com', '/buscar?q='),
    1156: ('Mia Khalifa', 'http://bangbrosportal.com', '/?s='),
    1157: ('Blacks On Moms', 'http://bangbrosportal.com', '/?s='),
    1158: ('Filthy Family', 'http://bangbrosportal.com', '/?s='),
    1159: ('Melena Maria Rya', 'https://www.melenamariarya.com', '/scene/'),
    1160: ('Anal Overdose', 'https://analoverdose.com', '/'),
    1161: ('Banging Beauties', 'https://www.bangingbeauties.com', '/'),
    1162: ('Chocolate BJs', 'https://www.chocolatebjs.com', '/'),
    1163: ('Oral Overdose', 'https://www.oraloverdose.com', '/'),
    1164: ('Up Her Asshole', 'https://www.upherasshole.com', '/'),
    1165: ('Perv City', 'https://www.pervcity.com', '/'),
    1166: ('Abby Winters', 'https://www.abbywinters.com', '/amateurs/models?filters%5Bkeyword%5D='),
    1167: ('Nude Girls', 'https://www.abbywinters.com', '/'),
    1168: ('Mystery Shoot', 'https://www.abbywinters.com', '/'),
    1169: ('Girl Girl', 'https://www.abbywinters.com', '/'),
    1170: ('Video Masturbation', 'https://www.abbywinters.com', '/'),
    1171: ('Abby Winters Behind the Scenes', 'https://www.abbywinters.com', '/'),
    1172: ('Abby Winters Best Of', 'https://www.abbywinters.com', '/'),
    1173: ('Guest Direction', 'https://www.abbywinters.com', '/'),
    1174: ('Girls and Their Boys', 'https://www.abbywinters.com', '/'),
    1175: ('Nude In Public', 'https://www.abbywinters.com', '/'),
    1176: ('Video Of Myself at Home', 'https://www.abbywinters.com', '/'),
    1177: ('Girls In Lingerie At Night', 'https://www.abbywinters.com', '/'),
    1178: ('Abby Winters Podcast', 'https://www.abbywinters.com', '/'),
    1179: ('Learn How to Get Women', 'https://www.abbywinters.com', '/'),
    1180: ('Tales From the Edge', 'https://thetalesfromtheedge.com', '/tour_ttfte/search.php?query='),
    1181: ('Assylum', 'https://www.assylum.com', '/'),
    1182: ('SlaveMouth', 'https://www.slavemouth.com', '/'),
    1183: ('DickDrainers', 'http://dickdrainers.com', '/tour/search.php?query='),
    1184: ('ALS Angels', 'http://www.alsangels.com', '/dailyvideos.html'),
    1185: ('Watch4Beauty', 'https://www.watch4beauty.com', '/models/'),
    1186: ('Fresh Out Of High School', 'https://freshoutofhighschool.com', '/tour_fohs/search.php?query='),
    1187: ('The Tabu Tales', 'https://thetabutales.com', '/tour_tt/search.php?query='),
    1188: ('Shane Diesel\'s Banging Babes', 'https://www.shanedieselsbanginbabes.com', '/tour_sdbb/search.php?query='),
    1189: ('The Romance Series', 'https://theromanceseries.com', '/tour_rs/search.php?query='),
    1190: ('Femjoy', 'https://femjoy.com', '/api/v2/search/videos?include=actors,directors&thumb_size=850x463&query='),
    1191: ('Lilu Moon', 'https://www.lilumoonx.com', '/sapi/'),
    1192: ('Family Lust', 'https://www.familylust.com', '/models/'),
    1193: ('Over 40 Handjobs', 'https://www.over40handjobs.com', '/models/'),
    1194: ('Ebony Tugs', 'https://ebonytugs.com', '/models/'),
    1195: ('Teen Tugs', 'https://teentugs.com', '/models/'),
    1196: ('Czech Sex Casting', 'https://www.czechsexcasting.com', '/en/search-results?value='),
    1197: ('Sex With Muslims', 'https://www.sexwithmuslims.com', '/en/search-results?value='),
    1198: ('Sex In Taxi', 'https://www.sexintaxi.com', '/en/search-results?value='),
    1199: ('VR Porn CZ', 'https://www.vrporncz.com', '/en/search-results?value='),
    1200: ('Fucking Street', 'https://www.fuckingstreet.com', '/en/search-results?value='),
    1201: ('Hunter POV', 'https://www.hunterpov.com', '/en/search-results?value='),
    1202: ('Czech Gypsies', 'https://www.czechgypsies.com', '/en/search-results?value='),
    1203: ('Dick On Trip', 'https://www.dickontrip.com', '/en/search-results?value='),
    1204: ('Czech Boobs', 'https://www.czechboobs.com', '/en/search-results?value='),
    1205: ('Czech Deviant', 'https://www.czechdeviant.com', '/en/search-results?value='),
    1206: ('Amateri Premium', 'https://www.amateripremium.com', '/en/search-results?value='),
    1207: ('Fucking Office', 'https://www.fuckingoffice.com', '/en/search-results?value='),
    1208: ('Czech Executor', 'https://www.czechexecutor.com', '/en/search-results?value='),
    1209: ('Czech Hitchhikers', 'https://www.czechhitchhikers.com', '/en/search-results?value='),
    1210: ('Girls Take Away', 'https://www.girlstakeaway.com', '/en/search-results?value='),
    1211: ('Czech Escort Girls', 'https://www.czechescortgirls.com', '/en/search-results?value='),
    1212: ('Horny Doctor', 'https://www.hornydoctor.com', '/en/search-results?value='),
    1213: ('Lady Dee', 'https://www.ladydee.com', '/en/search-results?value='),
    1214: ('Teen From Bohemia', 'https://www.teenfrombohemia.com', '/en/search-results?value='),
    1215: ('Czech Real Dolls', 'https://www.czechrealdolls.com', '/en/search-results?value='),
    1216: ('Amateur From Bohemia', 'https://www.amateursfrombohemia.com', '/en/search-results?value='),
    1217: ('Czech Anal Sex', 'https://www.czechanalsex.com', '/en/search-results?value='),
    1218: ('Dellia Twins', 'https://www.dellaitwins.com', '/en/search-results?value='),
    1219: ('Chloe Lamour', 'https://www.chloelamour.com', '/en/search-results?value='),
    1220: ('Public From Bohemia', 'https://www.publicfrombohemia.com', '/en/search-results?value='),
    1221: ('Susan Ayn', 'https://www.susanayn.com', '/en/search-results?value='),
    1222: ('Horny Girls CZ', 'https://www.hornygirlscz.com', '/en/search-results?value='),
    1223: ('Czech Sex Party', 'https://www.czechsexparty.com', '/en/search-results?value='),
    1224: ('Retro Porn CZ', 'https://www.retroporncz.com', '/en/search-results?value='),
    1225: ('Boys Fuck MILFs', 'https://www.boysfuckmilfs.com', '/en/search-results?value='),
    1226: ('Czech Bi Porn', 'https://www.czechbiporn.com', '/en/search-results?value='),
    1227: ('Czech Shemale', 'https://www.czechshemale.com', '/en/search-results?value='),
    1228: ('Czech Gay City', 'https://www.czechgaycity.com', '/en/search-results?value='),
    1229: ('Top Web Models', 'https://tour.topwebmodels.com', '/scenes'),
    1230: ('Big Gulp Girls', 'https://tour.biggulpgirls.com', '/scenes'),
    1231: ('2 Girls 1 Camera', 'https://tour.2girls1camera.com', '/scenes'),
    1232: ('Cougar Season', 'https://tour.cougarseason.com', '/scenes'),
    1233: ('Deepthroat Sirens', 'https://tour.deepthroatsirens.com', '/scenes'),
    1234: ('Facials Forever', 'https://tour.facialsforever.com', '/scenes'),
    1235: ('Pounded Petite', 'https://tour.poundedpetite.com', '/scenes'),
    1236: ('She\'s Brand New', 'https://tour.shesbrandnew.com', '/scenes'),
    1237: ('My Dirty Hobby', 'https://www.mydirtyhobby.com', '/content/api/v2/global-search/video'),
    1238: ('Deviante', 'https://www.deviante.com', 'https://site-api.project1service.com'),
    1239: ('Forgive Me Father', 'https://www.forgivemefather.com', 'https://site-api.project1service.com'),
    1240: ('Sex Working', 'https://www.sexworking.com', 'https://site-api.project1service.com'),
    1241: ('Pretty Dirty Teens', 'https://www.prettydirtyteens.com', 'https://site-api.project1service.com'),
    1242: ('Love Her Ass', 'https://www.loveherass.com', 'https://site-api.project1service.com'),
    1243: ('Erotic Spice', 'https://www.eroticspice.com', 'https://site-api.project1service.com'),
    1244: ('I Kiss Girls', 'https://www.ikissgirls.com', '/search.php?query='),
    1245: ('SlutInspection', 'https://www.slutinspection.com', '/sapi/'),
    1246: ('Hussie Pass', 'https://hussiepass.com', '/trailers/'),
    1247: ('Babe Archives', 'https://www.babearchives.com', '/search.php?query='),
    1248: ('My Pervy Family', 'https://www.mypervyfamily.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    1249: ('Foster Tapes', 'https://www.teamskeet.com', '/movies/'),
    1250: ('Freeuse Fantasy', 'https://www.teamskeet.com', '/movies/'),
    1251: ('Not My Grandpa', 'https://www.teamskeet.com', '/movies/'),
    1252: (),
    1253: ('AnalOnly', 'https://tour.analonly.com', '/_next/data/'),
    1254: ('Exposed Whores', 'https://exposedwhores.com/new-tour', '/search.php?query='),
    1255: ('She Seduced Me', 'https://www.sheseducedme.com', '/search.php?query='),
    1256: ('Family Swap', 'https://nubiles-porn.com', '/video/website/52/'),
    1257: ('Filthy POV', 'https://www.filthykings.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    1258: ('Filthy Massage', 'https://www.filthykings.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    1259: ('Filthy Taboo', 'https://www.filthykings.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    1260: ('Night Creep', 'https://www.filthykings.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    1261: ('Filthy Blowjobs', 'https://www.filthykings.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    1262: ('Filthy Newbies', 'https://www.filthykings.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    1263: ('Anal4K', 'https://anal4k.com', '/api'),
    1264: ('House of Fyre', 'https://www.houseofyre.com', '/search.php?query='),
    1265: ('Philavise', 'https://www.philavise.com', '/search.php?query='),
    1266: ('FamilyXXX', 'http://www.familyxxx.com', '/tour_famxxx/'),
    1267: ('Couple Fantasies', 'https://www.couplescinema.com', '/search/videos?s='),
    1268: ('Verso Cinema', 'https://www.couplescinema.com', '/search/videos?s='),
    1269: ('Sex School', 'https://www.couplescinema.com', '/search/videos?s='),
    1270: ('JoyBear', 'https://www.couplescinema.com', '/search/videos?s='),
    1271: ('Common Sensual', 'https://www.couplescinema.com', '/search/videos?s='),
    1272: ('Gentle Desire', 'https://www.couplescinema.com', '/search/videos?s='),
    1273: ('Petra Joy', 'https://www.couplescinema.com', '/search/videos?s='),
    1274: ('Madison Young', 'https://www.couplescinema.com', '/search/videos?s='),
    1275: ('Light Southern Cinema', 'https://www.couplescinema.com', '/search/videos?s='),
    1276: ('Pink and Whit Productions', 'https://www.couplescinema.com', '/search/videos?s='),
    1277: ('Signe Baumane', 'https://www.couplescinema.com', '/search/videos?s='),
    1278: ('Maria Beatty', 'https://www.couplescinema.com', '/search/videos?s='),
    1279: ('Spark Erotic', 'https://www.couplescinema.com', '/search/videos?s='),
    1280: ('Foxhouse Films', 'https://www.couplescinema.com', '/search/videos?s='),
    1281: ('Mario Ancewicz', 'https://www.couplescinema.com', '/search/videos?s='),
    1282: ('Ninja', 'https://www.couplescinema.com', '/search/videos?s='),
    1283: ('Morgana Muses', 'https://www.couplescinema.com', '/search/videos?s='),
    1284: ('Thousand Faces Films', 'https://www.couplescinema.com', '/search/videos?s='),
    1285: ('The Lifestyle', 'https://www.couplescinema.com', '/search/videos?s='),
    1286: ('JVR Porn', 'https://jvrporn.com', '/video/'),
    1287: ('Kimber Lee Live', 'https://kimberleelive.com', '/videos/'),
    1288: ('Vicky at Home', 'https://vickyathome.com', '/milf-videos/'),
    1289: ('Shanda Fay', 'https://shandafay.com', '/videos/'),
    1290: ('Deauxma Live', 'https://deauxmalive.com', '/videos/'),
    1291: ('Sara Jay', 'https://sarajay.com', '/videos/'),
    1292: ('Carmen Valentina', 'https://carmenvalentina.com', '/videos/'),
    1293: ('Charlee Chase Live', 'https://charleechaselive.com', '/videos/'),
    1294: ('Gabby Quinteros', 'https://gabbyquinteros.com', '/videos/'),
    1295: ('Angelina Castro Live', 'https://angelinacastrolive.com', '/videos/'),
    1296: ('Julia Ann Live', 'https://juliaannlive.com', '/videos/'),
    1297: ('Nikki Benz', 'https://nikkibenz.com', '/videos/'),
    1298: ('Sunny Lane Live', 'https://sunnylanelive.com', '/videos/'),
    1299: ('Puma Swede XXX', 'https://pumaswedexxx.com', '/videos/'),
    1300: ('Sophie Dee Live', 'https://sophiedeelive.com', '/videos/'),
    1301: ('Its Cleo Live', 'https://itscleolive.com', '/videos/'),
    1302: ('Maggie Green Live', 'https://maggiegreenlive.com', '/videos/'),
    1303: ('Bobbi Eden Live', 'https://bobbiedenlive.com', '/videos/'),
    1304: ('Eva Lin Live', 'https://evalin.live', '/videos/'),
    1305: ('Tasha Reign', 'https://tashareign.com', '/videos/'),
    1306: ('Jelena Jensen', 'https://jelenajensen.com', '/videos/'),
    1307: ('Penny Pax Live', 'https://pennypaxlive.com', '/videos/'),
    1308: ('Alex Legend', 'https://alexlegend.com', '/videos/'),
    1309: ('Sex My Wife', 'https://sexmywife.com', '/videos/'),
    1310: ('Rubber Doll', 'https://rubberdoll.net', '/videos/'),
    1311: ('Fucked Feet', 'https://fuckedfeet.com', '/videos/'),
    1312: ('Nina Kayy', 'https://ninakayy.com', '/videos/'),
    1313: ('Rome Major', 'https://romemajor.com', '/videos/'),
    1314: ('Siri', 'https://siripornstar.com', '/videos/'),
    1315: ('Kink305', 'https://kink305.com', '/videos/'),
    1316: ('Foxxed Up', 'https://foxxedup.com', '/videos/'),
    1317: ('Natalia Starr', 'https://nataliastarr.com', '/videos/'),
    1318: ('Samantha Grace', 'https://samanthagrace.com', '/videos/'),
    1319: ('Rachel Storms XXX', 'https://rachelstormsxxx.com', '/videos/'),
    1320: ('Kendra James', 'https://kendrajames.com', '/videos/'),
    1321: ('Maxine X', 'https://maxinex.com', '/videos/'),
    1322: ('POV Mania', 'https://povmania.com', '/videos/'),
    1323: ('Girl Girl Mania', 'https://girlgirlmania.com', '/videos/'),
    1324: ('Kayla Paige Live', 'https://kaylapaigelive.com', '/videos/'),
    1325: ('Women By Julia Ann', 'https://womenbyjuliaann.com', '/videos/'),
    1326: ('VNA Live', 'https://vnalive.com', '/videos/'),
    1327: ('Lauren Phillips', 'https://laurenphillips.com', '/search.php?query='),
    1328: ('Milfed', 'https://milfed.com', 'https://site-api.project1service.com'),
    1329: ('PervNana', 'https://www.mylf.com', '/movies/'),
    1330: ('Data18 Empire', 'https://data18.empirestores.co', '/Search?q='),
    1331: ('TGirl Japan Hardcore', 'https://www.tgirljapanhardcore.com', '/tour/trailers/'),
    1332: ('TGirl Japan', 'https://www.tgirljapan.com', '/tour/trailers/'),
    1333: ('Grooby Girls', 'https://www.groobygirls.com', '/tour/trailers/'),
    1334: ('Adult Empire', 'https://www.adultempire.com', '/allsearch/search?q='),
    1335: ('Family Therapy', 'https://familytherapyxxx.com', '/?s='),
    1336: ('Fit18', 'https://www.fit18.com', 'https://fit18.team18media.app/graphql'),
    1337: ('SpankMonster', 'https://spankmonster.com', '/MemberSceneSearch?q='),
    1338: ('Femout', 'https://www.femout.xxx', '/tour/trailers/'),
    1339: ('TGirls', 'https://www.tgirls.xxx', '/tour/trailers/'),
    1340: ('TGirls Porn', 'https://www.tgirls.porn', '/tour/trailers/'),
    1341: ('Brazilian Transsexuals', 'https://www.brazilian-transsexuals.com', '/tour/trailers/'),
    1342: ('TS Casting Couch', 'https://www.ts-castingcouch.com', '/tour/trailers/'),
    1343: ('Black TGirls', 'https://www.black-tgirls.com', '/tour/trailers/'),
    1344: ('Christy Marks', 'https://www.christymarks.com', '/videos/'),
    1345: ('ScorelandTwo', 'https://www.scoreland2.com', '/big-boob-scenes/'),
    1346: ('DarkRoomVR', 'https://darkroomvr.com', '/search?q='),
    1347: ('Puba', 'https://www.puba.com', '/pornstarnetwork/'),
    1348: ('StasyQ', 'https://www.stasyq.com', '/r/Q/'),
    1349: ('Bound Honeys', 'https://www.boundhoneys.com', '/search.php?search='),
    1350: ('Lustomic', 'https://lustomic.com', '/video_preview_page.php?iID='),
    1351: ('Girl Grind', 'https://www.girlgrind.com', 'https://site-api.project1service.com'),
    1352: ('Strapon Cum', 'https://straponcum.com', '/updates/'),
    1353: ('HotwifeXXX', 'http://www.hotwifexxx.com', '/tour_hwxxx/'),
    1354: ('PervDoctor', 'https://www.teamskeet.com', '/movies/'),
    1355: ('MomSwap', 'https://www.teamskeet.com', '/movies/'),
    1356: ('FreeuseMILF', 'http://freeusemilf.com', '/movies/'),
    1357: ('Slayed', 'https://www.slayed.com', '/graphql'),
    1358: ('White Teens Black Cocks', 'https://api.fundorado.com', '/api/'),
    1359: ('POVR', 'https://povr.com', '/search?q='),
    1360: ('Bratty MILF', 'https://brattymilf.com', '/video/gallery/'),
    1361: ('Swallow Bay', 'https://swallowbay.com', '/video/'),
    1362: ('SisSwap', 'https://www.teamskeet.com', '/movies/'),
    1363: ('IMadePorn', 'https://www.teamskeet.com', '/movies/'),
    1364: ('Facials4K', 'https://facials4k.com', '/api'),
    1365: ('Bang Movies', 'https://www.bang.com', '/movies?term='),
    1366: ('VirtualPorn', 'https://virtualporn.com', '/videos?q='),
    1367: ('JAVLibrary', 'https://www.javlibrary.com', '/en/vl_searchbyid.php?keyword='),
    1368: ('Killergram', 'https://killergram.com', '/episodes.asp?page=episodes&id='),
    1369: ('Killergram Platinum', 'https://killergram.com', '/platinum.asp?page=platinum&id='),
    1370: ('Data18 Movie Scene', 'https://data18.com', '/sys/live.php?index=&key='),
    1371: ('PervTherapy', 'https://www.teamskeet.com', '/movies/'),
    1372: ('HijabHookup', 'https://www.teamskeet.com', '/movies/'),
    1373: ('KissingSis', 'https://www.teamskeet.com', '/movies/'),
    1374: ('Mr Lucky POV', 'https://www.mrluckypov.com', '/search.php?query='),
    1375: ('Real Sensual', 'https://www.realsensual.com', '/search.php?query='),
    1376: ('Tutor 4k', 'https://vip4k.com', '/en/search/'),
    1377: ('Daddy 4k', 'https://vip4k.com', '/en/search/'),
    1378: ('Stuck 4k', 'https://vip4k.com', '/en/search/'),
    1379: ('Old 4k', 'https://vip4k.com', '/en/search/'),
    1380: ('Hunt 4k', 'https://vip4k.com', '/en/search/'),
    1381: ('Sis', 'https://vip4k.com', '/en/search/'),
    1382: ('Black 4k', 'https://vip4k.com', '/en/search/'),
    1383: ('Loan 4k', 'https://vip4k.com', '/en/search/'),
    1384: ('Debt 4k', 'https://vip4k.com', '/en/search/'),
    1385: ('Rim 4k', 'https://vip4k.com', '/en/search/'),
    1386: ('Fist 4k', 'https://vip4k.com', '/en/search/'),
    1387: ('Mature 4k', 'https://vip4k.com', '/en/search/'),
    1388: ('Shame 4k', 'https://vip4k.com', '/en/search/'),
    1389: ('Thicc18', 'https://thicc18.com', 'https://thicc18.team18media.app/graphql'),
    1390: ('Tiny Sis', 'https://www.tinysis.com', '/movies/'),
    1391: ('Bobs TGirls', 'https://www.bobstgirls.com', '/tour/trailers/'),
    1392: ('Ladyboy', 'https://www.ladyboy.xxx', '/tour/trailers/'),
    1393: ('Mom4K', 'https://mom4k.com', '/api'),
    1394: ('Bad Mommy POV', 'https://badmommypov.com', '/1/search/'),
    1395: ('NewGirlPOV', 'http://pornmastermind.com', '/tour/newgirlpov/search.php?qall='),
    1396: ('Younger Mommy', 'https://youngermommy.com', '/video/gallery/'),
    1397: ('Cum Swapping Sis', 'https://cumswappingsis.com', '/video/gallery/'),
    1398: ('TMWPOV', 'http://tmwpov.com', '/search.php?query='),
    1399: ('TeamSkeet X Avery Black', 'https://www.teamskeet.com', '/movies/'),
    1400: ('TeamSkeet X BJ Raw', 'https://www.teamskeet.com', '/movies/'),
    1401: ('TeamSkeet X Bang', 'https://www.teamskeet.com', '/movies/'),
    1402: ('TeamSkeet X Bratty Foot Girls', 'https://www.teamskeet.com', '/movies/'),
    1403: ('TeamSkeet X BritStudioXXX', 'https://www.teamskeet.com', '/movies/'),
    1404: ('TeamSkeet X Cum Kitchen', 'https://www.teamskeet.com', '/movies/'),
    1405: ('TeamSkeet X DocTayTay', 'https://www.teamskeet.com', '/movies/'),
    1406: ('TeamSkeet X Erotique TV Live', 'https://www.teamskeet.com', '/movies/'),
    1407: ('TeamSkeet X EvilAngel', 'https://www.teamskeet.com', '/movies/'),
    1408: ('TeamSkeet X GrandDadz', 'https://www.teamskeet.com', '/movies/'),
    1409: ('TeamSkeet X Herb Collins', 'https://www.teamskeet.com', '/movies/'),
    1410: ('TeamSkeet X Impure Desire', 'https://www.teamskeet.com', '/movies/'),
    1411: ('TeamSkeet X JavHub', 'https://www.teamskeet.com', '/movies/'),
    1412: ('TeamSkeet X Luxury Girl', 'https://www.teamskeet.com', '/movies/'),
    1413: ('TeamSkeet X OZ Fellatio Queens', 'https://www.teamskeet.com', '/movies/'),
    1414: ('TeamSkeet X POV Perv', 'https://www.teamskeet.com', '/movies/'),
    1415: ('TeamSkeet X POVGod', 'https://www.teamskeet.com', '/movies/'),
    1416: ('TeamSkeet X PurgatoryX', 'https://www.teamskeet.com', '/movies/'),
    1417: ('TeamSkeet X Riley Cyriis', 'https://www.teamskeet.com', '/movies/'),
    1418: ('TeamSkeet X Screampies', 'https://www.teamskeet.com', '/movies/'),
    1419: ('TeamSkeet X ToughLoveX', 'https://www.teamskeet.com', '/movies/'),
    1420: ('TeamSkeet X YoungBusty', 'https://www.teamskeet.com', '/movies/'),
    1421: ('StayHomePOV', 'https://www.teamskeet.com', '/movies/'),
    1422: ('TeamSkeet Allstars', 'https://www.teamskeet.com', '/movies/'),
    1423: ('TeamSkeet Classics', 'https://www.teamskeet.com', '/movies/'),
    1424: ('TeamSkeet Labs', 'https://www.teamskeet.com', '/movies/'),
    1425: ('TeamSkeet Selects', 'https://www.teamskeet.com', '/movies/'),
    1426: ('Mylf X Bang', 'https://www.mylf.com', '/movies/'),
    1427: ('Mylf X BJ Raw', 'https://www.mylf.com', '/movies/'),
    1428: ('Mylf X Chad Alva', 'https://www.mylf.com', '/movies/'),
    1429: ('Mylf X Dee Siren', 'https://www.mylf.com', '/movies/'),
    1430: ('Mylf X Elegant Raw', 'https://www.mylf.com', '/movies/'),
    1431: ('Mylf X EvilAngel', 'https://www.mylf.com', '/movies/'),
    1432: ('Mylf X Karups Older Women', 'https://www.mylf.com', '/movies/'),
    1433: ('Mylf X Mandy Flores', 'https://www.mylf.com', '/movies/'),
    1434: ('Mylf X Marie McCray', 'https://www.mylf.com', '/movies/'),
    1435: ('Mylf X MariskaX', 'https://www.mylf.com', '/movies/'),
    1436: ('Mylf X Miss Lexa', 'https://www.mylf.com', '/movies/'),
    1437: ('Mylf X Paytons Place', 'https://www.mylf.com', '/movies/'),
    1438: ('Mylf X PurgatoryX', 'https://www.mylf.com', '/movies/'),
    1439: ('Mylf X SinfulXXX', 'https://www.mylf.com', '/movies/'),
    1440: ('Mylf X Steve Holmes', 'https://www.mylf.com', '/movies/'),
    1441: ('Mylf X ToughLoveX', 'https://www.mylf.com', '/movies/'),
    1442: ('MomShoot', 'https://www.mylf.com', '/movies/'),
    1443: ('Mylf Classics', 'https://www.mylf.com', '/movies/'),
    1444: ('Mylf Labs', 'https://www.mylf.com', '/movies/'),
    1445: ('New Mylfs', 'https://www.mylf.com', '/movies/'),
    1446: ('Trick Your GF', 'http://trickyourgf.com', '/detailed/'),
    1447: ('Make Him Cuckold', 'http://makehimcuckold.com', '/detailed/'),
    1448: ('She Is Nerdy', 'http://sheisnerdy.com', '/detailed/'),
    1449: ('Tricky Agent', 'http://trickyagent.com', '/detailedTrailer/'),
    1550: ('Net Video Girls', 'https://netvideogirls.net', '/'),
    1551: ('Moms Family Secrets', 'https://momsfamilysecrets.com', '/video/gallery/'),
    1552: ('Squirted', 'https://squirted.com', 'https://site-api.project1service.com'),
    1553: ('See Him Fuck', 'https://seehimfuck.com', '/trailers/'),
    1554: ('MommysBoy', 'http://www.mommysboy.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    1555: ('PolyFamilyLife', 'http://www.adulttime.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    1556: ('ModelTime', 'http://www.modeltime.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    1557: ('OutOfTheFamily', 'http://www.outofthefamily.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    1558: ('GiveMeTeens', 'http://www.givemeteens.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    1559: ('WhiteGhetto', 'http://www.whiteghetto.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    1560: ('SilviaSaint', 'http://www.silviasaint.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    1561: ('CumshotOasis', 'http://www.cumshotoasis.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    1562: ('Daughter JOI', 'https://daughterjoi.com', '/1/search/'),
    1563: ('HushPass', 'https://hushpass.com', '/t1/search.php?query='),
    1564: ('Hot Milfs Fuck', 'https://hotmilfsfuck.com', '/search.php?query='),
    1565: ('Sugar Daddy Porn', 'https://www.sugardaddyporn.com', '/videos/search?s='),
    1566: ('HotGuysFuck', 'https://www.hotguysfuck.com', '/videos/search?s='),
    1567: ('BiGuysFuck', 'https://www.biguysfuck.com', '/videos/search?s='),
    1568: ('GayHoopla', 'https://www.gayhoopla.com', '/videos/search?s='),
    1569: ('Big Cock Hero', 'https://naughtyamerica.com', '/search?term='),
    1570: ('Mom\'s Money', 'https://naughtyamerica.com', '/search?term='),
    1571: ('College Sugarbabes', 'https://naughtyamerica.com', '/search?term='),
    1572: ('Mrs. Creampie', 'https://naughtyamerica.com', '/search?term='),
    1573: ('Thundercock', 'https://naughtyamerica.com', '/search?term='),
    1574: ('Conor Coxxx', 'https://conorcoxxx.com', '/MemberSceneSearch?q='),
    1575: ('Mom Lover', 'https://momlover.com', '/video'),
    1576: ('I\'m Not Your Mommy', 'https://momlover.com', '/video'),
    1577: ('Mom Swapped', 'https://momlover.com', '/video'),
    1578: ('Mom Wants to Breed', 'https://momlover.com', '/video'),
    1579: ('Mom Wants Creampie', 'https://momlover.com', '/video'),
    1580: ('Mom\'s Family Secrets', 'https://momlover.com', '/video'),
    1581: ('Moms Boy Toy', 'https://momlover.com', '/video'),
    1582: ('Mom\'s Tight', 'https://momlover.com', '/video'),
    1583: ('Czech Casting', 'https://czechcasting.com', '/tour/search/?q='),
    1584: ('Freaky Fembots', 'https://www.teamskeet.com', '/movies/'),
    1585: ('TeamSkeet x Kriss Kiss', 'https://www.teamskeet.com', '/movies/'),
    1586: ('TeamSkeet x Molly RedWolf', 'https://www.teamskeet.com', '/movies/'),
    1587: ('TeamSkeet x Sweetie Fox', 'https://www.teamskeet.com', '/movies/'),
    1588: ('TeamSkeet Features', 'https://www.teamskeet.com', '/movies/'),
    1589: ('PervPrincipal', 'https://www.mylf.com', '/movies/'),
    1590: ('LPI', 'https://www.mofos.com', 'https://site-api.project1service.com'),
    1591: ('Bel Ami Online', 'https://newtour.belamionline.com', '/playvideo.aspx?'),
    1592: ('Mom Comes First', 'https://momcomesfirst.com', '/?s='),
    1593: ('GF Leaks', 'https://www.realitykings.com', 'https://site-api.project1service.com'),
    1594: ('Hentaied', 'https://hentaied.com', '/?s='),
    1595: ('Parasited', 'https://parasited.com', '/?s='),
    1596: ('Futanari XXX', 'https://futanari.xxx', '/?s='),
    1597: ('Caribbeancom', 'https://en.caribbeancom.com', '/eng/moviepages/'),
    1598: ('VRAllure', 'https://www.vrallure.com', '/scenes/'),
    1599: ('Kin8tengoku', 'https://en.kin8tengoku.com', '/gateway/entry.phpgw?en=1&provider_id=4034&action=list&q='),
    1600: ('JAVDatabase', 'https://www.javdatabase.com', '/?wpessid=391487&s='),
    1601: ('Adult Prime', 'https://adultprime.com', '/studios/search?q='),
    1602: ('Beauty and the Senior', 'https://adultprime.com', '/studios/search?q='),
    1603: ('4K CFNM', 'https://adultprime.com', '/studios/search?type='),
    1604: ('Adult Prime Originals', 'https://adultprime.com', '/studios/search?type='),
    1605: ('BBvideo', 'https://adultprime.com', '/studios/search?type='),
    1606: ('Bondagettes', 'https://adultprime.com', '/studios/search?type='),
    1607: ('Bound Men Wanked', 'https://adultprime.com', '/studios/search?type='),
    1608: ('BrasilBimbos', 'https://adultprime.com', '/studios/search?type='),
    1609: ('Breed Bus', 'https://adultprime.com', '/studios/search?type='),
    1610: ('Club Bang Boys', 'https://adultprime.com', '/studios/search?type='),
    1611: ('Club Castings', 'https://adultprime.com', '/studios/search?type='),
    1612: ('Cockin', 'https://adultprime.com', '/studios/search?type='),
    1613: ('Color Climax', 'https://adultprime.com', '/studios/search?type='),
    1614: ('CuckOldest', 'https://adultprime.com', '/studios/search?type='),
    1615: ('DaringSex HD', 'https://adultprime.com', '/studios/search?type='),
    1616: ('Digital Desire', 'https://adultprime.com', '/studios/search?type='),
    1617: ('Dirty Gunther', 'https://adultprime.com', '/studios/search?type='),
    1618: ('Dirty Hospital', 'https://adultprime.com', '/studios/search?type='),
    1619: ('Distorded', 'https://adultprime.com', '/studios/search?type='),
    1620: ('Elegant Raw', 'https://adultprime.com', '/studios/search?type='),
    1621: ('Evil Playgrounds', 'https://adultprime.com', '/studios/search?type='),
    1622: ('Family Screw', 'https://adultprime.com', '/studios/search?type='),
    1623: ('Fixxxion', 'https://adultprime.com', '/studios/search?type='),
    1624: ('Fresh POV', 'https://adultprime.com', '/studios/search?type='),
    1625: ('Fucking Skinny', 'https://adultprime.com', '/studios/search?type='),
    1626: ('Gonzo 2000', 'https://adultprime.com', '/studios/search?type='),
    1627: ('Granddadz', 'https://adultprime.com', '/studios/search?type='),
    1628: ('GrandMams', 'https://adultprime.com', '/studios/search?type='),
    1629: ('GrandParentsX', 'https://adultprime.com', '/studios/search?type='),
    1630: ('Group Banged', 'https://adultprime.com', '/studios/search?type='),
    1631: ('Group Mams', 'https://adultprime.com', '/studios/search?type='),
    1632: ('Group Sex Games', 'https://adultprime.com', '/studios/search?type='),
    1633: ('Hollandsche Passie', 'https://adultprime.com', '/studios/search?type='),
    1634: ('Interraced', 'https://adultprime.com', '/studios/search?type='),
    1635: ('Jim Slip', 'https://adultprime.com', '/studios/search?type='),
    1636: ('Laras Playground', 'https://adultprime.com', '/studios/search?type='),
    1637: ('Lets Go Bi', 'https://adultprime.com', '/studios/search?type='),
    1638: ('Mams Casting', 'https://adultprime.com', '/studios/search?type='),
    1639: ('Manalized', 'https://adultprime.com', '/studios/search?type='),
    1640: ('Manko 88', 'https://adultprime.com', '/studios/search?type='),
    1641: ('Massage Sins', 'https://adultprime.com', '/studios/search?type='),
    1642: ('Mature Van', 'https://adultprime.com', '/studios/search?type='),
    1643: ('My MILFz', 'https://adultprime.com', '/studios/search?type='),
    1644: ('My Sexy Kittens', 'https://adultprime.com', '/studios/search?type='),
    1645: ('OldieX', 'https://adultprime.com', '/studios/search?type='),
    1646: ('Peep Leek', 'https://adultprime.com', '/studios/search?type='),
    1647: ('Perfect 18', 'https://adultprime.com', '/studios/search?type='),
    1648: ('Plumperd', 'https://adultprime.com', '/studios/search?type='),
    1649: ('Pornstar Classics', 'https://adultprime.com', '/studios/search?type='),
    1650: ('Pornstars Live', 'https://adultprime.com', '/studios/search?type='),
    1651: ('Prime Lesbian', 'https://adultprime.com', '/studios/search?type='),
    1652: ('Raw Euro', 'https://adultprime.com', '/studios/search?type='),
    1653: ('Red Light Sex Trips', 'https://adultprime.com', '/studios/search?type='),
    1654: ('Retro Raw', 'https://adultprime.com', '/studios/search?type='),
    1655: ('Rodox', 'https://adultprime.com', '/studios/search?type='),
    1656: ('Salsa XXX', 'https://adultprime.com', '/studios/search?type='),
    1657: ('Sensual Heat', 'https://adultprime.com', '/studios/search?type='),
    1658: ('Shadow Slaves', 'https://adultprime.com', '/studios/search?type='),
    1659: ('Sinful Raw', 'https://adultprime.com', '/studios/search?type='),
    1660: ('Sinful Soft', 'https://adultprime.com', '/studios/search?type='),
    1661: ('Sinful XXX', 'https://adultprime.com', '/studios/search?type='),
    1662: ('Southern Sins', 'https://adultprime.com', '/studios/search?type='),
    1663: ('Submissed', 'https://adultprime.com', '/studios/search?type='),
    1664: ('Summer Sinners', 'https://adultprime.com', '/studios/search?type='),
    1665: ('Swhores', 'https://adultprime.com', '/studios/search?type='),
    1666: ('Teenrs', 'https://adultprime.com', '/studios/search?type='),
    1667: ('The Pain Files', 'https://adultprime.com', '/studios/search?type='),
    1668: ('Tranny Bizarre', 'https://adultprime.com', '/studios/search?type='),
    1669: ('UK Flashers', 'https://adultprime.com', '/studios/search?type='),
    1670: ('Vintage Classic Porn', 'https://adultprime.com', '/studios/search?type='),
    1671: ('VR Teens', 'https://adultprime.com', '/studios/search?type='),
    1672: ('Young Busty', 'https://adultprime.com', '/studios/search?type='),
    1673: ('Abuse Me', 'http://bangbrosportal.com', '/?s='),
    1674: ('DirtyAuditions', 'https://dirtyauditions.com', '/_next/data/'),
    1675: ('Sexy Modern Bull', 'https://sexymodernbull.com', '/videos'),
    1676: ('GotFilled', 'https://gotfilled.com', '/videos'),
    1677: ('Come Inside', 'https://comeinside.com', '/scenes'),
    1678: ('Benefit Monkey', 'https://benefitmonkey.com', '/scenes'),
    1679: ('Ricky\'s Room', 'https://rickysroom.com', '/videos'),
    1680: ('Inserted', 'https://inserted.com', '/videos'),
    1681: ('BJ Raw', 'https://bjraw.com', '/videos'),
    1682: ('AltErotic', 'https://alterotic.com', '/videos'),
    1683: ('Lezkey', 'https://lezkey.com', '/scenes'),
    1684: ('SIDECHICK', 'https://sidechick.com', '/videos'),
    1685: ('JAV888', 'https://jav888.com', '/videos'),
    1686: ('Smashed', 'https://nubiles-porn.com', '/video/website/68/'),
    1687: ('Pie 4k', 'https://vip4k.com', '/en/search/'),
    1688: ('Shower 4K', 'https://pornplus.com', '/api'),
    1689: ('Kinky Sluts 4K', 'https://pornplus.com', '/api'),
    1690: ('Property Exploits', 'https://pornplus.com', '/api'),
    1691: ('Asians Exploited', 'https://pornplus.com', '/api'),
    1692: ('Strip Club Tryouts', 'https://pornplus.com', '/api'),
    1693: ('MomCum', 'https://pornplus.com', '/api'),
    1694: ('VIP4K', 'https://vip4k.com', '/en/search/'),
    1695: ('PornPlus', 'https://pornplus.com', '/api'),
    1696: ('BBC POVD', 'https://pornplus.com', '/api'),
    1697: ('Girl Scout Sex', 'https://pornplus.com', '/api'),
    1698: ('Exploited Cheerleaders', 'https://pornplus.com', '/api'),
    1699: ('School of Cock', 'https://pornplus.com', '/api'),
    1700: ('Glory Hole 4K', 'https://pornplus.com', '/api'),
    1701: ('Creepy Pa', 'https://pornplus.com', '/api'),
    1702: ('Caged Sex', 'https://pornplus.com', '/api'),
    1703: ('Teeny Taboo', 'https://teenytaboo.com', '/videos/'),
    1704: (),
    1705: ('LoveHerFilms', 'https://www.loveherfilms.com', '/tour/search.php?query='),
    1706: ('LoveHerBoobs', 'https://www.loveherboobs.com', '/tour/search.php?query='),
    1707: ('SheLovesBlack', 'https://www.shelovesblack.com', '/tour/search.php?query='),
    1708: ('Try Teens', 'https://api.fundorado.com', '/api/'),
    1709: ('Young Throats', 'https://api.fundorado.com', '/api/'),
    1710: ('Bride 4K', 'https://vip4k.com', '/en/search/'),
    1711: ('Dyke 4K', 'https://vip4k.com', '/en/search/'),
    1712: ('Ignore 4K', 'https://vip4k.com', '/en/search/'),
    1713: ('Buttmuse', 'https://www.littlecaprice-dreams.com', '/?s='),
    1714: ('Caprice Divas', 'https://www.littlecaprice-dreams.com', '/?s='),
    1715: ('NasstyX', 'https://www.littlecaprice-dreams.com', '/?s='),
    1716: ('POVDreams', 'https://www.littlecaprice-dreams.com', '/?s='),
    1717: ('Streetfuck', 'https://www.littlecaprice-dreams.com', '/?s='),
    1718: ('SuperprivateX', 'https://www.littlecaprice-dreams.com', '/?s='),
    1719: ('Wecumtoyou', 'https://www.littlecaprice-dreams.com', '/?s='),
    1720: ('Xpervo', 'https://www.littlecaprice-dreams.com', '/?s='),
    1721: ('Cuck 4K', 'https://vip4k.com', '/en/search/'),
    1722: ('Oopsie', 'https://adulttime.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    1723: ('Caught Fapping', 'https://adulttime.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    1724: ('Couple Swapping', 'https://adulttime.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    1725: ('Kiss Me Fuck Me', 'https://adulttime.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    1726: ('Dare We Share', 'https://adulttime.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    1727: ('Teen Sneaks', 'https://adulttime.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    1728: ('Modern Day Sins', 'https://adulttime.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    1729: ('Accidental Gangbang', 'https://adulttime.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    1730: ('Aunt Judys XXX', 'https://auntjudysxxx.com', '/tour/search.php?query='),
    1731: ('Aunt Judys', 'https://auntjudys.com', '/tour/search.php?query='),
    1732: ('Gilfed', 'https://gilfed.com', 'https://site-api.project1service.com'),
    1733: ('Dilfed', 'https://dilfed.com', 'https://site-api.project1service.com'),
    1734: ('Mylf After Dark', 'https://www.mylf.com', '/movies/'),
    1735: ('HijabMylfs', 'https://www.mylf.com', '/movies/'),
    1736: ('PervDriver', 'https://www.teamskeet.com', '/movies/'),
    1737: ('Hot Girls Game', 'https://www.realitykings.com', 'https://site-api.project1service.com'),
    1738: ('WowPorn', 'https://www.wowpornblog.com', '/?s='),
    1739: ('Black TGirls Hardcore', 'https://www.blacktgirlshardcore.com', '/tour/trailers/'),
    1740: ('Mommy 4K', 'https://vip4k.com', '/en/search/'),
    1741: ('Colette', 'https://www.colette.com', '/videos/'),
    1742: (),
    1743: ('Work Me Harder', 'https://www.realitykings.com', 'https://site-api.project1service.com'),
    1744: ('ScoreVideos', 'https://www.scorevideos.com', '/porn-videos/'),
    1745: ('Bush', 'https://www.cherrypimps.com', '/search.php?query='),
    1746: ('Ginger', 'https://www.cherrypimps.com', '/search.php?query='),
    1747: ('Divine-DD', 'https://www.divine-dd.com', '/videos'),
    1748: ('Serve 4K', 'https://vip4k.com', '/en/search/'),
    1749: ('Fan Fuckers', 'https://adultprime.com', '/studios/search?type='),
    1750: ('Fill Up My Mom', 'https://www.filthykings.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    1751: ('Hot Girls Raw', 'https://www.filthykings.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    1752: ('Its Anal', 'https://www.filthykings.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    1753: ('FK BTS', 'https://www.filthykings.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    1754: ('MilfAF', 'https://www.milfaf.com', '/models/'),
    1755: ('Shady Spa', 'https://www.shadyspa.com', '/models/'),
    1756: ('Breed Me', 'https://www.breedme.com', '/models/'),
    1757: ('MrLuckyRAW', 'https://www.mrluckyraw.com', '/search.php?query='),
    1758: ('Sex Selector', 'https://www.sexselector.com', 'https://site-api.project1service.com'),
    1759: ('Xev Unleashed', 'https://xevunleashed.com', '/search.php?query='),
    1760: ('My POV Fam', 'https://www.mypovfam.com', '/?s='),
    1761: ('Perverted POV', 'https://www.pervertedpov.com', '/?s='),
    1762: ('Peter\'s Kingdom', 'https://peterskingdom.com', '/?s='),
    1763: ('Raw White Meat', 'https://rawwhitemeat.com', '/?s='),
    1764: ('Sluts Around Town', 'https://slutsaroundtown.com', '/?s='),
    1765: ('18 Lust', 'https://18lust.com', '/MemberSceneSearch?q='),
    1766: ('Bizarre Entertainment', 'https://www.bizarrevideo.com', '/MemberSceneSearch?q='),
    1767: ('Black Massive Cocks', 'https://blackmassivecocks.com', '/MemberSceneSearch?q='),
    1768: ('Brutha\'s Inc', 'https://bruthasinc.com', '/MemberSceneSearch?q='),
    1769: ('Concoxxxion', 'https://concoxxxion.com', '/MemberSceneSearch?q='),
    1770: ('Darkside Entertainment', 'https://darksideentertainment.com', '/MemberSceneSearch?q='),
    1771: ('Digital Video Vision', 'https://digitalvideovision.com', '/MemberSceneSearch?q='),
    1772: ('Elegant Angel', 'https://elegantangel.com', '/MemberSceneSearch?q='),
    1773: ('Evasive Angles', 'https://evasiveangles.com', '/MemberSceneSearch?q='),
    1774: ('Forbidden Fruits Films', 'https://forbiddenfruitsfilms.com', '/MemberSceneSearch?q='),
    1775: ('Horny Household', 'https://hornyhousehold.com', '/MemberSceneSearch?q='),
    1776: ('Hot Wife Fun', 'https://hotwifefun.com', '/MemberSceneSearch?q='),
    1777: ('Joanna Angel', 'https://joannaangel.com', '/MemberSceneSearch?q='),
    1778: ('Jodi West', 'https://jodiwest.com', '/MemberSceneSearch?q='),
    1779: ('Jonathan Jordan XXX', 'https://jonathanjordanxxx.com', '/MemberSceneSearch?q='),
    1780: ('Kaiia Eve', 'https://kaiiaeve.com', '/MemberSceneSearch?q='),
    1781: ('Kings of Fetish', 'https://kingsoffetish.com', '/MemberSceneSearch?q='),
    1782: ('Lethal Hardcore', 'https://www.lethalhardcore.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    1783: ('Lethal Hardcore VR', 'https://www.lethalhardcorevr.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    1784: ('Only 3x', 'https://only3x.com', '/MemberSceneSearch?q='),
    1785: ('LeWood', 'https://lewood.com', '/MemberSceneSearch?q='),
    1786: ('Pornstar Stroker', 'https://pornstarstroker.com', '/MemberSceneSearch?q='),
    1787: ('Reagan Foxx', 'https://www.reaganfoxx.com', '/MemberSceneSearch?q='),
    1788: ('Real Girls Fuck', 'https://realgirlsfuck.com', '/MemberSceneSearch?q='),
    1789: ('Severe Sex Films', 'https://severesexfilms.com', '/MemberSceneSearch?q='),
    1790: ('SINematica', 'https://sinematica.com', '/MemberSceneSearch?q='),
    1791: ('Smut Factor', 'https://smutfactor.com', '/MemberSceneSearch?q='),
    1792: ('Star Strokers', 'https://starstroker.com', '/MemberSceneSearch?q='),
    1793: ('Step House XXX', 'https://stephousexxx.com', '/MemberSceneSearch?q='),
    1794: ('Vouyer Media', 'https://vouyermedia.com', '/MemberSceneSearch?q='),
    1795: ('West Coast Productions', 'https://westcoastproductions.com', '/MemberSceneSearch?q='),
    1796: ('Whorecraft VR', 'https://whorecraftvr.com', '/MemberSceneSearch?q='),
    1797: ('Freeze', 'https://freeze.xxx', '/?s='),
    1798: ('Plants vs Cunts', 'https://plantsvscunts.com', '/?s='),
    1799: ('Brand New Amateurs', 'https://brandnewamateurs.com', '/models'),
    1800: ('Hot Wives Cheating', 'https://hotwivescheating.com/', '/MemberSceneSearch?q='),
    1801: ('Pornbox', 'https://www.pornbox.com', '/store/search?q='),
    1802: ('DownblouseJerk', 'https://www.downblousejerk.com', '/videos'),
    1803: ('RealBikiniGirls', 'https://www.realbikinigirls.com', '/videos'),
    1804: ('LingerieTales', 'https://www.lingerietales.com', '/videos'),
    1805: ('DFXtra', 'https://www.dogfartnetwork.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    1806: ('Milfy', 'https://www.milfy.com', '/graphql'),
    1807: ('Use POV', 'https://www.mylf.com', '/movies/'),
    1808: ('The Loft', 'https://www.teamskeet.com', '/movies/'),
    1809: ('TeamSkeet X Slut Inspection', 'https://www.teamskeet.com', '/movies/'),
    1810: ('Glowupz', 'https://www.teamskeet.com', '/movies/'),
    1811: ('Mylf X Little Puck', 'https://www.mylf.com', '/movies/'),
    1812: ('Secrets', 'https://www.mylf.com', '/movies/'),
    1813: ('Tiger Moms', 'https://www.mylf.com', '/movies/'),
    1814: ('Ask Your Mother', 'https://www.mylf.com', '/movies/'),
    1815: ('Mylf X Manko88', 'https://www.mylf.com', '/movies/'),
    1816: ('Breeding Material', 'https://www.teamskeet.com', '/movies/'),
    1817: ('Mormon Girlz', 'https://www.teamskeet.com', '/movies/'),
    1818: ('Sex and Grades', 'https://www.teamskeet.com', '/movies/'),
    1819: ('Brat Tamer', 'https://www.teamskeet.com', '/movies/'),
    1820: ('TeamSkeet X Fit18', 'https://www.teamskeet.com', '/movies/'),
    1821: ('TeamSkeet X Harmony Films', 'https://www.teamskeet.com', '/movies/'),
    1822: ('TeamSkeet X Jonathan Jordan', 'https://www.teamskeet.com', '/movies/'),
    1823: ('After Dark', 'https://www.teamskeet.com', '/movies/'),
    1824: ('Jesse Loads Monster Facials', 'http://jesseloadsmonsterfacials.com', '/visitors'),
    1825: ('Mr. Lucky LIFE', 'https://www.mrluckylife.com', '/search.php?query='),
    1826: ('Cream Her', 'https://www.creamher.com', '/search.php?query='),
    1827: ('DR. Daddy POV', 'https://www.drdaddypov.com', '/search.php?query='),
    1828: ('Goth Girlfriends', 'https://www.gothgirlfriends.com', '/search.php?query='),
    1829: ('POV Perv', 'https://tour.povperv.com', '/scenes'),
    1830: ('LegendaryX', 'https://legendaryx.com', '/videos'),
    1831: ('Amazing Films', 'https://amazingfilms.com', '/videos'),
    1832: ('Lucid Flix', 'https://lucidflix.com', '/episodes'),
    1833: ('Nick Marxx', 'https://nickmarxx.com', '/videos'),
    1834: ('BlackBullChallenge', 'https://blackbullchallenge.com', '/videos'),
    1835: ('Dark Shade', 'https://darkshade.com', '/videos'),
    1836: ('Dick HD Daily', 'https://dickhddaily.com', '/videos'),
    1837: ('Dire Desires', 'https://diredesires.com', '/scenes'),
    1838: ('Purity VR', 'https://purityvr.com', '/videos'),
    1839: ('Passion POV', 'https://passionpov.com', '/videos'),
    1840: ('Queer Crush', 'https://queercrush.com', '/videos'),
    1841: ('Hard Werk', 'https://hardwerk.com', '/films'),
    1842: ('Cannon Prod', 'https://cannonprod.com', '/videos'),
    1843: ('Bemefi', 'https://bemefi.com', '/videos'),
    1844: ('FreakMobMedia', 'https://freakmobmedia.com', '/videos'),
    1845: ('XFul', 'https://xful.com', '/videos'),
    1846: ('S3XUS', 'https://s3xus.com', '/scenes'),
    1847: ('Yes Girlz', 'https://yesgirlz.com', '/scenes'),
    1848: ('Z Filmz Originals', 'https://z-filmz-originals.com', '/videos'),
    1849: ('Hoby Buchanon', 'https://hobybuchanon.com', '/updates'),
    1850: ('VRHush', 'https://vrhush.com', '/scenes'),
    1851: ('Hitzefrei', 'https://hitzefrei.com', 'https://tour.hitzefrei.com/search/'),
    1852: ('Unleashed', 'https://unleashed.hitzefrei.com', 'https://unleashed.hitzefrei.com/search/'),
    1853: ('CityCheck', 'https://citycheck.hitzefrei.com', 'https://citycheck.hitzefrei.com/search/'),
    1854: ('Milf Hunters', 'https://milfhunters.hitzefrei.com', 'https://milfhunters.hitzefrei.com/search/'),
    1855: ('Cuff em All', 'https://cuffemall.hitzefrei.com', 'https://cuffemall.hitzefrei.com/search/'),
    1856: ('fANALarm', 'https://fanalarm.hitzefrei.com', 'https://fanalarm.hitzefrei.com/search/'),
    1857: ('Fuck On Arrival', 'https://fuckonarrival.hitzefrei.com', 'https://fuckonarrival.hitzefrei.com/search/'),
    1858: ('Family Affairs', 'https://familyaffairs.hitzefrei.com', 'https://familyaffairs.hitzefrei.com/search/'),
    1859: ('Patti\'s Anal', 'https://pattisanals.hitzefrei.com', 'https://pattisanals.hitzefrei.com/search/'),
    1860: ('Gonzo Living', 'https://www.gonzoliving.com', 'https://tour.gonzoliving.com/search/'),
    1861: ('Teen Gonzo', 'https://www.teengonzo.com', 'https://tour.teengonzo.com/search/'),
    1862: ('Milf Gonzo', 'https://www.milfgonzo.com', 'https://tour.milfgonzo.com/search/'),
    1863: ('Touch My Wife', 'http://www.touchmywife.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    1864: ('Taboo Heat', 'http://www.tabooheat.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    1865: ('B Skow', 'http://www.bskow.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    1866: ('GASM', 'https://www.gasm.com', '/search/videos?s='),
    1867: ('Magma Film', 'https://www.gasm.com', '/search/videos?s='),
    1868: ('JapanHD', 'https://www.gasm.com', '/search/videos?s='),
    1869: ('Pure XXX Films', 'https://www.gasm.com', '/search/videos?s='),
    1870: ('Harmony Vision', 'https://www.gasm.com', '/search/videos?s='),
    1871: ('Paradise Films', 'https://www.gasm.com', '/search/videos?s='),
    1872: ('Leche69', 'https://www.gasm.com', '/search/videos?s='),
    1873: ('Cosplay Babes', 'https://www.gasm.com', '/search/videos?s='),
    1874: ('Fun Movies', 'https://www.gasm.com', '/search/videos?s='),
    1875: ('MMV Films', 'https://www.gasm.com', '/search/videos?s='),
    1876: ('Inflagranti', 'https://www.gasm.com', '/search/videos?s='),
    1877: ('Hot Gold', 'https://www.gasm.com', '/search/videos?s='),
    1878: ('The Undercover Lover', 'https://www.gasm.com', '/search/videos?s='),
    1879: ('Herzog', 'https://www.gasm.com', '/search/videos?s='),
    1880: ('Butt Formation', 'https://www.gasm.com', '/search/videos?s='),
    1881: ('PornXN', 'https://www.gasm.com', '/search/videos?s='),
    1882: ('Filthy and Fisting', 'https://www.gasm.com', '/search/videos?s='),
    1883: ('Voodooed', 'https://voodooed.com', '/?s='),
    1884: ('Vored', 'https://vored.com', '/?s='),
    1885: ('Latina MILF', 'https://letsdoeit.com', 'https://site-api.project1service.com'),
    1886: ('Heavy on Hotties', 'https://www.heavyonhotties.com', '/'),
    1887: ('Filthy Kings', 'https://www.filthykings.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    1888: ('MYLF Seeker', 'https://www.filthykings.com', 'https://tsmkfa364q-dsn.algolia.net/1/indexes/*/queries'),
    1889: ('Score Classics', 'https://www.scoreclassics.com', '/classic-boob-videos/'),
    1890: ('LustCinema', 'https://next-prod-api.lustcinema.com', '/api/search'),
    1891: ('CzechAR', 'https://www.czechar.com', '/model-'),
    1892: ('Strippers 4K', 'https://strippers4k.com', '/api'),
    1893: ('Wifey', 'https://www.wifey.com', '/graphql'),
    1894: ('PassthroughVR', 'https://www.realvr.com', '/vrpornvideos/search/'),
}

abbreviations = (
    ('^18og ', '18OnlyGirls '),
    ('^18yo ', '18YearsOld '),
    ('^1kf ', '1000Facials '),
    ('^21ea ', '21EroticAnal '),
    ('^21fa ', '21FootArt '),
    ('^21n ', '21Naturals '),
    ('^2cst ', '2ChicksSameTime '),
    ('^a1o1 ', 'Asian1on1 '),
    ('^aa ', 'AmateurAllure '),
    ('^ad ', 'AmericanDaydreams '),
    ('^add ', 'ManualAddActors '),
    ('^afg ', '18OnlyGirls '),
    ('^agm ', 'AllGirlMassage '),
    ('^AllFineGirls ', '18OnlyGirls '),
    ('^am ', 'AssMasterpiece '),
    ('^analb ', 'AnalBeauty '),
    ('^ap ', 'AssParade '),
    ('^atkg', 'ATKGirlfriends'),
    ('^aw ', 'AngelaWhite '),
    ('^ba ', 'BBCSurprise '),
    ('^baebz ', 'Baeb '),
    ('^badventures ', 'Bang '),
    ('^bandts ', 'BeautyandtheSenior '),
    ('^bblib ', 'BigButtsLikeItBig '),
    ('^bcasting ', 'BangCasting '),
    ('^bcb ', 'BigCockBully '),
    ('^bcc ', 'BackroomCastingCouch '),
    ('^bch ', 'BigCockHero '),
    ('^bconfessions ', 'BangConfessions '),
    ('^bdpov ', 'BadDaddyPOV '),
    ('^bex ', 'BrazzersExxtra '),
    ('^bgb ', 'BabyGotBoobs '),
    ('^bgbs ', 'BoundGangbangs '),
    ('^bgf ', 'BiGuysFuck '),
    ('^bglamkore ', 'BangGlamkore '),
    ('^bgonzo ', 'BangGonzo '),
    ('^bin ', 'BigNaturals '),
    ('^bjf ', 'BlowjobFridays '),
    ('^blackambush ', 'BBCSurprise '),
    ('^bp ', 'ButtPlays '),
    ('^bprettyraw ', 'Bang '),
    ('^brammed ', 'Bang '),
    ('^brealteens ', 'Bang '),
    ('^brequests ', 'Bang '),
    ('^broadside ', 'Bang '),
    ('^bsurprise ', 'Bang '),
    ('^btas ', 'BigTitsatSchool '),
    ('^btaw ', 'BigTitsatWork '),
    ('^btc', 'BigTitCreampie '),
    ('^btis ', 'BigTitsinSports '),
    ('^btiu ', 'BigTitsinUniform '),
    ('^btlbd ', 'BigTitsLikeBigDicks '),
    ('^btra ', 'BigTitsRoundAsses '),
    ('^btrickery ', 'Bang '),
    ('^burna ', 'BurningAngel '),
    ('^bwb ', 'BigWetButts '),
    ('^byngr ', 'Bang '),
    ('^cc ', 'Czech Casting '),
    ('^ccxxx ', 'Conor Coxxx '),
    ('^cfnm ', 'ClothedFemaleNudeMale '),
    ('^clip ', 'AnalVids '),
    ('^clubseventeen ', 'ClubSweethearts '),
    ('^cps ', 'CherryPimps '),
    ('^cpbush ', 'Bush '),
    ('^cpbusted ', 'Busted '),
    ('^cpcheese ', 'Cheese.XXX '),
    ('^cpconfessions ', 'Confessions.XXX '),
    ('^cpcucked ', 'Cucked.XXX '),
    ('^cpfresh ', 'Fresh '),
    ('^cpginger ', 'Ginger '),
    ('^cppetite ', 'Petite.XXX '),
    ('^cptaboo ', 'Taboo '),
    ('^css ', 'CzechStreets '),
    ('^cuf ', 'CumFiesta '),
    ('^cws ', 'CzechWifeSwap '),
    ('^da ', 'DoctorAdventures '),
    ('^DateSlam ', 'ScrewMeToo '),
    ('^Daughter ', 'DaughterSwap '),
    ('^Daughters ', 'DaughterSwap '),
    ('^dbm ', 'DontBreakMe '),
    ('^dc ', 'DorcelVision '),
    ('^ddfb ', 'DDFBusty '),
    ('^dfxtraoriginals ', 'DFXtra '),
    ('^dm ', 'DirtyMasseur '),
    ('^dnj ', 'DaneJones '),
    ('^dpg ', 'DigitalPlayground '),
    ('^drilled ', 'Drilled.XXX '),
    ('^ds ', 'ScrewMeToo '),
    ('^dsw ', 'DaughterSwap '),
    ('^dwc ', 'DirtyWivesClub '),
    ('^dwp ', 'DayWithAPornstar '),
    ('^ecg ', 'ExploitedCollegeGirls '),
    ('^esp ', 'EuroSexParties '),
    ('^ete ', 'EuroTeenErotica '),
    ('^ext ', 'ExxxtraSmall '),
    ('^Exxtra ', 'BrazzersExxtra '),
    ('^family ', 'Taboo '),
    ('^fams ', 'FamilyStrokes '),
    ('^faq ', 'FirstAnalQuest '),
    ('^fds ', 'FakeDrivingSchool '),
    ('^fft ', 'FemaleFakeTaxi '),
    ('^ffr ', 'FacialsForever '),
    ('^fhd ', 'FantasyHD '),
    ('^fhl ', 'FakeHostel '),
    ('^fho ', 'FakehubOriginals '),
    ('^fittingroom ', 'Fitting-Room '),
    ('^fj ', 'Femjoy '),
    ('^fka ', 'FakeAgent '),
    ('^fm ', 'FuckingMachines '),
    ('^fmm ', 'FreakMobMedia '),
    ('^fms ', 'FantasyMassage '),
    ('^frs ', 'FitnessRooms '),
    ('^ft ', 'FastTimes '),
    ('^ftx ', 'FakeTaxi '),
    ('^gbcp ', 'GangbangCreampie '),
    ('^gft ', 'GrandpasFuckTeens '),
    ('^glf ', 'Gilfed '),
    ('^gta ', 'GirlsTryAnal '),
    ('^gw ', 'GirlsWay '),
    ('^h1o1 ', 'Housewife1on1 '),
    ('^ham ', 'HotAndMean '),
    ('^hart ', 'Hegre '),
    ('^hcm ', 'HotCrazyMess '),
    ('^hegre-art ', 'Hegre '),
    ('^hgf ', 'HotGuysFuck '),
    ('^hlaf ', 'Hot Legs and Feet '),
    ('^hoh ', 'HandsOnHardcore '),
    ('^hotab ', 'HouseofTaboo '),
    ('^houseofyre ', 'House of Fyre '),
    ('^hr ', 'HollyRandall '),
    ('^ht ', 'Hogtied '),
    ('^hussieauditions', 'HussiePass'),
    ('^hustl3r ', 'Hustler '),
    ('^hv ', 'HarmonyVision '),
    ('^ihaw ', 'IHaveAWife '),
    ('^iktg ', 'IKnowThatGirl '),
    ('^il ', 'ImmoralLive '),
    ('^int3rracialpass ', 'InterracialPass '),
    ('^irpass ', 'InterracialPass '),
    ('^itc ', 'InTheCrack '),
    ('^jb ', 'JavBus '),
    ('^jlmf ', 'JesseLoadsMonsterFacials '),
    ('^jowm', 'JerkOffWithMe'),
    ('^jp ', 'JaysPOV '),
    ('^kha ', 'KarupsHA '),
    ('^kow ', 'KarupsOW '),
    ('^kpc ', 'KarupsPC '),
    ('^la ', 'LatinAdultery '),
    ('^latn ', 'LookAtHerNow '),
    ('^lcd ', 'LittleCaprice '),
    ('^legalporno ', 'AnalVids '),
    ('^lhf ', 'LoveHerFeet '),
    ('^lilhum ', 'LilHumpers '),
    ('^littlecapricedreams ', 'LittleCaprice '),
    ('^lsb ', 'Lesbea '),
    ('^lst ', 'LatinaSexTapes '),
    ('^lta ', 'LetsTryAnal '),
    ('^maj ', 'ManoJob '),
    ('^mbb ', 'MommyBlowsBest '),
    ('^mbt ', 'MomsBangTeens '),
    ('^mc ', 'MassageCreep '),
    ('^mcu ', 'MonsterCurves '),
    ('^mdhf ', 'MyDaughtersHotFriend '),
    ('^mdhg ', 'MyDadsHotGirlfriend '),
    ('^mfa ', 'ManuelFerrara '),
    ('^mfhg ', 'MyFriendsHotGirl '),
    ('^mfhm ', 'MyFriendsHotMom '),
    ('^mfl ', 'Mofos '),
    ('^mfp ', 'MyFamilyPies '),
    ('^mfst ', 'MyFirstSexTeacher '),
    ('^mgb ', 'MommyGotBoobs '),
    ('^mgbf ', 'MyGirlfriendsBustyFriend '),
    ('^mic ', 'MomsInControl '),
    ('^mih ', 'MilfHunter '),
    ('^mj ', 'ManoJob '),
    ('^mlib ', 'MilfsLikeItBig '),
    ('^mlt ', 'MomsLickTeens '),
    ('^mmgs ', 'MommysGirl '),
    ('^mmts ', 'MomsTeachSex '),
    ('^mnm ', 'MyNaughtyMassage '),
    ('^mom ', 'MomXXX '),
    ('^mpov ', 'MrPOV '),
    ('^mr ', 'MassageRooms '),
    ('^mrpov ', 'MisterPOV'),
    ('^mrs ', 'MassageRooms '),
    ('^mrsc ', 'MrsCreampie '),
    ('^mshf ', 'MySistersHotFriend '),
    ('^mts ', 'MomsTeachSex '),
    ('^mvft ', 'MyVeryFirstTime '),
    ('^mwhf ', 'MyWifesHotFriend '),
    ('^na ', 'NaughtyAthletics '),
    ('^naf ', 'NeighborAffair '),
    ('^nam ', 'NaughtyAmerica '),
    ('^naughtyamericavr ', 'NaughtyAmerica '),
    ('^nb ', 'NaughtyBookworms '),
    ('^news ', 'NewSensations '),
    ('^nf ', 'NubileFilms '),
    ('^no ', 'NaughtyOffice '),
    ('^np ', 'NubilesPorn '),
    ('^nrg ', 'NaughtyRichGirls '),
    ('^nrx ', 'Pornbox '),
    ('^nubc ', 'NubilesCasting '),
    ('^nubet ', 'NubilesET '),
    ('^nubilef ', 'NubileFilms '),
    ('^Nubiles.net ', 'Nubiles'),
    ('^NubilesNet ', 'Nubiles'),
    ('^num ', 'NuruMassage '),
    ('^nvg ', 'NetVideoGirls '),
    ('^nw ', 'NaughtyWeddings '),
    ('^obj ', 'OnlyBlowjob '),
    ('^otb ', 'OnlyTeenBlowjobs '),
    ('^passion-hd ', 'PassionHD '),
    ('^pav ', 'PixAndVideo '),
    ('^pba ', 'PublicAgent '),
    ('^pc ', 'PrincessCum '),
    ('^pcfnm ', 'PureCFNM '),
    ('^pdmcl ', 'ChicasLoca '),
    ('^penthouse ', 'PenthouseGold '),
    ('^pf ', 'PornFidelity '),
    ('^phd ', 'PassionHD '),
    ('^phdp ', 'PetiteHDPorn '),
    ('^plib ', 'PornstarsLikeitBig '),
    ('^pml ', 'PornMegaLoad '),
    ('^pop ', 'PervsOnPatrol '),
    ('^ppu ', 'PublicPickups '),
    ('^prdi ', 'PrettyDirty '),
    ('^ps ', 'PropertySex '),
    ('^ptt ', 'Petite '),
    ('^pud ', 'PublicDisgrace '),
    ('^pxf ', 'PureXXXFilms '),
    ('^pyx ', 'PurgatoryX '),
    ('^reg ', 'RealExGirlfriends '),
    ('^rkp ', 'RKPrime '),
    ('^rws ', 'RealWifeStories '),
    ('^rwm ', 'RawWhiteMeat '),
    ('^saf ', 'ShesAFreak '),
    ('^sart ', 'SexArt '),
    ('^sas ', 'SexandSubmission '),
    ('^sbj ', 'StreetBlowjobs '),
    ('^scoreland2', 'ScorelandTwo '),
    ('^seb ', 'SexuallyBroken '),
    ('^sed ', 'SexualDisgrace '),
    ('^shd ', 'ScoreLand '),
    ('^Shes New ', 'She\'s New '),
    ('^sins ', 'SinsLife '),
    ('^sislove ', 'SisLovesMe '),
    ('^smb ', 'ShareMyBF '),
    ('^SuperSkinnyGirls ', '18OnlyGirls '),
    ('^ssc ', 'StepSiblingsCaught '),
    ('^ssg ', '18OnlyGirls '),
    ('^ssn ', 'ShesNew '),
    ('^sts ', 'StrandedTeens '),
    ('^swm ', 'SexWithMuslims '),
    ('^swsn ', 'SwallowSalon '),
    ('^tdp ', 'TeensDoPorn '),
    ('^tds ', 'TheDickSuckers '),
    ('^ted ', 'Throated '),
    ('^tf ', 'TeenFidelity '),
    ('^tft ', 'TeacherFucksTeens '),
    ('^tgs ', 'ThisGirlSucks '),
    ('^these ', 'TheStripperExperience '),
    ('^tla ', 'TeensLoveAnal '),
    ('^tlc ', 'TeensLoveCream '),
    ('^tle ', 'TheLifeErotic '),
    ('^tlhc ', 'TeensLoveHugeCocks '),
    ('^tlib ', 'TeensLikeItBig '),
    ('^tlm ', 'TeensLoveMoney '),
    ('^tog ', 'TonightsGirlfriend '),
    ('^togc ', 'TonightsGirlfriendClassic '),
    ('^trwo ', 'TheRealWorkout '),
    ('^tspa ', 'TrickySpa '),
    ('^tss ', 'ThatSitcomShow '),
    ('^tuf ', 'TheUpperFloor '),
    ('^txc ', 'TeamSkeetXCamSoda '),
    ('^viparea ', 'Babe Archives '),
    ('^w4b ', 'Watch4Beauty '),
    ('^wa ', 'WhippedAss '),
    ('^wcx', 'WoodmanCastingX'),
    ('^wfbg ', 'WeFuckBlackGirls '),
    ('^wkp ', 'Wicked '),
    ('^wlt ', 'WeLiveTogether '),
    ('^woc ', 'WildOnCam '),
    ('^wov ', 'WivesOnVacation '),
    ('^wowg ', 'WowGirls '),
    ('^wowp ', 'WowPorn '),
    ('^wunf', 'WakeUpNFuck'),
    ('^wy ', 'WebYoung '),
    ('^ylp ', '18OnlyGirls '),
    ('^xevbellringer ', 'XevUnleashed '),
    ('^xlg ', 'XLGirls '),
    ('^YoungLegalPorn ', '18OnlyGirls '),
    ('^ztod ', 'ZeroTolerance '),
    ('^zzs ', 'ZZseries '),
)


def getProviderFromSiteNum(siteNum):
    provider = None

    if siteNum is not None:
        # Strike3
        if (0 <= siteNum <= 1) or siteNum == 52 or siteNum == 136 or (670 <= siteNum <= 671) or siteNum == 1357 or siteNum == 1806 or siteNum == 1893:
            provider = networkStrike3

        # Brazzers
        elif siteNum == 2 or (54 <= siteNum <= 81) or siteNum == 582 or siteNum == 690 or siteNum == 1351 or siteNum == 1552:
            provider = network1service

        # MetadataAPI
        elif siteNum == 3:
            provider = networkMetadataAPI

        # Naughty America
        elif (5 <= siteNum <= 51) or siteNum == 341 or (393 <= siteNum <= 396) or (467 <= siteNum <= 468) or siteNum == 581 or siteNum == 620 or siteNum == 625 or siteNum == 691 or siteNum == 749 or (1569 <= siteNum <= 1573):
            provider = siteNaughtyAmerica

        # GirlsWay
        elif siteNum == 53 or (375 <= siteNum <= 379) or (795 <= siteNum <= 797):
            provider = networkGammaEntOther

        # 21Naturals
        elif siteNum == 183 or (373 <= siteNum <= 374):
            provider = networkGammaEntOther

        # Evil Angel
        elif siteNum == 277 or siteNum == 975:
            provider = networkGammaEntOther

        # XEmpire
        elif siteNum == 278 or (285 <= siteNum <= 287) or siteNum == 843:
            provider = networkGammaEntOther

        # Pure Taboo
        elif siteNum == 281:
            provider = networkGammaEntOther

        # Blowpass
        elif siteNum == 329 or (351 <= siteNum <= 355) or siteNum == 861:
            provider = networkGammaEntOther

        # Mile High Media
        elif (361 <= siteNum <= 364) or siteNum == 852 or (914 <= siteNum <= 915) or siteNum == 1328 or (1732 <= siteNum <= 1733):
            provider = network1service

        # Fantasy Massage
        elif siteNum == 330 or (355 <= siteNum <= 360) or siteNum == 750:
            provider = networkGammaEntOther

        # 21Sextury
        elif (365 <= siteNum <= 372) or siteNum == 466 or siteNum == 692:
            provider = networkGammaEntOther

        # Girlfriends Films
        elif siteNum == 380:
            provider = networkGammaEntOther

        # Burning Angel
        elif siteNum == 381:
            provider = networkGammaEntOther

        # Pretty Dirty
        elif siteNum == 382:
            provider = networkGammaEntOther

        # Devil's Film
        elif siteNum == 383:
            provider = networkGammaEntOther

        # Peter North
        elif siteNum == 384:
            provider = networkGammaEntOther

        # Rocco Siffredi
        elif siteNum == 385:
            provider = networkGammaEntOther

        # Tera Patrick
        elif siteNum == 386:
            provider = networkGammaEnt

        # Sunny Leone
        elif siteNum == 387:
            provider = networkGammaEnt

        # Lane Sisters
        elif siteNum == 388:
            provider = networkGammaEnt

        # Dylan Ryder
        elif siteNum == 389:
            provider = networkGammaEnt

        # Abbey Brooks
        elif siteNum == 390:
            provider = networkGammaEnt

        # Devon Lee
        elif siteNum == 391:
            provider = networkGammaEnt

        # Hanna Hilton
        elif siteNum == 392:
            provider = networkGammaEnt

        # 21Sextreme
        elif (460 <= siteNum <= 465):
            provider = networkGammaEntOther

        # X-Art
        elif siteNum == 82:
            provider = siteXart

        # Bang Bros
        elif (83 <= siteNum <= 135):
            provider = network1service

        # Reality Kings
        elif (137 <= siteNum <= 182) or (822 <= siteNum <= 828) or siteNum == 1593 or siteNum == 1737 or siteNum == 1743:
            provider = network1service

        # Kelly Madison Productions
        elif (184 <= siteNum <= 186):
            provider = networkKellyMadison

        # TeamSkeet
        elif (187 <= siteNum <= 215) or (566 <= siteNum <= 567) or siteNum == 626 or siteNum == 686 or siteNum == 748 or siteNum == 807 or (845 <= siteNum <= 851) or siteNum == 875 or (997 <= siteNum <= 1011) or (1249 <= siteNum <= 1251) or (1354 <= siteNum <= 1356) or (1362 <= siteNum <= 1363) or (1371 <= siteNum <= 1373) or siteNum == 1390 or (1399 <= siteNum <= 1425) or (1584 <= siteNum <= 1588) or siteNum == 1736 or (1808 <= siteNum <= 1810) or (1816 <= siteNum <= 1823):
            provider = networkTeamSkeet

        # Porndoe Premium
        elif siteNum == 219 or siteNum == 224 or (228 <= siteNum <= 229) or siteNum == 232 or siteNum == 234 or (236 <= siteNum <= 237) or (239 <= siteNum <= 242) or (245 <= siteNum <= 246) or (248 <= siteNum <= 259):
            provider = sitePorndoePremium

        # LetsDoeIt
        elif (216 <= siteNum <= 218) or (220 <= siteNum <= 223) or (225 <= siteNum <= 227) or (230 <= siteNum <= 231) or siteNum == 233 or siteNum == 235 or siteNum == 238 or (243 <= siteNum <= 244) or siteNum == 247 or siteNum == 1885:
            provider = network1service

        # AnalVids
        elif siteNum == 260:
            provider = siteAnalVids

        # Mofos
        elif (261 <= siteNum <= 270) or siteNum == 583 or (738 <= siteNum <= 740) or (1059 <= siteNum <= 1064) or siteNum == 1590:
            provider = network1service

        # Babes
        elif (271 <= siteNum <= 276):
            provider = network1service

        # GloryHoleSecrets
        elif siteNum == 279:
            provider = networkGammaEntOther

        # NewSensations
        elif siteNum == 280 or siteNum == 1266:
            provider = siteNewSensations

        # SteppedUp
        elif (282 <= siteNum <= 284) or siteNum == 767 or siteNum == 1253 or siteNum == 1674:
            provider = networkSteppedUp

        # Twistys
        elif (288 <= siteNum <= 291) or siteNum == 768:
            provider = network1service

        # Spizoo
        elif siteNum == 293 or (571 <= siteNum <= 577) or (1374 <= siteNum <= 1375) or siteNum == 1757 or (1825 <= siteNum <= 1828):
            provider = siteSpizoo

        # Private
        elif (294 <= siteNum <= 305):
            provider = sitePrivate

        # PornPros Network
        elif (306 <= siteNum <= 327) or (479 <= siteNum <= 489) or siteNum == 624 or siteNum == 769 or siteNum == 844 or siteNum == 890 or siteNum == 1263 or siteNum == 1364 or siteNum == 1393 or (1688 <= siteNum <= 1693) or (1695 <= siteNum <= 1702) or siteNum == 1892:
            provider = networkPornPros

        # DigitalPlayground
        elif siteNum == 328:
            provider = network1service

        # SexyHub
        elif (333 <= siteNum <= 339) or (406 <= siteNum <= 407):
            provider = network1service

        # FullPornNetwork
        elif (343 <= siteNum <= 350) or siteNum == 1394 or siteNum == 1562:
            provider = networkFullPornNetwork

        # DogfartNetwork
        elif (408 <= siteNum <= 431) or siteNum == 1805:
            provider = networkGammaEntOther

        # FakeHub
        elif siteNum == 340 or (397 <= siteNum <= 407):
            provider = network1service

        # JulesJordan
        elif siteNum == 432:
            provider = siteJulesJordan

        # Manuel Ferrara
        elif siteNum == 522:
            provider = siteJulesJordan

        # The Ass Factory
        elif siteNum == 523:
            provider = siteJulesJordan

        # Sperm Swallowers
        elif siteNum == 524:
            provider = siteJulesJordan

        # GirlGirl
        elif siteNum == 782:
            provider = siteJulesJordan

        # DDF Network
        elif (440 <= siteNum <= 447):
            provider = networkPornWorld

        # PerfectGonzo
        elif (448 <= siteNum <= 459) or (908 <= siteNum <= 911):
            provider = networkPerfectGonzo

        # BadoinkVR Network
        elif (469 <= siteNum <= 473) or siteNum == 1894:
            provider = networkBadoinkVR

        # VRBangers
        elif siteNum == 474:
            provider = siteVRBangers

        # SexBabesVR
        elif siteNum == 475:
            provider = networkHighTechVR

        # SinsVR
        elif siteNum == 569:
            provider = siteXSinsVR

        # StasyQ VR
        elif siteNum == 570:
            provider = networkHighTechVR

        # WankzVR
        elif siteNum == 476:
            provider = siteMilfVR

        # MilfVR
        elif siteNum == 477:
            provider = siteMilfVR

        # Kink
        elif (490 <= siteNum <= 521) or siteNum == 687 or (735 <= siteNum <= 736) or (873 <= siteNum <= 874) or (888 <= siteNum <= 889):
            provider = networkKink

        # Nubiles
        elif (525 <= siteNum <= 545) or (755 <= siteNum <= 756) or siteNum == 766 or (995 <= siteNum <= 996) or siteNum == 1040 or siteNum == 1256 or siteNum == 1360 or (1396 <= siteNum <= 1397) or siteNum == 1551 or (1575 <= siteNum <= 1582) or siteNum == 1686:
            provider = networkNubiles

        # BellaPass
        elif (548 <= siteNum <= 563) or (1246 <= siteNum <= 1247) or siteNum == 1553:
            provider = networkBellaPass

        # AllureMedia
        elif (564 <= siteNum <= 565):
            provider = siteAllureMedia

        # Manyvids
        elif siteNum == 568:
            provider = siteManyvids

        # VirtualTaboo
        elif siteNum == 292:
            provider = siteVirtualTaboo

        # VirtualRealPorn
        elif siteNum == 342:
            provider = siteVirtualReal

        # CzechVR Network
        elif (578 <= siteNum <= 580) or (1891 == siteNum):
            provider = networkCzechVR

        # FinishesTheJob
        elif (584 <= siteNum <= 586):
            provider = siteFinishesTheJob

        # Wankz Network
        elif (587 <= siteNum <= 619):
            provider = networkWankz

        # MetArt Network
        elif (621 <= siteNum <= 623) or (753 <= siteNum <= 754) or (816 <= siteNum <= 821):
            provider = networkMetArt

        # Tonights Girlfriend
        elif siteNum == 627:
            provider = siteTonightsGirlfriend

        # Karups
        elif (628 <= siteNum <= 630):
            provider = siteKarups

        # TeenMegaWorld
        elif (631 <= siteNum <= 666) or siteNum == 930 or siteNum == 1398:
            provider = networkTeenMegaWorld

        # Screwbox
        elif siteNum == 668:
            provider = siteScrewbox

        # DorcelClub
        elif siteNum == 669:
            provider = siteDorcelClub

        # MissaX / AllHerLuv / Exposed Whores / She Seduced Me / House of Fyre / Philavise / Lauren Phillips
        elif siteNum == 672 or siteNum == 673 or (1254 <= siteNum <= 1255) or (1264 <= siteNum <= 1265) or siteNum == 1327:
            provider = siteMissaX

        # Mylf
        elif (674 <= siteNum <= 683) or siteNum == 757 or siteNum == 842 or (siteNum >= 853 and siteNum <= 858) or (881 <= siteNum <= 887) or siteNum == 1329 or (1426 <= siteNum <= 1445) or siteNum == 1589 or (1734 <= siteNum <= 1735) or siteNum == 1807 or (1811 <= siteNum <= 1815):
            provider = networkMYLF

        # Manually Add Actors
        elif siteNum == 684:
            provider = addActors

        # First Anal Quest
        elif siteNum == 685:
            provider = siteFirstAnalQuest

        # Hegre
        elif siteNum == 688:
            provider = siteHegre

        # Femdom Empire
        elif siteNum == 689 or siteNum == 694:
            provider = networkFemdomEmpire

        # Dorcel Vision
        elif siteNum == 693:
            provider = siteDorcelVision

        # XConfessions
        elif siteNum == 695:
            provider = siteXConfessions

        # CzechAV
        elif (696 <= siteNum <= 728) or siteNum == 1583:
            provider = networkCzechAV

        # ArchAngel
        elif siteNum == 729:
            provider = siteArchAngel

        # We Are Hairy
        elif siteNum == 730:
            provider = siteWeAreHairy

        # Love Her Films
        elif siteNum == 731 or (1705 <= siteNum <= 1707):
            provider = networkLoveHerFilms

        # MomPOV
        elif siteNum == 732:
            provider = siteMomPOV

        # Property Sex
        elif siteNum == 733:
            provider = network1service

        # FuelVirtual
        elif (546 <= siteNum <= 547) or siteNum == 1395:
            provider = networkFuelVirtual

        # TransAngels
        elif siteNum == 737:
            provider = network1service

        # Straplezz
        elif siteNum == 741:
            provider = networkMetArt

        # LittleCaprice
        elif siteNum == 742 or (1713 <= siteNum <= 1720):
            provider = siteLittleCaprice

        # VIPissy
        elif siteNum == 744:
            provider = siteVIPissy

        # GirlsOutWest
        elif siteNum == 745:
            provider = siteGirlsOutWest

        # Girls Rimming
        elif siteNum == 746:
            provider = siteGirlsRimming

        # Gangbang Creampie
        elif siteNum == 747:
            provider = networkGammaEntOther

        # StepSecrets
        elif siteNum == 751:
            provider = siteStepSecrets

        # VRHush
        elif siteNum == 752:
            provider = siteVRHush

        # Fitting-Room
        elif siteNum == 758:
            provider = siteFittingRoom

        # FamilyHookups
        elif siteNum == 759:
            provider = network1service

        # Clips4Sale
        elif siteNum == 760:
            provider = siteClips4Sale

        # VogoV
        elif siteNum == 761:
            provider = siteVogoV

        # UltraFilms
        elif siteNum == 762:
            provider = siteUltrafilms

        # fuckingawesome.com
        elif siteNum == 763:
            provider = siteFuckingAwesome

        # ToughLoveX
        elif siteNum == 764:
            provider = siteToughLoveX

        # cumlouder.com
        elif siteNum == 765:
            provider = siteCumLouder

        # ZeroTolerance
        elif siteNum == 770:
            provider = networkGammaEntOther

        # ClubFilly
        elif siteNum == 771:
            provider = siteClubFilly

        # Intersec
        elif (772 <= siteNum <= 781):
            provider = networkIntersec

        # Cherry Pimps
        elif (783 <= siteNum <= 792) or (1052 <= siteNum <= 1056) or (1745 <= siteNum <= 1746):
            provider = networkCherryPimps

        # Wicked
        elif siteNum == 793:
            provider = networkGammaEntOther

        # LilHumpers
        elif siteNum == 798:
            provider = network1service

        # Bellesa
        elif siteNum == 799 or siteNum == 876:
            provider = networkBellesa

        # Adult Prime
        elif siteNum == 800 or (1601 <= siteNum <= 1672) or siteNum == 1749:
            provider = networkAdultPrime

        # Family Sinners
        elif siteNum == 802:
            provider = network1service

        # ReidMyLips
        elif siteNum == 803:
            provider = siteReidMyLips

        # Playboy Plus
        elif siteNum == 804:
            provider = sitePlayboyPlus

        # Meana Wolf
        elif siteNum == 805:
            provider = siteMeanaWolf

        # Transsensual
        elif siteNum == 806:
            provider = network1service

        # Erito
        elif siteNum == 808:
            provider = network1service

        # TrueAmateurs
        elif siteNum == 809:
            provider = network1service

        # Hustler
        elif siteNum == 810:
            provider = networkMetArt

        # AmourAngels
        elif siteNum == 811:
            provider = siteAmourAngels

        # Bang
        elif siteNum == 813 or siteNum == 1365:
            provider = networkBang

        # Vivid
        elif siteNum == 814:
            provider = siteVivid

        # AdultEmpireCash Network
        elif siteNum == 815 or siteNum == 1337 or siteNum == 1574 or (1765 <= siteNum <= 1781) or (1784 <= siteNum <= 1796) or siteNum == 1800:
            provider = networkAdultEmpireCash

        # My Pervy Family
        elif siteNum == 1248:
            provider = networkGammaEntOther

        # Filthy Kings sites
        elif (1257 <= siteNum <= 1262) or (1750 <= siteNum <= 1753) or (1887 <= siteNum <= 1888):
            provider = networkGammaEntOther

        # PJGirls
        elif siteNum == 667:
            provider = sitePJGirls

        # PureCFNM Network
        elif (829 <= siteNum <= 834):
            provider = networkPureCFNM

        # BAMVisions
        elif siteNum == 835:
            provider = siteBAMVisions

        # ATKGirlfriends
        elif siteNum == 836:
            provider = siteATKGirlfriends

        # Interracial Pass / ExploitedX / I Kiss Girls
        elif siteNum == 840 or (976 <= siteNum <= 978) or siteNum == 1244 or (1563 <= siteNum <= 1564):
            provider = siteInterracialPass

        # LookAtHerNow
        elif siteNum == 841:
            provider = network1service

        # Deviant Hardcore
        elif siteNum == 859:
            provider = network1service

        # She Will Cheat
        elif siteNum == 860:
            provider = network1service

        # SinsLife
        elif siteNum == 862:
            provider = siteSinsLife

        # Puffy Network
        elif siteNum == 863 or (867 <= siteNum <= 870):
            provider = networkPuffy

        # SinX
        elif (864 <= siteNum <= 866) or siteNum == 871:
            provider = networkSinX

        # Kinky Spa
        elif siteNum == 872:
            provider = network1service

        # Reality Lovers
        elif siteNum == 877:
            provider = siteRealityLovers

        # Adult Time
        elif siteNum == 478 or siteNum == 878 or (1554 <= siteNum <= 1561) or (1722 <= siteNum <= 1729) or (1863 <= siteNum <= 1865):
            provider = networkGammaEntOther

        # RealJamVR
        elif siteNum == 879:
            provider = networkHighTechVR

        # BBC Paradise
        elif siteNum == 880:
            provider = networkMYLF

        # HoloGirlsVR
        elif siteNum == 891:
            provider = siteHoloGirlsVR

        # Gender X
        elif siteNum == 893:
            provider = networkGammaEntOther

        # Romero Multimedia
        elif (895 <= siteNum <= 896) or (1594 <= siteNum <= 1596) or (1797 <= siteNum <= 1798) or (1883 <= siteNum <= 1884):
            provider = networkRomero

        # XVirtual
        elif siteNum == 897:
            provider = siteXVirtual

        # Lust Reality
        elif siteNum == 898:
            provider = siteLustReality

        # Sex Like Real
        elif siteNum == 899:
            provider = siteSexLikeReal

        # DoeGirls
        elif siteNum == 900:
            provider = network1service

        # Xillimite
        elif siteNum == 901:
            provider = siteXillimite

        # VRP Films
        elif siteNum == 902:
            provider = siteVRPFilms

        # VR Latina
        elif siteNum == 903:
            provider = siteVRLatina

        # VRConk
        elif siteNum == 904:
            provider = siteVRConk

        # Evolved Fights Network
        elif siteNum == 906 or siteNum == 907:
            provider = networkEvolvedFights

        # JavBus
        elif siteNum == 912:
            provider = networkJavBus

        # Hucows
        elif siteNum == 913:
            provider = siteHucows

        # Why Not Bi
        elif siteNum == 916:
            provider = network1service

        # HentaiPros
        elif siteNum == 917:
            provider = network1service

        # PornPortal
        elif (918 <= siteNum <= 929):
            provider = network1service

        # VNA Network
        elif siteNum == 931 or (1287 <= siteNum <= 1326):
            provider = networkVNA

        # QueenSnake
        elif siteNum == 932:
            provider = siteQueenSnake

        # QueenSect
        elif siteNum == 933:
            provider = siteQueenSnake

        # Fetish Network
        elif (934 <= siteNum <= 937):
            provider = networkKink

        # ScrewMeToo
        elif siteNum == 938:
            provider = siteScrewMeToo

        # Aussie Ass
        elif siteNum == 940:
            provider = siteAussieAss

        # 5Kporn
        elif (941 <= siteNum <= 942):
            provider = network5Kporn

        # Teen Core Club
        elif (943 <= siteNum <= 974 or siteNum == 1358 or 1708 <= siteNum <= 1709):
            provider = networkTeenCoreClub

        # Desperate Amateurs
        elif (siteNum == 979):
            provider = siteDesperateAmateurs

        # Dirty Hard Drive
        elif (980 <= siteNum <= 987):
            provider = networkDirtyHardDrive

        # Melone Challenge
        elif (siteNum == 988):
            provider = siteMeloneChallenge

        # Holly Randall
        elif siteNum == 989:
            provider = siteHollyRandall

        # In The Crack
        elif siteNum == 990:
            provider = siteInTheCrack

        # Angela White
        elif siteNum == 991:
            provider = siteAngelaWhite

        # Cumbizz
        elif siteNum == 992:
            provider = siteCumbizz

        # Pornstar Platinum
        elif siteNum == 993:
            provider = sitePornstarPlatinum

        # Woodman Casting X
        elif siteNum == 994:
            provider = siteWoodmanCastingX

        # ScoreGroup
        elif (1012 <= siteNum <= 1021) or (1344 <= siteNum <= 1345) or siteNum == 1744 or siteNum == 1889:
            provider = networkScoreGroup

        # TwoTGirls
        elif siteNum == 1022:
            provider = siteTwoTGirls

        # Sicflics
        elif siteNum == 1023:
            provider = siteSicflics

        # AlettaOceanLive
        elif siteNum == 1024:
            provider = siteAlettaOceanLive

        # ModelCentro network
        elif (1025 <= siteNum <= 1039) or siteNum == 1051 or siteNum == 1058 or siteNum == 1075 or siteNum == 1191 or siteNum == 1245:
            provider = networkModelCentro

        # PornWorld
        elif siteNum == 332 or (433 <= siteNum <= 439) or siteNum == 1057:
            provider = networkPornWorld

        # MormonGirlz
        elif siteNum == 1065:
            provider = siteMormonGirlz

        # PurgatoryX
        elif siteNum == 1066 or (1851 <= siteNum <= 1862):
            provider = networkRadicalCashOther

        # PlumperPass
        elif siteNum == 1067:
            provider = sitePlumperPass

        # FTV
        elif (1068 <= siteNum <= 1069):
            provider = networkFTV

        # Jacquie & Michel
        elif siteNum == 1070:
            provider = siteJacquieEtMichel

        # Data18 Scenes
        elif siteNum == 1071 or siteNum == 1370:
            provider = siteData18Scenes

        # Penthouse Gold
        elif siteNum == 1072:
            provider = sitePenthouseGold

        # Data18 Movies
        elif siteNum == 1073:
            provider = siteData18Movies

        # WakeUpNFuck
        elif siteNum == 1074:
            provider = siteWUNF

        # SexMex
        elif siteNum == 1076:
            provider = siteSexMex

        # Explicite Art
        elif siteNum == 1077:
            provider = siteExpliciteArt

        # Black PayBack
        elif siteNum == 1078:
            provider = siteBlackPayBack

        # Sunny Lane Live
        elif siteNum == 1079:
            provider = siteSunnyLaneLive

        # FAKings
        elif (1080 <= siteNum <= 1152):
            provider = networkFAKings

        # Other BangBros Sites
        elif (1153 <= siteNum <= 1154) or (1156 <= siteNum <= 1158) or siteNum == 1673:
            provider = networkBangBrosOther

        # Putalocura
        elif siteNum == 1155:
            provider = sitePutalocura

        # Melena Maria Rya
        elif siteNum == 1159:
            provider = siteMelenaMariaRya

        # PervCity
        elif (1160 <= siteNum <= 1165):
            provider = networkPervCity

        # Abby Winters
        elif (1166 <= siteNum <= 1179):
            provider = networkAbbyWinters

        # New Sensations Other
        elif siteNum == 1180 or (1186 <= siteNum <= 1189):
            provider = siteNewSensationsOther

        # Deranged Dollars
        elif (1181 <= siteNum <= 1182):
            provider = networkDerangedDollars

        # DickDrainers
        elif siteNum == 1183:
            provider = siteDickDrainers

        # ALS Angels
        elif siteNum == 1184:
            provider = siteAlsAngels

        # Watch4Beauty
        elif siteNum == 1185:
            provider = siteWatch4Beauty

        # Femjoy
        elif siteNum == 1190:
            provider = siteFemjoy

        # Thick Cash
        elif (1192 <= siteNum <= 1195):
            provider = networkThickCash

        # PornCZ
        elif (1196 <= siteNum <= 1228):
            provider = networkPornCZ

        # MyDirtyHobby
        elif siteNum == 1237:
            provider = siteMyDirtyHobby

        # Deviante
        elif (1238 <= siteNum <= 1243):
            provider = network1service

        # Couples Cinema Network
        elif (1267 <= siteNum <= 1285):
            provider = networkCouplesCinema

        # JVR Porn
        elif siteNum == 1286:
            provider = siteJVRPorn

        # Data18 Empire
        elif siteNum == 1330:
            provider = siteData18Empire

        # Grooby Network
        elif (1331 <= siteNum <= 1333) or (1338 <= siteNum <= 1343) or (1391 <= siteNum <= 1392) or siteNum == 1739:
            provider = networkGrooby

        # Adult Empire
        elif siteNum == 1334:
            provider = siteAdultEmpire

        # Family Therapy
        elif siteNum == 1335:
            provider = siteFamilyTherapy

        # Network 18
        elif siteNum == 1336 or siteNum == 1389:
            provider = network18

        # DarkRoomVR
        elif siteNum == 1346:
            provider = siteDarkRoomVR

        elif siteNum == 1347:
            provider = sitePuba

        # StasyQ
        elif (1348 == siteNum):
            provider = siteStasyQ

        # Bound Honeys
        elif siteNum == 1349:
            provider = siteBoundHoneys

        # Lustomic
        elif siteNum == 1350:
            provider = siteLustomic

        # Strapon Cum
        elif siteNum == 1352:
            provider = siteStraponCum

        # HotwifeXXX
        elif siteNum == 1353:
            provider = siteHotwifeXXX

        # POVR
        elif siteNum == 1359:
            provider = sitePOVR

        # Swallow Bay
        elif siteNum == 1361:
            provider = siteSwallowBay

        # Virtual Porn
        elif siteNum == 1366:
            provider = siteVirtualPorn

        # JAV Library
        elif siteNum == 1367:
            provider = siteJavLibrary

        # Killergram
        elif (1368 <= siteNum <= 1369):
            provider = siteKillergram

        # VIP4K
        elif (1376 <= siteNum <= 1388) or siteNum == 1687 or siteNum == 1694 or (1710 <= siteNum <= 1712) or siteNum == 1721 or siteNum == 1740 or siteNum == 1748:
            provider = networkVIP4K

        # Dirty Flix Network
        elif (1446 <= siteNum <= 1449):
            provider = networkDirtyFlix

        # NetVideoGirls
        elif siteNum == 1550:
            provider = networkNVG

        # Blurred Media
        elif (1565 <= siteNum <= 1568):
            provider = networkBlurredMedia

        # Bel Ami Online
        elif siteNum == 1591:
            provider = siteBelAmi

        # Mom Comes First
        elif siteNum == 1592:
            provider = siteMomComesFirst

        # Caribbeancom
        elif siteNum == 1597:
            provider = siteCaribbeancom

        # VRAllure
        elif siteNum == 1598:
            provider = siteVRAllure

        # Kin8tengoku
        elif siteNum == 1599:
            provider = siteKin8tengoku

        # JAV Database
        elif siteNum == 1600:
            provider = siteJAVDatabase

        # Radical Cash
        elif (837 <= siteNum <= 839) or (1229 <= siteNum <= 1236) or (1675 <= siteNum <= 1685) or siteNum == 1747 or (1802 <= siteNum <= 1804) or (1829 <= siteNum <= 1850):
            provider = networkRadicalCash

        # Teeny Taboo
        elif siteNum == 1703:
            provider = siteTeenyTaboo

        # WowNetwork
        elif siteNum == 743 or siteNum == 794 or siteNum == 1738:
            provider = networkWowNetwork

        # Aunt Judys
        elif (1730 <= siteNum <= 1731):
            provider = networkAuntJudys

        # Colette
        elif siteNum == 1741:
            provider = siteColette

        # Thick Cash Other
        elif (1754 <= siteNum <= 1756):
            provider = networkThickCashOther

        # Sex Selector
        elif siteNum == 1758:
            provider = network1service

        # Xev Unleashed
        elif siteNum == 1759:
            provider = siteXevUnleashed

        # PKJ Media
        elif 1760 <= siteNum <= 1764:
            provider = networkPKJMedia

        # Brand New Amateurs
        elif siteNum == 1799:
            provider = siteBrandNewAmateurs

        # Pornbox
        elif siteNum == 1801:
            provider = sitePornbox

        # Jesse Loads Monster Facials
        elif siteNum == 1824:
            provider = siteJesseLoadsMonsterFacials

        # GASM
        elif 1866 <= siteNum <= 1882:
            provider = networkGASM

        # Heavy on Hotties
        elif siteNum == 1886:
            provider = siteHeavyOnHotties

        # Lust Cinema
        elif siteNum == 1890:
            provider = siteXConfessions

        # Lethal Hardcore
        elif (1782 <= siteNum <= 1783):
            provider = networkGammaEntOther

    return provider
